(*
-----------------------------------------------------------------------
CIP - Computational Intelligence Packages: Package Perceptron
Version 1.1 for Mathematica 7 or higher
-----------------------------------------------------------------------

Author : Prof. Dr. Achim Zielesny
         E-Mail 
         - IBCI : achim.zielesny@fh-gelsenkirchen.de
         - GNWI : achim.zielesny@gnwi.de

IBCI - Institute for Chemoinformatics and Bioinformatics, 
University of Applied Sciences Gelsenkirchen, Germany

GNWI - Gesellschaft fuer naturwissenschaftliche Informatik mbH, 
Oer-Erkenschwick, Germany

Citation:
A. Zielesny, CIP - Computational Intelligence Packages, Version 1.1, 
GNWI mbH (http://www.gnwi.de), Oer-Erkenschwick, Germany, 2011.

Additional information:
Achim Zielesny, From Curve Fitting to Machine Learning: An 
illustrative Guide to scientific Data Analysis and Computational 
Intelligence, Berlin 2011.
(Springer: Intelligent Systems Reference Library, Volume 18)

A CIP user forum is provided at http://www.gnwi.de.

Code partially based on:
J. A. Freeman, Simulating Neural Networks with Mathematica, 
Boston 1993, Addison-Wesley Longman Publishing Co.


Copyright 2011 Achim Zielesny

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License (LGPL) as 
published by the Free Software Foundation, version 3 of the License.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
Lesser General Public License (LGPL) for more details.

You should have received a copy of the GNU Lesser General Public 
License along with this program. If not, see 
<http://www.gnu.org/licenses/>. 
-----------------------------------------------------------------------
*)

(* ::Section:: *)
(* Frequently used data structures *)

(*
-----------------------------------------------------------------------
Frequently used data structures
-----------------------------------------------------------------------
perceptronInfo: {networks, dataSetScaleInfo, perceptronTrainingResults, optimizationMethod} 

	networks: {weights1, weights2, ...}
	weights: {hiddenWeights, outputWeights}
	hiddenWeights: Weights from input to hidden units
	outputWeights : Weights from hidden to output units
	dataSetScaleInfo: {dataMatrixScaleInfo for inputs, dataMatrixScaleInfo for outputs}, see GetDataSetScaleInfo
	perceptronTrainingResults: {singleTrainingResult1, singleTrainingResult2, ...}
	singleTrainingResult[[i]] corresponds to weights[[i]]
	singleTrainingResult: {trainingMeanSquaredErrorList, testMeanSquaredErrorList}
	trainingMeanSquaredErrorList: {reportPair1, reportPair2, ...}
	reportPair: {reportIteration, mean squared error of report iteration}
	testMeanSquaredErrorList: Same structure as trainingMeanSquaredErrorList
-----------------------------------------------------------------------
*)

(* ::Section:: *)
(* Package and dependencies *)

BeginPackage["CIP`Perceptron`", {"CIP`Utility`", "CIP`Graphics`", "CIP`DataTransformation`", "CIP`Cluster`", "Combinatorica`"}]

(* ::Section:: *)
(* Off settings *)

Off[General::"spell1"]
Off[General::shdw]
Off[FindMinimum::cvmit]
Off[General::compat]

(* ::Section:: *)
(* Options *)

Options[PerceptronOptionsTraining] = 
{
	(* True: Multiple perceptrons may be used (one percetpron for every single output component), False: One perceptron is used only *)
    PerceptronOptionMultiplePerceptrons -> True,
	
	(* Optimization method: "FindMinimum", "NMinimize", "BackpropagationPlusMomentum", "GeneticAlgorithm" *)
    PerceptronOptionOptimizationMethod -> "FindMinimum",
    
    (* Test set *)
    PerceptronOptionTestSet -> {}
}

Options[PerceptronOptionsOptimization] = 
{
	(* Initial weights to be improved (may be empty list)
	   initialWeights: {hiddenWeights, outputWeights}
	   hiddenWeights: Weights from input to hidden units
	   outputWeights: Weights from hidden to output units *)
	PerceptronOptionInitialWeights -> {},

	(* Initial networks for multiple perceptrons training to be improved (may be empty list)
	   networks: {weights1, weights2, ...}
	   weights: {hiddenWeights, outputWeights}
	   hiddenWeights: Weights from input to hidden units
	   outputWeights: Weights from hidden to output units *)
	PerceptronOptionInitialNetworks -> {},
	
    (* Initial weights will be in interval -PerceptronOptionWeightsValueLimit <= weight value <= +PerceptronOptionWeightsValueLimit*)
	PerceptronOptionWeightsValueLimit -> 1.0,
	
    (* Number of digits for AccuracyGoal and PrecisionGoal (MUST be smaller than MachinePrecision) *)
    PerceptronOptionMinimizationPrecision -> 5,
    
    (* Maximum number of minimization steps *)
    PerceptronOptionMaximumIterations -> 10000,

    (* Number of iterations to improve *)
    PerceptronOptionIterationsToImprove -> 1000,
    
    (* The meanSquaredErrorLists (training protocol) will be filled every reportIteration steps.
       reportIteration <= 0 means no internal reports during training/minimization procedure. *)
    PerceptronOptionReportIteration -> 0
}

Options[PerceptronOptionsBackpropagation] = 
{
    (* Minimum learning parameter *)
    PerceptronOptionLearningParameterMin -> 0.1,
    
    (* Maximum learning parameter *)
    PerceptronOptionLearningParameterMax -> 0.1,
    
    (* Momentum parameter *)
    PerceptronOptionMomentumParameter -> 0.5
}

Options[PerceptronOptionsGeneticAlgorithm] =
{
    (* Size of population *)
    PerceptronOptionPopulationSize -> 50,
    
    (* Crossover probability : 0 to 1.0 *)
    PerceptronOptionCrossoverProbability -> 0.9,
    
    (* Mutation probability : 0 to 1.0 *)
    PerceptronOptionMutationProbability -> 0.9
}

(* ::Section:: *)
(* Declarations *)

BumpFunction::usage = 
	"BumpFunction[x, interval]"

BumpSum::usage = 
	"BumpSum[x, intervals]"

CalculatePerceptron2dValue::usage = 
	"CalculatePerceptron2dValue[argumentValue, indexOfInput, indexOfFunctionValueOutput, input, perceptronInfo]"

CalculatePerceptron3dValue::usage = 
	"CalculatePerceptron3dValue[argumentValue1, argumentValue2, indexOfInput1, indexOfInput2, indexOfFunctionValueOutput, input, perceptronInfo]"

CalculatePerceptronClassNumber::usage = 
	"CalculatePerceptronClassNumber[input, perceptronInfo]"

CalculatePerceptronClassNumbers::usage = 
	"CalculatePerceptronClassNumbers[inputs, perceptronInfo]"

CalculatePerceptronDataSetRmse::usage = 
	"CalculatePerceptronDataSetRmse[dataSet, perceptronInfo]"

CalculatePerceptronOutput::usage = 
	"CalculatePerceptronOutput[input, perceptronInfo]"

CalculatePerceptronOutputs::usage = 
	"CalculatePerceptronOutputs[inputs, perceptronInfo]"

FitPerceptron::usage = 
	"FitPerceptron[dataSet, numberOfHiddenNeutrons, options]"

FitPerceptronSeries::usage = 
	"FitPerceptronSeries[dataSet, numberOfHiddenNeutronsList, options]"

GetBestPerceptronClassOptimization::usage = 
	"GetBestPerceptronClassOptimization[perceptronTrainOptimization, options]"

GetBestPerceptronRegressOptimization::usage = 
	"GetBestPerceptronRegressOptimization[perceptronTrainOptimization, options]"

GetNumberOfHiddenNeurons::usage = 
	"GetNumberOfHiddenNeurons[perceptronInfo]"

GetPerceptronInputInclusionClass::usage = 
	"GetPerceptronInputInclusionClass[trainingAndTestSet, numberOfHiddenNeurons, options]"

GetPerceptronInputInclusionRegress::usage = 
	"GetPerceptronInputInclusionRegress[trainingAndTestSet, numberOfHiddenNeurons, options]"

GetPerceptronInputRelevanceClass::usage = 
	"GetPerceptronInputRelevanceClass[trainingAndTestSet, numberOfHiddenNeurons, options]"

GetPerceptronInputRelevanceRegress::usage = 
	"GetPerceptronInputRelevanceRegress[trainingAndTestSet, numberOfHiddenNeurons, options]"

GetPerceptronSeriesClassificationResult::usage = 
	"GetPerceptronSeriesClassificationResult[trainingAndTestSet, perceptronInfoList]"

GetPerceptronSeriesRmse::usage = 
	"GetPerceptronSeriesRmse[trainingAndTestSet, perceptronInfoList]"

GetPerceptronStructure::usage = 
	"GetPerceptronStructure[perceptronInfo]"

GetPerceptronTrainOptimization::usage = 
	"GetPerceptronTrainOptimization[dataSet, numberOfHiddenNeurons, trainingFraction, numberOfTrainingSetOptimizationSteps, options]"

GetPerceptronWeights::usage = 
	"GetPerceptronWeights[perceptronInfo, indexOfNetwork]"

ScanClassTrainingWithPerceptron::usage = 
	"ScanClassTrainingWithPerceptron[dataSet, numberOfHiddenNeutrons, trainingFractionList, options]"

ScanRegressTrainingWithPerceptron::usage = 
	"ScanRegressTrainingWithPerceptron[dataSet, numberOfHiddenNeutrons, trainingFractionList, options]"

ShowPerceptron2dOutput::usage = 
	"ShowPerceptron2dOutput[indexOfInput, indexOfFunctionValueOutput, input, arguments, perceptronInfo]"

ShowPerceptron3dOutput::usage = 
	"ShowPerceptron3dOutput[indexOfInput1, indexOfInput2, indexOfFunctionValueOutput, input, perceptronInfo, options]"

ShowPerceptronClassificationResult::usage = 
	"ShowPerceptronClassificationResult[namedPropertyList, trainingAndTestSet, perceptronInfo]"

ShowPerceptronSingleClassification::usage = 
	"ShowPerceptronSingleClassification[namedPropertyList, classificationDataSet, perceptronInfo]"

ShowPerceptronClassificationScan::usage = 
	"ShowPerceptronClassificationScan[perceptronClassificationScan, options]"

ShowPerceptronInputRelevanceClass::usage = 
	"ShowPerceptronInputRelevanceClass[perceptronInputComponentRelevanceListForClassification, options]"
	
ShowPerceptronInputRelevanceRegress::usage = 
	"ShowPerceptronInputRelevanceRegress[perceptronInputComponentRelevanceListForRegression, options]"

ShowPerceptronRegressionResult::usage = 
	"ShowPerceptronRegressionResult[namedPropertyList, trainingAndTestSet, perceptronInfo]"

ShowPerceptronSingleRegression::usage = 
	"ShowPerceptronSingleRegression[namedPropertyList, dataSet, perceptronInfo]"

ShowPerceptronRegressionScan::usage = 
	"ShowPerceptronRegressionScan[perceptronRegressionScan, options]"

ShowPerceptronSeriesClassificationResult::usage = 
	"ShowPerceptronSeriesClassificationResult[perceptronSeriesClassificationResult, options]"

ShowPerceptronSeriesRmse::usage = 
	"ShowPerceptronSeriesRmse[perceptronSeriesRmse, options]"

ShowPerceptronTraining::usage = 
	"ShowPerceptronTraining[perceptronInfo]"

ShowPerceptronTrainOptimization::usage = 
	"ShowPerceptronTrainOptimization[perceptronTrainOptimization, options]"

SigmoidFunction::usage = 
	"SigmoidFunction[x]"

(* ::Section:: *)
(* Functions *)
	Begin["`Private`"]

BumpFunction[

	(* Bump function.

	   Returns:
	   Bump function value *)

	(* Argument *)
	x_?NumberQ,
	
	(* Bump interval: {minValue, maxValue} *)
	interval_/;VectorQ[interval, NumberQ]
	
	] := SigmoidFunction[x - interval[[1]]] - SigmoidFunction[x - interval[[2]]];

BumpSum[

	(* Bump sum function.

	   Returns:
	   Bump sum value *)

	(* Argument *)
	x_?NumberQ,
	
	(* Bump intervals: {interval1, interval2, ...} 
	   interval: {minValue, maxValue} *)
	intervals_/;MatrixQ[intervals, NumberQ]

	] := 
	
	Module[
    
		{
			i
		},
		
		Return[
			Sum[BumpFunction[x, intervals[[i]]], {i, Length[intervals]}]
		]	
	];

CalculatePerceptron2dValue[

	(* Calculates 2D output for specified argument and input for specified 3-Layer-True-Unit perceptron.
	   This special method assumes an input and an output with one component only.

	   Returns:
	   Value of specified output neuron for argument *)

    (* Argument value for neuron with index indexOfInput *)
    argumentValue_?NumberQ,
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			indexOfInput,
			indexOfFunctionValueOutput,
			input
		},

		indexOfInput = 1;
		indexOfFunctionValueOutput = 1;
		input = {0.0};
		Return[
			CalculatePerceptron2dValue[argumentValue, indexOfInput, indexOfFunctionValueOutput, input, perceptronInfo]
		]
	];

CalculatePerceptron2dValue[

	(* Calculates 2D output for specified argument and input for specified 3-Layer-True-Unit perceptron.

	   Returns:
	   Value of specified output neuron for argument and input *)

    (* Argument value for neuron with index indexOfInput *)
    argumentValue_?NumberQ,
    
    (* Index of input neuron that receives argumentValue *)
    indexOfInput_?IntegerQ,

    (* Index of output neuron that returns function value *)
    indexOfFunctionValueOutput_?IntegerQ,
    
    (* Perceptron input in original units: 
       inputsInOriginalUnits = {inputValue1, inputValue2, ...} 
       Value of input neuron with specified index (indexOfInput) is replaced by argumentValue *)
    input_/;VectorQ[input, NumberQ],
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			currentInput,
			output
		},
		
		currentInput = ReplacePart[input, {indexOfInput -> argumentValue}];
		output = CalculatePerceptronOutput[currentInput, perceptronInfo];
		Return[output[[indexOfFunctionValueOutput]]];
	];

CalculatePerceptron3dValue[

	(* Calculates 3D output for specified arguments for specified 3-Layer-True-Unit perceptron. 
	   This specific methods assumes a 3-Layer-True-Unit perceptron with 2 input neurons and 1 output neuron.

	   Returns:
	   Value of the single output neuron for arguments *)


    (* Argument value for neuron with index indexOfInput1 *)
    argumentValue1_?NumberQ,
    
    (* Argument value for neuron with index indexOfInput2 *)
    argumentValue2_?NumberQ,
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			indexOfInput1,
			indexOfInput2,
			indexOfOutput,
			input
		},
		
		indexOfInput1 = 1;
		indexOfInput2 = 2;
		indexOfOutput = 1;
		input = {0.0,0.0};
		Return[
			CalculatePerceptron3dValue[argumentValue1, argumentValue2, indexOfInput1, indexOfInput2, indexOfOutput, input, perceptronInfo]
		]
	];

CalculatePerceptron3dValue[

	(* Calculates 3D output for specified arguments and input for specified 3-Layer-True-Unit perceptron.

	   Returns:
	   Value of specified output neuron for arguments and input *)


    (* Argument value for neuron with index indexOfInput1 *)
    argumentValue1_?NumberQ,
    
    (* Argument value for neuron with index indexOfInput2 *)
    argumentValue2_?NumberQ,
    
    (* Index of input neuron that receives argumentValue1 *)
    indexOfInput1_?IntegerQ,

    (* Index of input neuron that receives argumentValue2 *)
    indexOfInput2_?IntegerQ,

    (* Index of output neuron that returns function value *)
    indexOfFunctionValueOutput_?IntegerQ,
    
    (* Perceptron input in original units: 
       inputsInOriginalUnits = {inputValue1, inputValue2, ...} 
       Value of input neurons with specified indices (indexOfInput1, indexOfInput2) are replaced by argument values *)
    input_/;VectorQ[input, NumberQ],
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			currentInput,
			output
		},
		
		currentInput = ReplacePart[input, {indexOfInput1 -> argumentValue1, indexOfInput2 -> argumentValue2}];
		output = CalculatePerceptronOutput[currentInput, perceptronInfo];
		Return[output[[indexOfFunctionValueOutput]]];
	];

CalculatePerceptronClassNumber[

	(* Returns class number for specified input for 3-Layer-True-Unit classification perceptron with specified weights.

	   Returns:
	   Class number of input *)

    
    (* input in original units: {inputValueInOriginalUnit1, inputValueInOriginalUnit2, ...} *)
    input_/;VectorQ[input, NumberQ],
        
  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			combinedOutputs,
			hiddenWeights,
			i,
			networks,
			scaledInputs,
			outputs,
			outputWeights,
			dataSetScaleInfo,
			weights
		},
    
    	networks = perceptronInfo[[1]];
    	dataSetScaleInfo = perceptronInfo[[2]];

		If[Length[networks] == 1,
	
			(* --------------------------------------------------------------------------------
			   One network
			   -------------------------------------------------------------------------------- *)		

			weights = networks[[1]];
    		hiddenWeights = weights[[1]];
			outputWeights = weights[[2]];
			(* Transform original input *)
			scaledInputs = CIP`DataTransformation`ScaleDataMatrix[{input}, dataSetScaleInfo[[1]]];
			outputs = GetInternalPerceptronOutputs[scaledInputs, hiddenWeights, outputWeights];
			Return[CIP`Utility`GetPositionOfMaximumValue[outputs[[1]]]],
			
			(* --------------------------------------------------------------------------------
			   Multiple networks (with ONE output value each)
			   -------------------------------------------------------------------------------- *)		

			combinedOutputs =
				Table[
					weights = networks[[i]];
		    		hiddenWeights = weights[[1]];
					outputWeights = weights[[2]];
					(* Transform original input *)
					scaledInputs = CIP`DataTransformation`ScaleDataMatrix[{input}, dataSetScaleInfo[[1]]];
					outputs = GetInternalPerceptronOutputs[scaledInputs, hiddenWeights, outputWeights];
					outputs[[1, 1]],
					
					{i, Length[networks]}
				];
			Return[CIP`Utility`GetPositionOfMaximumValue[combinedOutputs]]
		]
	];

CalculatePerceptronClassNumbers[

	(* Returns class numbers for specified inputs for 3-Layer-True-Unit classification perceptron with specified weights.

	   Returns:
	   {class number of input1, class number of input2, ...} *)

    
    (* {inputsInOriginalUnit1, inputsInOriginalUnit2, ...}
        inputsInOriginalUnit: {inputValueInOriginalUnit1, inputValueInOriginalUnit2, ...} *)
    inputs_/;MatrixQ[inputs, NumberQ],
        
  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			combinedOutputs,
			correspondingOutput,
			hiddenWeights,
			i,
			networks,
			scaledInputs,
			outputs,
			outputWeights,
			dataSetScaleInfo,
			weights
		},

    	networks = perceptronInfo[[1]];
    	dataSetScaleInfo = perceptronInfo[[2]];

		If[Length[networks] == 1,
	
			(* --------------------------------------------------------------------------------
			   One network
			   -------------------------------------------------------------------------------- *)		

			weights = networks[[1]];
    		hiddenWeights = weights[[1]];
			outputWeights = weights[[2]];
			(* Transform original inputs *)
			scaledInputs = CIP`DataTransformation`ScaleDataMatrix[inputs, dataSetScaleInfo[[1]]];
			outputs = GetInternalPerceptronOutputs[scaledInputs, hiddenWeights, outputWeights];
			Return[
				Table[CIP`Utility`GetPositionOfMaximumValue[outputs[[i]]], {i, Length[outputs]}]
			],
			
			(* --------------------------------------------------------------------------------
			   Multiple networks (with ONE output value each)
			   -------------------------------------------------------------------------------- *)		

			combinedOutputs =
				Table[
					weights = networks[[i]];
		    		hiddenWeights = weights[[1]];
					outputWeights = weights[[2]];
					(* Transform original input *)
					scaledInputs = CIP`DataTransformation`ScaleDataMatrix[inputs, dataSetScaleInfo[[1]]];
					outputs = GetInternalPerceptronOutputs[scaledInputs, hiddenWeights, outputWeights];
					Flatten[outputs],
					
					{i, Length[networks]}
				];
			Return[
				Table[
					correspondingOutput = combinedOutputs[[All, i]];
					CIP`Utility`GetPositionOfMaximumValue[correspondingOutput],
				
					{i, Length[First[combinedOutputs]]}
				]
			]
		]
	];

CalculatePerceptronCorrectClassificationInPercent[

	(* Returns correct classification in percent for classification data set.

	   Returns: 
	   Correct classification in percent for classification data set *)


	(* classificationDataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} 
	   outputValue: 0/1
	   Data set must be a classification data set, i.e. the output components must 0/1 code a class,
	   i.e. class 4 of 5 must be coded {0, 0, 0, 1, 0} *)
    classificationDataSet_,

  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			pureFunction
		},

		pureFunction = Function[inputs, CalculatePerceptronClassNumbers[inputs, perceptronInfo]];
		Return[CIP`Utility`GetCorrectClassificationInPercent[classificationDataSet, pureFunction]]
	];

CalculatePerceptronDataSetRmse[

	(* Returns RMSE of data set.

	   Returns: 
	   RMSE of data set *)


	(* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} *)
    dataSet_,

  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			pureFunction,
			rmse
		},

		pureFunction = Function[inputs, CalculatePerceptronOutputs[inputs, perceptronInfo]];
		rmse = Sqrt[CIP`Utility`GetMeanSquaredError[dataSet, pureFunction]];
		Return[rmse]
	];

CalculatePerceptronOutput[

	(* Calculates output for specified input for specified 3-Layer-True-Unit perceptron.

	   Returns:
	   output: {transformedValueOfOutput1, transformedValueOfOutput2, ...} *)

    
    (* Input in original units: {inputValueInOriginalUnit1, inputValueInOriginalUnit2, ...} *)
    input_/;VectorQ[input, NumberQ],
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			combinedOutputs,
			dataMatrixScaleInfo,
			dataSetScaleInfo,
			hiddenWeights,
			i,
			networks,
			outputsInOriginalUnits,
			scaledOutputs,
			outputWeights,
			scaledInputs,
			weights
		},
    
    	networks = perceptronInfo[[1]];
    	dataSetScaleInfo = perceptronInfo[[2]];

		If[Length[networks] == 1,
	
			(* --------------------------------------------------------------------------------
			   One network (with multiple output values)
			   -------------------------------------------------------------------------------- *)		

			weights = networks[[1]];
    		hiddenWeights = weights[[1]];
			outputWeights = weights[[2]];
			(* Transform original input *)
			scaledInputs = CIP`DataTransformation`ScaleDataMatrix[{input}, dataSetScaleInfo[[1]]];
			scaledOutputs = GetInternalPerceptronOutputs[scaledInputs, hiddenWeights, outputWeights];
			(* Transform outputs to original units *)
			outputsInOriginalUnits = CIP`DataTransformation`ScaleDataMatrixReverse[scaledOutputs, dataSetScaleInfo[[2]]];
			Return[First[outputsInOriginalUnits]],
			
			(* --------------------------------------------------------------------------------
			   Multiple networks (with ONE output value each)
			   -------------------------------------------------------------------------------- *)		

			combinedOutputs =
				Table[
					weights = networks[[i]];
		    		hiddenWeights = weights[[1]];
					outputWeights = weights[[2]];
					(* Transform original input *)
					scaledInputs = CIP`DataTransformation`ScaleDataMatrix[{input}, dataSetScaleInfo[[1]]];
					scaledOutputs = GetInternalPerceptronOutputs[scaledInputs, hiddenWeights, outputWeights];

					(* Transform outputs to original units:
					   dataSetScaleInfo: {dataMatrixScaleInfo for inputs, dataMatrixScaleInfo for outputs} 
					   dataMatrixScaleInfo: {minMaxList, targetInterval} *)					
					dataMatrixScaleInfo = {{dataSetScaleInfo[[2, 1, i]]}, dataSetScaleInfo[[2, 2]]};
					outputsInOriginalUnits = CIP`DataTransformation`ScaleDataMatrixReverse[scaledOutputs, dataMatrixScaleInfo];
					outputsInOriginalUnits[[1, 1]],
					
					{i, Length[networks]}
				];
			Return[combinedOutputs]
		]
	];

CalculatePerceptronOutputs[

	(* Calculates outputs for specified inputs for specified 3-Layer-True-Unit perceptron.

	   Returns:
	   outputs: {output1, output2, ...} 
	   output: {transformedValueOfOutput1, transformedValueOfOutput1, ...} *)

    
    (* {inputsInOriginalUnit1, inputsInOriginalUnit2, ...}
        inputsInOriginalUnit: {inputValueInOriginalUnit1, inputValueInOriginalUnit2, ...} *)
    inputs_/;MatrixQ[inputs, NumberQ],
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			combinedOutputs,
			dataMatrixScaleInfo,
			dataSetScaleInfo,
			hiddenWeights,
			i,
			networks,
			outputsInOriginalUnits,
			scaledOutputs,
			outputWeights,
			scaledInputs,
			weights
		},
		
    	networks = perceptronInfo[[1]];
    	dataSetScaleInfo = perceptronInfo[[2]];

		If[Length[networks] == 1,
	
			(* --------------------------------------------------------------------------------
			   One network (with multiple output values)
			   -------------------------------------------------------------------------------- *)		

			weights = networks[[1]];
    		hiddenWeights = weights[[1]];
			outputWeights = weights[[2]];
			(* Transform original inputs *)
			scaledInputs = CIP`DataTransformation`ScaleDataMatrix[inputs, dataSetScaleInfo[[1]]];
			scaledOutputs = GetInternalPerceptronOutputs[scaledInputs, hiddenWeights, outputWeights];
			(* Transform outputs to original units *)
			outputsInOriginalUnits = CIP`DataTransformation`ScaleDataMatrixReverse[scaledOutputs, dataSetScaleInfo[[2]]];
			Return[outputsInOriginalUnits],
			
			(* --------------------------------------------------------------------------------
			   Multiple networks (with ONE output value each)
			   -------------------------------------------------------------------------------- *)		

			combinedOutputs =
				Table[
					weights = networks[[i]];
		    		hiddenWeights = weights[[1]];
					outputWeights = weights[[2]];
					(* Transform original input *)
					scaledInputs = CIP`DataTransformation`ScaleDataMatrix[inputs, dataSetScaleInfo[[1]]];
					scaledOutputs = GetInternalPerceptronOutputs[scaledInputs, hiddenWeights, outputWeights];

					(* Transform outputs to original units:
					   dataSetScaleInfo: {dataMatrixScaleInfo for inputs, dataMatrixScaleInfo for outputs} 
					   dataMatrixScaleInfo: {minMaxList, targetInterval} *)					
					dataMatrixScaleInfo = {{dataSetScaleInfo[[2, 1, i]]}, dataSetScaleInfo[[2, 2]]};
					outputsInOriginalUnits = CIP`DataTransformation`ScaleDataMatrixReverse[scaledOutputs, dataMatrixScaleInfo];
					Flatten[outputsInOriginalUnits],
					
					{i, Length[networks]}
				];
			Return[Transpose[combinedOutputs]]
		]
	];

CrossoverChromosomes[

	(* Returns 2 chromosomes after random crossover between chromosomes and random mutation of each chromosome.
	   NOTE: Uses random number. A possible seed must be set in superior methods.

	   Returns:
	  {chromosome1, chromosome2}
	   chromosome: {hiddenWeights, outputWeights} *)

    
    (* Chromosome has form: {hiddenWeights, outputWeights} *)
    chromosome1_,
    
    (* Chromosome has form: {hiddenWeights, outputWeights} *)
    chromosome2_,
    
    crossoverProbability_?NumberQ,
    
    mutationProbability_?NumberQ,
    
    (* Mutated value will be in interval -mutatedValueBound <= mutated value <= +mutatedValueBound *)
    mutatedValueBound_?NumberQ
    
	] := 
	
	Module[
    
		{
			i,
			randomNumber,
			randomPosition1,
			randomPosition2,
			pos1,
			pos2,
			xOverStart,
			xOverEnd,
			newChromosome1,
			newChromosome2
		},
    
		randomNumber = RandomReal[];
    
		If[randomNumber <= crossoverProbability,
      
			(* ----------------------------------------------------------------------------- *)
			(* Perform crossover and mutation: First choose layer : Hidden or output weights *)
			(* ----------------------------------------------------------------------------- *)
			randomPosition1 = RandomInteger[{1, 2}];
			(* Second choose neuron : Hidden or output neuron *)
			randomPosition2 = RandomInteger[{1, Length[chromosome1[[randomPosition1]] ]}];
			(* Determine positions for crossover start and end *)
			pos1 = RandomInteger[{1, Length[chromosome1[[randomPosition1, randomPosition2]] ]}];
			pos2 = pos1;
			While[pos2 == pos1, 
				pos2 = RandomInteger[{1, Length[chromosome1[[randomPosition1, randomPosition2]] ]}]
			];
			xOverStart = Min[pos1, pos2];
			xOverEnd = Max[pos1, pos2];
			(* Perform crossover *)
			newChromosome1 = chromosome1;
			Do[
				newChromosome1 = ReplacePart[newChromosome1, {randomPosition1, randomPosition2, i} -> chromosome2[[randomPosition1, randomPosition2, i]]],
        
				{i, xOverStart, xOverEnd}
			];
			newChromosome2 = chromosome2;
			Do[
				newChromosome2 = ReplacePart[newChromosome2, {randomPosition1, randomPosition2, i} -> chromosome1[[randomPosition1, randomPosition2, i]]],
        
				{i, xOverStart, xOverEnd}
			];
			Return[
				{
					MutateChromosome[newChromosome1, mutationProbability, mutatedValueBound],
          			MutateChromosome[newChromosome2, mutationProbability, mutatedValueBound]
				}
			],
      
			(* ----------------------------------------------------------------------------- *)
			(* No crossover, only mutation *)
			(* ----------------------------------------------------------------------------- *)
			Return[
				{
					MutateChromosome[chromosome1, mutationProbability, mutatedValueBound],
					MutateChromosome[chromosome2, mutationProbability, mutatedValueBound]
				}
			]
		]
	];

FitMultiplePerceptrons[

	(* Training of multiple (1 perceptron per output component of data set) 3-Layer True-Unit Perceptron.
	
	   Returns:
	   perceptronInfo (see "Frequently used data structures") *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,
	
	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,
	
	(* Options *)
	opts___

	] :=
  
	Module[
    
		{
			crossoverProbability,
			dataSetScaleInfo,
			targetInterval,
			i,
			initialNetworks,
			initialWeights,
			learningParameterMin,
			learningParameterMax,
			maximumNumberOfIterations,
			minimizationPrecision,
			momentumParameter,
			multipleTestSet,
			multipleTrainingSet,
			mutationProbability,
			networks,
			numberOfIterationsToImprove,
			perceptronInfo,
			perceptronTrainingResults,
			populationSize,
			randomValueInitialization,
			reportIteration,
			testSet,
			optimizationMethod,
			trainingSet,
			weightsValueLimit
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		reportIteration = PerceptronOptionReportIteration/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* ----------------------------------------------------------------------------------------------------
		   Initialization
		   ---------------------------------------------------------------------------------------------------- *)
		dataSetScaleInfo = CIP`DataTransformation`GetDataSetScaleInfoForTrainingAndTestSet[
			trainingAndTestSet,
			DataTransformationOptionTargetInterval -> targetInterval
		];
		trainingSet = trainingAndTestSet[[1]];
		testSet = trainingAndTestSet[[2]];
		multipleTrainingSet = CIP`DataTransformation`TransformDataSetToMultipleDataSet[trainingSet];
		If[Length[testSet] > 0,
			
			multipleTestSet = CIP`DataTransformation`TransformDataSetToMultipleDataSet[testSet],
			
			multipleTestSet = Table[{}, {i, Length[multipleTrainingSet]}]
		];

		(* ----------------------------------------------------------------------------------------------------
		   Training
		   ---------------------------------------------------------------------------------------------------- *)
		networks = {};
		perceptronTrainingResults = {};
		Do[
			(* If initial networks are available overwrite initialWeights *)
			If[Length[initialNetworks] > 0 && Length[initialNetworks] == Length[multipleTrainingSet],
				initialWeights = initialNetworks[[i]];
			];
			perceptronInfo = 
				FitSinglePerceptron[
					{multipleTrainingSet[[i]], multipleTestSet[[i]]},
					numberOfHiddenNeurons,
	    			PerceptronOptionOptimizationMethod -> optimizationMethod,
					PerceptronOptionInitialWeights -> initialWeights,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
					PerceptronOptionMinimizationPrecision -> minimizationPrecision,
					PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
		 			PerceptronOptionReportIteration -> reportIteration,
					PerceptronOptionLearningParameterMin -> learningParameterMin,
					PerceptronOptionLearningParameterMax -> learningParameterMax,
					PerceptronOptionMomentumParameter -> momentumParameter,
					PerceptronOptionPopulationSize -> populationSize,
					PerceptronOptionCrossoverProbability -> crossoverProbability,
					PerceptronOptionMutationProbability -> mutationProbability,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				];
			AppendTo[networks, perceptronInfo[[1, 1]]];
			AppendTo[perceptronTrainingResults, perceptronInfo[[3, 1]]],
			
			{i, Length[multipleTrainingSet]}
		];

		(* ----------------------------------------------------------------------------------------------------
		   Return perceptronInfo
		   ---------------------------------------------------------------------------------------------------- *)
		Return[{networks, dataSetScaleInfo, perceptronTrainingResults}]		
	];

FitPerceptron[

	(* Training of single or multiple 3-Layer True-Unit Perceptron(s).

	   Returns:
	   perceptronInfo (see "Frequently used data structures") *)


	(* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} *)
    dataSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,

	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			crossoverProbability,
			initialNetworks,
			initialWeights,
			weightsValueLimit,
			learningParameterMin,
			learningParameterMax,
			maximumNumberOfIterations,
			minimizationPrecision,
			momentumParameter,
			multiplePerceptrons,
			mutationProbability,
			numberOfIterationsToImprove,
			populationSize,
			randomValueInitialization,
			reportIteration,
			targetInterval,
			testSet,
			trainingAndTestSet,
			optimizationMethod
		},
    
		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
	    testSet = PerceptronOptionTestSet/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		reportIteration = PerceptronOptionReportIteration/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];
		
		(* ----------------------------------------------------------------------------------------------------
		   Switch training method
		   ---------------------------------------------------------------------------------------------------- *)
		trainingAndTestSet = {dataSet, testSet};
		
		If[multiplePerceptrons,
			
			Return[
				FitMultiplePerceptrons[
					trainingAndTestSet,
					numberOfHiddenNeurons,
	    			PerceptronOptionOptimizationMethod -> optimizationMethod,
					PerceptronOptionInitialWeights -> initialWeights,
					PerceptronOptionInitialNetworks -> initialNetworks,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
					PerceptronOptionMinimizationPrecision -> minimizationPrecision,
					PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
		 			PerceptronOptionReportIteration -> reportIteration,
					PerceptronOptionLearningParameterMin -> learningParameterMin,
					PerceptronOptionLearningParameterMax -> learningParameterMax,
					PerceptronOptionMomentumParameter -> momentumParameter,
					PerceptronOptionPopulationSize -> populationSize,
					PerceptronOptionCrossoverProbability -> crossoverProbability,
					PerceptronOptionMutationProbability -> mutationProbability,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				]
			],

			Return[
				FitSinglePerceptron[
					trainingAndTestSet,
					numberOfHiddenNeurons,
	    			PerceptronOptionOptimizationMethod -> optimizationMethod,
					PerceptronOptionInitialWeights -> initialWeights,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
					PerceptronOptionMinimizationPrecision -> minimizationPrecision,
					PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
		 			PerceptronOptionReportIteration -> reportIteration,
					PerceptronOptionLearningParameterMin -> learningParameterMin,
					PerceptronOptionLearningParameterMax -> learningParameterMax,
					PerceptronOptionMomentumParameter -> momentumParameter,
					PerceptronOptionPopulationSize -> populationSize,
					PerceptronOptionCrossoverProbability -> crossoverProbability,
					PerceptronOptionMutationProbability -> mutationProbability,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				]
			]
		]
	];

FitPerceptronSeries[

	(* Trains of a series of single or multiple 3-Layer True-Unit Perceptron(s).

	   Returns:
	   perceptronInfoList: {perceptronInfo1, perceptronInfo2, ...}
	   perceptronInfo[[i]] corresponds to numberOfHiddenNeuronsList[[i]]
	   (see "Frequently used data structures") *)


	(* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} *)
    dataSet_,

	(* List with numbers of hidden neurons *)
	numberOfHiddenNeuronsList_/;VectorQ[numberOfHiddenNeuronsList, IntegerQ],

	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			i,
			crossoverProbability,
			initialNetworks,
			initialWeights,
			weightsValueLimit,
			learningParameterMin,
			learningParameterMax,
			maximumNumberOfIterations,
			minimizationPrecision,
			momentumParameter,
			multiplePerceptrons,
			mutationProbability,
			numberOfIterationsToImprove,
			populationSize,
			randomValueInitialization,
			reportIteration,
			targetInterval,
			testSet,
			optimizationMethod
		},
    
		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
	    testSet = PerceptronOptionTestSet/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		reportIteration = PerceptronOptionReportIteration/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		Return[
			Table[
				FitPerceptron[
					dataSet,
					numberOfHiddenNeuronsList[[i]],
					PerceptronOptionTestSet -> testSet,
					PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
	    			PerceptronOptionOptimizationMethod -> optimizationMethod,
					PerceptronOptionInitialWeights -> initialWeights,
					PerceptronOptionInitialNetworks -> initialNetworks,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
					PerceptronOptionMinimizationPrecision -> minimizationPrecision,
					PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
		 			PerceptronOptionReportIteration -> reportIteration,
					PerceptronOptionLearningParameterMin -> learningParameterMin,
					PerceptronOptionLearningParameterMax -> learningParameterMax,
					PerceptronOptionMomentumParameter -> momentumParameter,
					PerceptronOptionPopulationSize -> populationSize,
					PerceptronOptionCrossoverProbability -> crossoverProbability,
					PerceptronOptionMutationProbability -> mutationProbability,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				],
				
				{i, Length[numberOfHiddenNeuronsList]}
			]			
		]
	];

FitPerceptronWithBP[

	(* Training of 3-Layer True-Unit Perceptron with standard backpropagation plus momentum.

	   Returns:
	   perceptronInfo (see "Frequently used data structures") *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,

	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			dataSetScaleInfo,
			targetInterval,
			bestEpoch,
			bestMeanSquaredErrorOfTrainingSet,
			bestWeights,
			desiredOutputs,
			hiddenDelta,
			hiddenLastDelta,
			hiddenOutputs,
			hiddenWeights,
			i,
			initialWeights,
			weightsValueLimit,
			internalPerceptronOptionReportIteration,
			isReported,
			k,
			lastPerceptronOptionReportIteration,
			learningParameter,
			learningParameterMax,
			learningParameterMin,
			maximumNumberOfIterations,
			meanSquaredError,
			momentumParameter,
			numberOfInputs,
			numberOfIterationsToImprove,
			numberOfOutputs,
			numberOfTestPairs,
			numberOfTrainingPairs,
			outputDelta,
			outputErrors,
			outputLastDelta,
			outputs,
			outputWeights,
			randomValueInitialization,
			reportIteration,
			scaledTestSet,
			scaledTrainingAndTestSet,
			scaledTrainingSet,
			testMeanSquaredErrorList,
			trainingInputs,
			trainingInputOutputPair,
			trainingList,
			trainingMeanSquaredErrorList,
			trueUnitHiddenOutputs
		},
    
		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		reportIteration = PerceptronOptionReportIteration/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* ----------------------------------------------------------------------------------------------------
		   Initialization
		   ---------------------------------------------------------------------------------------------------- *)
		(* Set seed for random numbers if necessary *)
		If[randomValueInitialization == "Seed", SeedRandom[1], SeedRandom[]];

		dataSetScaleInfo = CIP`DataTransformation`GetDataSetScaleInfoForTrainingAndTestSet[
			trainingAndTestSet,
			DataTransformationOptionTargetInterval -> targetInterval
		];
    
    	(* Set training and test set *)
    	(* Set training and test set *)
    	scaledTrainingAndTestSet = CIP`DataTransformation`ScaleTrainingAndTestSet[trainingAndTestSet, dataSetScaleInfo];
    	scaledTrainingSet = scaledTrainingAndTestSet[[1]];
    	scaledTestSet = scaledTrainingAndTestSet[[2]];
    
	    (* Initialization *)
	    If[reportIteration > maximumNumberOfIterations, reportIteration = maximumNumberOfIterations];
	    internalPerceptronOptionReportIteration = reportIteration;
	    numberOfInputs = First[Dimensions[scaledTrainingSet[[1, 1]] ]];
	    numberOfOutputs = First[Dimensions[scaledTrainingSet[[1, 2]] ]];
	    bestWeights = {};
	    bestMeanSquaredErrorOfTrainingSet = Infinity;
    
		(* Initialization of hidden and output weights *)
	    If[Length[initialWeights] > 0,
      
			(* Use specified weights as initial weights *)
			hiddenWeights = initialWeights[[1]];
			outputWeights = initialWeights[[2]],
      
			(* Use random weights as initial weights *)
			(* 'True unit' : 'numberOfInputs + 1' and 'numberOfHiddenNeurons + 1' *)
			hiddenWeights = Table[RandomReal[{-weightsValueLimit, weightsValueLimit}, numberOfInputs + 1], {numberOfHiddenNeurons}];
			outputWeights = Table[RandomReal[{-weightsValueLimit, weightsValueLimit}, numberOfHiddenNeurons + 1], {numberOfOutputs}]
		];
    
		(* 'True unit' : 'numberOfInputs + 1' and 'numberOfHiddenNeurons + 1' *)
		hiddenLastDelta = Table[Table[0.0, {numberOfInputs + 1}], {numberOfHiddenNeurons}];
		outputLastDelta = Table[Table[0.0, {numberOfHiddenNeurons + 1}], {numberOfOutputs}];
    
	    (* Get length of training and test set *)
	    numberOfTrainingPairs = Length[scaledTrainingSet];
	    numberOfTestPairs = Length[scaledTestSet];
    
		(* Initialize training protocol *)
		trainingMeanSquaredErrorList = {{0, GetInternalMeanSquaredErrorOfPerceptron[scaledTrainingSet, hiddenWeights, outputWeights]}};
		If[numberOfTestPairs > 0,
		
			(* Test set exists *)
			testMeanSquaredErrorList = {{0, GetInternalMeanSquaredErrorOfPerceptron[scaledTestSet, hiddenWeights, outputWeights]}},
		
			(* No test set*)
			testMeanSquaredErrorList = {}
		];
    
		(* ----------------------------------------------------------------------------------------------------
		   Training
		   ---------------------------------------------------------------------------------------------------- *)
    	(* Main training loop over all epochs *)
		Do[
			trainingList = Combinatorica`RandomPermutation[numberOfTrainingPairs];
			If[learningParameterMax == learningParameterMin,
        
				learningParameter = learningParameterMin,
        
				learningParameter = learningParameterMax - i*(learningParameterMax - learningParameterMin)/maximumNumberOfIterations
			];
    		(* One epoch loop over all training pairs *)
			Do[
        
				(* Select training input/output pair *)
		        trainingInputOutputPair = scaledTrainingSet[[ trainingList[[k]] ]];
		        (* Add 'true unit' to training inputs *)
		        trainingInputs = Append[trainingInputOutputPair[[1]], 1.0];
		        desiredOutputs = trainingInputOutputPair[[2]];
        
		        (* Forward pass *)
		        hiddenOutputs = SigmoidFunction[hiddenWeights.trainingInputs];
		        (* Add 'true unit' to hidden outputs *)
		        trueUnitHiddenOutputs = Append[hiddenOutputs, 1.0];
		        outputs = SigmoidFunction[outputWeights.trueUnitHiddenOutputs];
        
		        (* Determine errors and deltas for weight update *)
		        outputErrors = desiredOutputs - outputs;
		        outputDelta = outputErrors*(outputs*(1 - outputs));
		        hiddenDelta = (trueUnitHiddenOutputs*(1 - trueUnitHiddenOutputs))*Transpose[outputWeights].outputDelta;
        
		        (* Update weights *)
		        outputLastDelta = learningParameter*Outer[Times, outputDelta, trueUnitHiddenOutputs] + momentumParameter*outputLastDelta;
		        outputWeights += outputLastDelta;
		        hiddenLastDelta = learningParameter*Drop[Outer[Times, hiddenDelta, trainingInputs], -1] + momentumParameter*hiddenLastDelta;
		        hiddenWeights += hiddenLastDelta,
        
				{k, numberOfTrainingPairs}
        
			]; (* End 'Do' {k, numberOfTrainingPairs} *)
      
			(* Calculate mean squared error of training set of epoch *)
			meanSquaredError = GetInternalMeanSquaredErrorOfPerceptron[scaledTrainingSet, hiddenWeights, outputWeights];
      
			(* Compare to best mean squared error value and save *)
			If[meanSquaredError < bestMeanSquaredErrorOfTrainingSet,
				bestEpoch = i;
				bestMeanSquaredErrorOfTrainingSet = meanSquaredError;
				bestWeights = {hiddenWeights, outputWeights}
			];
      
			(* Report training *)
			If[internalPerceptronOptionReportIteration == i,
		
				(* Report taining of this epoch *)		
				AppendTo[trainingMeanSquaredErrorList, {i, bestMeanSquaredErrorOfTrainingSet}];
				If[numberOfTestPairs > 0,
					AppendTo[testMeanSquaredErrorList, {i, GetInternalMeanSquaredErrorOfPerceptron[scaledTestSet, bestWeights[[1]], bestWeights[[2]]]}]
				];
				internalPerceptronOptionReportIteration += reportIteration;
				isReported = True,
				
				(* Do NOT report taining of this epoch *)		
				isReported = False
			];
      
  			(* Check termination condition because of numberOfIterationsToImprove *)
			If[i > (bestEpoch + numberOfIterationsToImprove),
				lastPerceptronOptionReportIteration = i;
				Break[]
			];

			(* Set lastPerceptronOptionReportIteration at end of loop *)
			If[i == maximumNumberOfIterations,
				lastPerceptronOptionReportIteration = i
			],
      
			{i, maximumNumberOfIterations}
		]; (* End 'Do' {i, maximumNumberOfIterations} *)
		
		(* ----------------------------------------------------------------------------------------------------
		   Set results
		   ---------------------------------------------------------------------------------------------------- *)
		If[!isReported,
			AppendTo[trainingMeanSquaredErrorList, {lastPerceptronOptionReportIteration, bestMeanSquaredErrorOfTrainingSet}];
			If[numberOfTestPairs > 0,
				AppendTo[testMeanSquaredErrorList, {lastPerceptronOptionReportIteration, GetInternalMeanSquaredErrorOfPerceptron[scaledTestSet, bestWeights[[1]], bestWeights[[2]]]}]
			];
		];
		
		(* Return perceptronInfo *)
		Return[
			{
				{bestWeights},
				dataSetScaleInfo,
				{{trainingMeanSquaredErrorList, testMeanSquaredErrorList}},
				"BackpropagationPlusMomentum"
			}
		]		
	];

FitPerceptronWithFindMinimum[

	(* Training of 3-Layer True-Unit Perceptron with FindMinimum and "ConjugateGradient" method.
	
	   Returns:
	   perceptronInfo (see "Frequently used data structures") *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,

	(* Options *)
	opts___

	] :=
  
	Module[
    
		{
			dataSetScaleInfo,
			targetInterval,
			hiddenWeights,
			hiddenWeightsVariables,
			i,
			initialWeights,
			inputs,
			k,
			lastTrainingStep,
			maximumNumberOfIterations,
			meanSquaredError,
			minimizationPrecision,
			minimizationStep,
			minimumInfo,
			numberOfInputs,
			numberOfIOPairs,
			numberOfOutputs,
			outputs,
			outputWeights,
			outputWeightsVariables,
			perceptronOutputs,
			randomValueInitialization,
			reportIteration,
			reportIterationCounter,
			scaledTrainingAndTestSet,
			scaledTrainingSet,
			scaledTestSet,
			startVariables,
			stepNumber,
			steps,
			testMeanSquaredErrorList,
			trainingMeanSquaredErrorList,
			wHiddenToOutput,
			wInputToHidden,
			weightsRules,
			weightsValueLimit,
			weightsVariables,
			weights
		},


		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
	    minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
	    maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
	    reportIteration = PerceptronOptionReportIteration/.{opts}/.Options[PerceptronOptionsOptimization];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* ----------------------------------------------------------------------------------------------------
		   Initialization
		   ---------------------------------------------------------------------------------------------------- *)
		(* Set seed for random numbers if necessary *)
		If[randomValueInitialization == "Seed", SeedRandom[1], SeedRandom[]];

		dataSetScaleInfo = CIP`DataTransformation`GetDataSetScaleInfoForTrainingAndTestSet[
			trainingAndTestSet,
			DataTransformationOptionTargetInterval -> targetInterval
		];
    
    	(* Set training and test set and related variables *)
    	scaledTrainingAndTestSet = CIP`DataTransformation`ScaleTrainingAndTestSet[trainingAndTestSet, dataSetScaleInfo];
    	scaledTrainingSet = scaledTrainingAndTestSet[[1]];
    	numberOfIOPairs = Length[scaledTrainingSet];
    	inputs = CIP`Utility`GetInputsOfDataSet[scaledTrainingSet];
    	outputs = CIP`Utility`GetOutputsOfDataSet[scaledTrainingSet];
    	scaledTestSet = scaledTrainingAndTestSet[[2]];
    
	    (* Network structure *)
	    numberOfInputs = First[Dimensions[scaledTrainingSet[[1, 1]]]];
	    numberOfOutputs = First[Dimensions[scaledTrainingSet[[1, 2]]]];

	    (* Initialize hidden and output weights *)
	    If[Length[initialWeights] > 0,
      
			(* Use specified weights as initial weights *)
			hiddenWeights = initialWeights[[1]];
			outputWeights = initialWeights[[2]],
      
			(* Use random weights as initial weights *)
			(* 'True unit' : 'numberOfInputs + 1' and 'numberOfHiddenNeurons + 1' *)
			hiddenWeights = Table[RandomReal[{-weightsValueLimit, weightsValueLimit}, numberOfInputs + 1], {numberOfHiddenNeurons}];
			outputWeights = Table[RandomReal[{-weightsValueLimit, weightsValueLimit}, numberOfHiddenNeurons + 1], {numberOfOutputs}]
		];

		(* Initialize training protocol *)
		trainingMeanSquaredErrorList = {{0, GetInternalMeanSquaredErrorOfPerceptron[scaledTrainingSet, hiddenWeights, outputWeights]}};
		If[Length[scaledTestSet] > 0,
		
			(* Test set exists *)
			testMeanSquaredErrorList = {{0, GetInternalMeanSquaredErrorOfPerceptron[scaledTestSet, hiddenWeights, outputWeights]}},
		
			(* No test set*)
			testMeanSquaredErrorList = {}
		];

		(* ----------------------------------------------------------------------------------------------------
		   Definition of start variables
		   ---------------------------------------------------------------------------------------------------- *)
		startVariables = GetWeightsStartVariables[numberOfInputs, numberOfHiddenNeurons, numberOfOutputs, wInputToHidden, wHiddenToOutput, hiddenWeights, outputWeights];

		(* ----------------------------------------------------------------------------------------------------
		   Mean squared error function to minimize
		   ---------------------------------------------------------------------------------------------------- *)
	    (* Map: Add 'true unit' *)
	    weightsVariables = GetWeightsVariables[numberOfInputs, numberOfHiddenNeurons, numberOfOutputs, wInputToHidden, wHiddenToOutput];
	    hiddenWeightsVariables = weightsVariables[[1]];
	    outputWeightsVariables = weightsVariables[[2]];
	    perceptronOutputs = SigmoidFunction[Map[Append[#, 1] &, SigmoidFunction[Map[Append[#, 1] &, inputs].Transpose[hiddenWeightsVariables]]].Transpose[outputWeightsVariables]];
		meanSquaredError =
			Sum[
				Sum[
					(outputs[[i, k]] - perceptronOutputs[[i, k]])^2,
					
					{k, numberOfOutputs}
				],
					    
				{i, numberOfIOPairs}	
			]/numberOfIOPairs;

		(* ----------------------------------------------------------------------------------------------------
		   Find minimum
		   ---------------------------------------------------------------------------------------------------- *)
		steps = 0;
		reportIterationCounter = 0;
		minimumInfo = 
			Reap[FindMinimum[
				meanSquaredError, 
				startVariables, 
				Method -> "ConjugateGradient", 
				MaxIterations -> maximumNumberOfIterations, 
				WorkingPrecision -> MachinePrecision,
				AccuracyGoal -> minimizationPrecision, 
				PrecisionGoal -> minimizationPrecision, 
				StepMonitor :> 
					(
						steps++;
						reportIterationCounter++;
						If[reportIterationCounter == reportIteration, 
							reportIterationCounter = 0;
							Sow[{steps, weightsVariables}]
						]
					)
			]];
		weightsRules = minimumInfo[[1, 2]];

		(* ----------------------------------------------------------------------------------------------------
		   Set training protocol if necessary
		   ---------------------------------------------------------------------------------------------------- *)
		If[Length[minimumInfo[[2]]] > 0,
			Do[
				minimizationStep = minimumInfo[[2, 1, i]];
				stepNumber = minimizationStep[[1]];
				weights = minimizationStep[[2]];
				AppendTo[trainingMeanSquaredErrorList, {stepNumber, GetInternalMeanSquaredErrorOfPerceptron[scaledTrainingSet, weights[[1]], weights[[2]]]}];
				If[Length[scaledTestSet] > 0,
					(* Test set exists *)
					AppendTo[testMeanSquaredErrorList, {stepNumber, GetInternalMeanSquaredErrorOfPerceptron[scaledTestSet, weights[[1]], weights[[2]]]}]
				],
				
				{i, Length[minimumInfo[[2, 1]]]}
			]
		];
			
		(* ----------------------------------------------------------------------------------------------------
		   Set results
		   ---------------------------------------------------------------------------------------------------- *)
		weights = GetWeightsVariables[numberOfInputs, numberOfHiddenNeurons, numberOfOutputs, wInputToHidden, wHiddenToOutput]/.weightsRules;

		(* End of training protocol *)
		lastTrainingStep = Last[trainingMeanSquaredErrorList];
		If[lastTrainingStep[[1]] < steps,
			AppendTo[trainingMeanSquaredErrorList, {steps, GetInternalMeanSquaredErrorOfPerceptron[scaledTrainingSet, weights[[1]], weights[[2]]]}];
			If[Length[scaledTestSet] > 0,
				(* Test set exists *)
				AppendTo[testMeanSquaredErrorList, {steps, GetInternalMeanSquaredErrorOfPerceptron[scaledTestSet, weights[[1]], weights[[2]]]}]
			]
		];
		
		(* Return perceptronInfo *)
		Return[
			{
				{weights},
				dataSetScaleInfo,
				{{trainingMeanSquaredErrorList, testMeanSquaredErrorList}},
				"FindMinimum"
			}
		]		
	];

FitPerceptronWithNMinimize[

	(* Training of 3-Layer True-Unit Perceptron with NMinimize and "DifferentialEvolution".
	
	   Returns:
	   perceptronInfo (see "Frequently used data structures") *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,

	(* Options *)
	opts___

	] :=
  
	Module[
    
		{
			constraints,
			dataSetScaleInfo,
			flatWeightsVariables,
			targetInterval,
			hiddenWeightsVariables,
			i,
			inputs,
			k,
			lastTrainingStep,
			maximumNumberOfIterations,
			meanSquaredError,
			minimizationPrecision,
			minimizationStep,
			minimumInfo,
			numberOfInputs,
			numberOfIOPairs,
			numberOfOutputs,
			outputs,
			outputWeightsVariables,
			perceptronOutputs,
			randomValueInitialization,
			reportIteration,
			reportIterationCounter,
			scaledTrainingAndTestSet,
			scaledTrainingSet,
			scaledTestSet,
			stepNumber,
			steps,
			testMeanSquaredErrorList,
			trainingMeanSquaredErrorList,
			wHiddenToOutput,
			wInputToHidden,
			weightsRules,
			weightsValueLimit,
			weightsVariables,
			weights
		},


		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
	    minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
	    maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
	    reportIteration = PerceptronOptionReportIteration/.{opts}/.Options[PerceptronOptionsOptimization];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* ----------------------------------------------------------------------------------------------------
		   Initialization
		   ---------------------------------------------------------------------------------------------------- *)
		(* Set seed for random numbers if necessary *)
		If[randomValueInitialization == "Seed", SeedRandom[1], SeedRandom[]];

		dataSetScaleInfo = CIP`DataTransformation`GetDataSetScaleInfoForTrainingAndTestSet[
			trainingAndTestSet,
			DataTransformationOptionTargetInterval -> targetInterval
		];
    
    	(* Set training and test set and related variables *)
    	scaledTrainingAndTestSet = CIP`DataTransformation`ScaleTrainingAndTestSet[trainingAndTestSet, dataSetScaleInfo];
    	scaledTrainingSet = scaledTrainingAndTestSet[[1]];
    	numberOfIOPairs = Length[scaledTrainingSet];
    	inputs = CIP`Utility`GetInputsOfDataSet[scaledTrainingSet];
    	outputs = CIP`Utility`GetOutputsOfDataSet[scaledTrainingSet];
    	scaledTestSet = scaledTrainingAndTestSet[[2]];
    
	    (* Network structure *)
	    numberOfInputs = First[Dimensions[scaledTrainingSet[[1, 1]]]];
	    numberOfOutputs = First[Dimensions[scaledTrainingSet[[1, 2]]]];

		(* Initialize training protocol *)
		trainingMeanSquaredErrorList = {};
		testMeanSquaredErrorList = {};

		(* ----------------------------------------------------------------------------------------------------
		   Mean squared error function to minimize
		   ---------------------------------------------------------------------------------------------------- *)
	    (* Map: Add 'true unit' *)
	    weightsVariables = GetWeightsVariables[numberOfInputs, numberOfHiddenNeurons, numberOfOutputs, wInputToHidden, wHiddenToOutput];
	    hiddenWeightsVariables = weightsVariables[[1]];
	    outputWeightsVariables = weightsVariables[[2]];
	    perceptronOutputs = SigmoidFunction[Map[Append[#, 1] &, SigmoidFunction[Map[Append[#, 1] &, inputs].Transpose[hiddenWeightsVariables]]].Transpose[outputWeightsVariables]];
		meanSquaredError =
			Sum[
				Sum[
					(outputs[[i, k]] - perceptronOutputs[[i, k]])^2,
					
					{k, numberOfOutputs}
				],
					    
				{i, numberOfIOPairs}	
			]/numberOfIOPairs;

		(* ----------------------------------------------------------------------------------------------------
		   Set constraints for weights
		   ---------------------------------------------------------------------------------------------------- *)
		flatWeightsVariables = Flatten[weightsVariables];
		constraints = 
			Apply[And, 
				Table[
					-weightsValueLimit <= flatWeightsVariables[[i]] <= weightsValueLimit, 
					
					{i, Length[flatWeightsVariables]}
				]
			];

		(* ----------------------------------------------------------------------------------------------------
		   Find minimum
		   ---------------------------------------------------------------------------------------------------- *)
		steps = 0;
		reportIterationCounter = 0;
		minimumInfo = 
			Reap[NMinimize[
				{meanSquaredError, constraints}, 
				flatWeightsVariables, 
				Method -> "DifferentialEvolution", 
				MaxIterations -> maximumNumberOfIterations, 
				WorkingPrecision -> MachinePrecision,
				AccuracyGoal -> minimizationPrecision, 
				PrecisionGoal -> minimizationPrecision, 
				StepMonitor :> 
					(
						steps++;
						reportIterationCounter++;
						If[reportIterationCounter == reportIteration, 
							reportIterationCounter = 0;
							Sow[{steps, weightsVariables}]
						]
					)
			]];
		weightsRules = minimumInfo[[1, 2]];

		(* ----------------------------------------------------------------------------------------------------
		   Set training protocol if necessary
		   ---------------------------------------------------------------------------------------------------- *)
		If[Length[minimumInfo[[2]]] > 0,
			Do[
				minimizationStep = minimumInfo[[2, 1, i]];
				stepNumber = minimizationStep[[1]];
				weights = minimizationStep[[2]];
				AppendTo[trainingMeanSquaredErrorList, {stepNumber, GetInternalMeanSquaredErrorOfPerceptron[scaledTrainingSet, weights[[1]], weights[[2]]]}];
				If[Length[scaledTestSet] > 0,
					(* Test set exists *)
					AppendTo[testMeanSquaredErrorList, {stepNumber, GetInternalMeanSquaredErrorOfPerceptron[scaledTestSet, weights[[1]], weights[[2]]]}]
				],
				
				{i, Length[minimumInfo[[2, 1]]]}
			]
		];
			
		(* ----------------------------------------------------------------------------------------------------
		   Set results
		   ---------------------------------------------------------------------------------------------------- *)
		weights = GetWeightsVariables[numberOfInputs, numberOfHiddenNeurons, numberOfOutputs, wInputToHidden, wHiddenToOutput]/.weightsRules;

		(* End of training protocol *)
		lastTrainingStep = Last[trainingMeanSquaredErrorList];
		If[lastTrainingStep[[1]] < steps,
			AppendTo[trainingMeanSquaredErrorList, {steps, GetInternalMeanSquaredErrorOfPerceptron[scaledTrainingSet, weights[[1]], weights[[2]]]}];
			If[Length[scaledTestSet] > 0,
				(* Test set exists *)
				AppendTo[testMeanSquaredErrorList, {steps, GetInternalMeanSquaredErrorOfPerceptron[scaledTestSet, weights[[1]], weights[[2]]]}]
			]
		];
		
		(* Return perceptronInfo *)
		Return[
			{
				{weights},
				dataSetScaleInfo,
				{{trainingMeanSquaredErrorList, testMeanSquaredErrorList}},
				"NMinimize"
			}
		]		
	];

FitPerceptronWithGA[

	(* Training of 3-Layer True-Unit perceptron with Genetic Algorithm.

	   Returns:
	   perceptronInfo (see "Frequently used data structures") *)

	
	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			dataSetScaleInfo,
			targetInterval,
			bestGeneration,
			bestMeanSquaredErrorOfTrainingSet,
			crossoverProbability,
			fitnessList,
			fittestChromosome,
			i,
			initialWeights,
			weightsValueLimit,
			internalPerceptronOptionReportIteration,
			isReported,
			k,
			lastPerceptronOptionReportIteration,
			maximumNumberOfIterations,
			meanSquaredError,
			mutationProbability,
			numberOfInputs,
			numberOfIterationsToImprove,
			numberOfOutputs,
			numberOfTestPairs,
			population,
			populationSize,
			randomValueInitialization,
			reportIteration,
			scaledFitnessSum,
			scaledTestSet,
			scaledTrainingAndTestSet,
			scaledTrainingSet,
			testMeanSquaredErrorList,
			trainingMeanSquaredErrorList
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		reportIteration = PerceptronOptionReportIteration/.{opts}/.Options[PerceptronOptionsOptimization];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* ----------------------------------------------------------------------------------------------------
		   Initialization
		   ---------------------------------------------------------------------------------------------------- *)
		(* Set seed for random numbers if necessary *)
		If[randomValueInitialization == "Seed", SeedRandom[1], SeedRandom[]];

		dataSetScaleInfo = CIP`DataTransformation`GetDataSetScaleInfoForTrainingAndTestSet[
			trainingAndTestSet,
			DataTransformationOptionTargetInterval -> targetInterval
		];
    
    	(* Set training and test set *)
    	scaledTrainingAndTestSet = CIP`DataTransformation`ScaleTrainingAndTestSet[trainingAndTestSet, dataSetScaleInfo];
    	scaledTrainingSet = scaledTrainingAndTestSet[[1]];
    	scaledTestSet = scaledTrainingAndTestSet[[2]];
    
	    (* Initialization *)
	    If[reportIteration > maximumNumberOfIterations, reportIteration = maximumNumberOfIterations];
	    internalPerceptronOptionReportIteration = reportIteration;
	    numberOfInputs = First[Dimensions[scaledTrainingSet[[1, 1]] ]];
	    numberOfOutputs = First[Dimensions[scaledTrainingSet[[1, 2]] ]];
		trainingMeanSquaredErrorList = {};
		testMeanSquaredErrorList = {};
	    bestMeanSquaredErrorOfTrainingSet = Infinity;
    
		(* Create initial population of form {{{hiddenWeights}, {outputWeights}}, ...} *)
		population = 
			Table[
				{
					Table[RandomReal[{-weightsValueLimit, weightsValueLimit}, numberOfInputs + 1],{numberOfHiddenNeurons}],
					Table[RandomReal[{-weightsValueLimit, weightsValueLimit}, numberOfHiddenNeurons + 1],{numberOfOutputs}]
				},
        
				{populationSize}
			];
   
		(* Check if there are weights to be improved *)
		If[Length[initialWeights] > 0,
			(* Add weights to be improved to population *)
			AppendTo[population, initialWeights]
		];
    
		(* Get length of test set *)
		numberOfTestPairs = Length[scaledTestSet];
    
		(* ----------------------------------------------------------------------------------------------------
		   Training
		   ---------------------------------------------------------------------------------------------------- *)
		Do[
      
			(* Evaluate fitness of population *)
			fitnessList = 
				Table[
					1.0/GetInternalMeanSquaredErrorOfPerceptron[scaledTrainingSet, population[[k, 1]], population[[k, 2]]],
          
					{k, Length[population]}
				];
			scaledFitnessSum = CIP`Utility`GetScaledFitnessSumList[fitnessList];
      
			(* Determine fittest chromosome of form {{hiddenWeights}, {outputWeights}} *)
			fittestChromosome = population[[ First[Flatten[Position[fitnessList, Max[fitnessList], {1}, 1]]] ]];
      
			(* Calculate mean squared error of training set of generation *)
			meanSquaredError = GetInternalMeanSquaredErrorOfPerceptron[scaledTrainingSet, fittestChromosome[[1]], fittestChromosome[[2]]];
      
			(* Compare to best mean squared error value and save *)
			If[meanSquaredError < bestMeanSquaredErrorOfTrainingSet,
				bestGeneration = i;
				bestMeanSquaredErrorOfTrainingSet = meanSquaredError
			];
      
			(* Report training *)
			If[i == 1 || internalPerceptronOptionReportIteration == i,
				
				(* Report taining of this generation *)		
				AppendTo[trainingMeanSquaredErrorList, {i, bestMeanSquaredErrorOfTrainingSet}];
				If[numberOfTestPairs > 0,
					AppendTo[testMeanSquaredErrorList, {i, GetInternalMeanSquaredErrorOfPerceptron[scaledTestSet, fittestChromosome[[1]], fittestChromosome[[2]]]}]
				];
				If[internalPerceptronOptionReportIteration == i, 
					internalPerceptronOptionReportIteration += reportIteration
				];
				isReported = True,
				
				(* Do NOT report taining of this generation *)		
				isReported = False
			];
      
			(* Check termination condition because of numberOfIterationsToImprove or end of loop *)
			If[i > (bestGeneration + numberOfIterationsToImprove) || i == maximumNumberOfIterations,
				lastPerceptronOptionReportIteration = i;
				Break[]
			];

			(* Create new population: Roulette-wheel selection and crossover + mutation *)
			population = 
				Flatten[
					Table[
						CrossoverChromosomes[
							SelectChromosome[population, scaledFitnessSum], SelectChromosome[population, scaledFitnessSum], crossoverProbability, mutationProbability, weightsValueLimit
						],
            
						{CIP`Utility`GetNextHigherEvenIntegerNumber[populationSize]/2}
					], 1
				];
      
			(* Elitism : Add fittest chromosome of last epoch/generation *)
			AppendTo[population, fittestChromosome],
      
			{i, maximumNumberOfIterations}
      
		]; (* End 'Do' {i, maximumNumberOfIterations} *)

		(* ----------------------------------------------------------------------------------------------------
		   Results
		   ---------------------------------------------------------------------------------------------------- *)
		(* Report training if necessary *)
		If[!isReported,
			AppendTo[trainingMeanSquaredErrorList, {lastPerceptronOptionReportIteration, bestMeanSquaredErrorOfTrainingSet}];
			If[numberOfTestPairs > 0,
				AppendTo[testMeanSquaredErrorList, {lastPerceptronOptionReportIteration, GetInternalMeanSquaredErrorOfPerceptron[scaledTestSet, fittestChromosome[[1]], fittestChromosome[[2]]]}]
			];
		];
    
		(* Return perceptronInfo *)
		Return[
			{
				{fittestChromosome},
				dataSetScaleInfo,
				{{trainingMeanSquaredErrorList, testMeanSquaredErrorList}},
				"GeneticAlgorithm"
			}
		]
	];

FitSinglePerceptron[

	(* Training of single 3-Layer True-Unit Perceptron.

	   Returns:
	   perceptronInfo (see "Frequently used data structures") *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,

	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			crossoverProbability,
			initialWeights,
			weightsValueLimit,
			learningParameterMin,
			learningParameterMax,
			maximumNumberOfIterations,
			minimizationPrecision,
			momentumParameter,
			mutationProbability,
			numberOfIterationsToImprove,
			populationSize,
			randomValueInitialization,
			reportIteration,
			targetInterval,
			optimizationMethod
		},
    
		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		reportIteration = PerceptronOptionReportIteration/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];
		
		(* ----------------------------------------------------------------------------------------------------
		   Switch training method
		   ---------------------------------------------------------------------------------------------------- *)
		Switch[optimizationMethod,
			
			"FindMinimum",
			Return[
				FitPerceptronWithFindMinimum[
					trainingAndTestSet,
					numberOfHiddenNeurons,
					PerceptronOptionInitialWeights -> initialWeights,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
	    			PerceptronOptionMinimizationPrecision -> minimizationPrecision,
	    			PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionReportIteration -> reportIteration,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				]
			],
			
			"NMinimize",
			Return[
				FitPerceptronWithNMinimize[
					trainingAndTestSet,
					numberOfHiddenNeurons,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
	    			PerceptronOptionMinimizationPrecision -> minimizationPrecision,
	    			PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionReportIteration -> reportIteration,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				]
			],
			
			"BackpropagationPlusMomentum",
			Return[
				FitPerceptronWithBP[
					trainingAndTestSet,
					numberOfHiddenNeurons,
					PerceptronOptionInitialWeights -> initialWeights,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
					PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
					PerceptronOptionReportIteration -> reportIteration,
					PerceptronOptionLearningParameterMin -> learningParameterMin,
					PerceptronOptionLearningParameterMax -> learningParameterMax,
					PerceptronOptionMomentumParameter -> momentumParameter,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				]
			],
			
			"GeneticAlgorithm",
			Return[
				FitPerceptronWithGA[
					trainingAndTestSet,
					numberOfHiddenNeurons,
					PerceptronOptionInitialWeights -> initialWeights,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
					PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
					PerceptronOptionReportIteration -> reportIteration,
					PerceptronOptionPopulationSize -> populationSize,
					PerceptronOptionCrossoverProbability -> crossoverProbability,
					PerceptronOptionMutationProbability -> mutationProbability,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				]
			]
		]
	];

GetBestPerceptronClassOptimization[

	(* Returns best training set optimization result of perceptron for classification.

	   Returns: 
	   Best index for classification *)


	(* perceptronTrainOptimization = {trainingSetRmseList, testSetRmseList, trainingAndTestSetList, perceptronInfoList}
	   trainingSetRmseList: List with {number of optimization step, RMSE of training set}
	   testSetRmseList: List with {number of optimization step, RMSE of test set}
	   trainingAndTestSetList: List with {training set, test set}
	   trainingAndTestSetList[[i]] refers to optimization step i
	   perceptronInfoList: List with perceptronInfo
	   perceptronInfoList[[i]] refers to optimization step i *)
	perceptronTrainOptimization_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			k,
			trainingAndTestSetList,
			perceptronInfoList,
			maximumCorrectClassificationInPercent,
			perceptronInfo,
			correctClassificationInPercent,
			bestIndex,
			testSet,
			trainingSet,
			trainingSetCorrectClassificationInPercent,
			testSetCorrectClassificationInPercent,
			bestOptimization,
			bestTestSetCorrectClassificationInPercent,
			minimumDeviation,
			deviation 
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Utility options *)
	    bestOptimization = UtilityOptionsBestOptimization/.{opts}/.Options[UtilityOptionsOptimization];

		Switch[bestOptimization,

			(* ------------------------------------------------------------------------------- *)
			"BestTestResult",			
			trainingAndTestSetList = perceptronTrainOptimization[[3]];
			perceptronInfoList = perceptronTrainOptimization[[4]];
			maximumCorrectClassificationInPercent = -1.0;
			Do[
				testSet = trainingAndTestSetList[[k, 2]];
				perceptronInfo = perceptronInfoList[[k]];
				correctClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[testSet, perceptronInfo];
				If[correctClassificationInPercent > maximumCorrectClassificationInPercent,
					maximumCorrectClassificationInPercent = correctClassificationInPercent;
					bestIndex = k
				],
				
				{k, Length[perceptronInfoList]}
			],
			
			(* ------------------------------------------------------------------------------- *)			
			"MinimumDeviation",
			trainingAndTestSetList = perceptronTrainOptimization[[3]];
			perceptronInfoList = perceptronTrainOptimization[[4]];
			minimumDeviation = Infinity;
			Do[
				trainingSet = trainingAndTestSetList[[k, 1]];
				testSet = trainingAndTestSetList[[k, 2]];
				perceptronInfo = perceptronInfoList[[k]];
				trainingSetCorrectClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[trainingSet, perceptronInfo];
				testSetCorrectClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[testSet, perceptronInfo];
				deviation = Abs[testSetCorrectClassificationInPercent - trainingSetCorrectClassificationInPercent];
				If[deviation < minimumDeviation || (deviation == minimumDeviation && testSetCorrectClassificationInPercent < bestTestSetCorrectClassificationInPercent),
					minimumDeviation = deviation;
					bestTestSetCorrectClassificationInPercent = testSetCorrectClassificationInPercent;
					bestIndex = k
				],
				
				{k, Length[perceptronInfoList]}
			]
		];

		Return[bestIndex]
	];

GetBestPerceptronRegressOptimization[

	(* Returns best optimization result of perceptron for regression.

	   Returns: 
	   Best index for regression *)


	(* perceptronTrainOptimization = {trainingSetRmseList, testSetRmseList, trainingAndTestSetList, perceptronInfoList}
	   trainingSetRmseList: List with {number of optimization step, RMSE of training set}
	   testSetRmseList: List with {number of optimization step, RMSE of test set}
	   trainingAndTestSetList: List with {training set, test set}
	   trainingAndTestSetList[[i]] refers to optimization step i
	   perceptronInfoList: List with perceptronInfo
	   perceptronInfoList[[i]] refers to optimization step i *)
	perceptronTrainOptimization_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			bestOptimization
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Utility options *)
	    bestOptimization = UtilityOptionsBestOptimization/.{opts}/.Options[UtilityOptionsOptimization];

		Return[
			CIP`Utility`GetBestRegressOptimization[
				perceptronTrainOptimization, 
				UtilityOptionsBestOptimization -> bestOptimization
			]
		]
	];

GetInternalMeanSquaredErrorOfPerceptron[

	(* Calculates mean squared error of specified data set for 3-Layer-True-Unit Perceptron with specified weights

	   Returns:
	   Mean squared error of data set *)


	(* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputComponent1, inputComponent2, ...}
	   output: {outputComponent1, outputComponent2, ...})
	   NOTE: Each component must be in [0, 1] *)
    dataSet_,
    
    (* Weights from input to hidden units *)
    hiddenWeights_/;MatrixQ[hiddenWeights, NumberQ],
    
    (* Weights from hidden to output units *)
    outputWeights_/;MatrixQ[outputWeights, NumberQ]
    
	] :=
  
	Module[
    
		{
			errors,
			hidden,
			inputs,
			machineOutputs,
			outputs
		},
    
		inputs = CIP`Utility`GetInputsOfDataSet[dataSet];
		outputs = CIP`Utility`GetOutputsOfDataSet[dataSet];

	    (* Add 'true unit' to inputs *)
	    hidden = SigmoidFunction[Map[Append[#, 1.0] &, inputs].Transpose[hiddenWeights]];

	    (* Add 'true unit' to hidden *)
	    machineOutputs = SigmoidFunction[Map[Append[#, 1.0] &, hidden].Transpose[outputWeights]];

	    errors = outputs - machineOutputs;
        Return[Apply[Plus, errors^2, {0,1}]/Length[dataSet]]
	];

GetInternalPerceptronOutput[

	(* Calculates internal output for specified input of 3-Layer-True-Unit perceptron with specified weights.

	   Returns:
	   output: {valueOfOutput1, valueOfOutput2, ...} *)

    
    (* input: {valueForInput1, valueForInput1, ...} *)
    input_/;VectorQ[input, NumberQ],
    
    (* Weights from input to hidden units *)
    hiddenWeights_/;MatrixQ[hiddenWeights, NumberQ],
    
    (* Weights from hidden to output units *)
    outputWeights_/;MatrixQ[outputWeights, NumberQ]
    
	] :=
  
	Module[
    
		{
	      hidden,
	      internalInputs,
	      trueUnitHidden
		},
    
		(* Add 'true unit' to inputs *)
		internalInputs = Append[input, 1.0];
	    hidden = SigmoidFunction[internalInputs.Transpose[hiddenWeights]];
	    (* Add 'true unit' to hidden *)
		trueUnitHidden = Append[hidden, 1.0];
		Return[SigmoidFunction[trueUnitHidden.Transpose[outputWeights]]];
    ];

GetInternalPerceptronOutputs[

	(* Calculates internal outputs for specified inputs for 3-Layer-True-Unit perceptron with specified weights.

	   Returns:
	   outputs: {output1, output2, ...} 
	   output: {valueOfOutput1, valueOfOutput2, ...} *)

    
    (* inputs: {input1, input2, ...} 
       input: {valueForInput1, valueForInput1, ...} *)
    inputs_/;MatrixQ[inputs, NumberQ],
    
    (* Weights from input to hidden units *)
    hiddenWeights_/;MatrixQ[hiddenWeights, NumberQ],
    
    (* Weights from hidden to output units *)
    outputWeights_/;MatrixQ[outputWeights, NumberQ]
    
	] :=
  
	Module[
    
		{
	      hidden,
	      internalInputs,
	      trueUnitHidden
		},
    
		(* Add 'true unit' to inputs *)
		internalInputs = Map[Append[#, 1.0] &, inputs];
	    hidden = SigmoidFunction[internalInputs.Transpose[hiddenWeights]];
	    (* Add 'true unit' to hidden *)
		trueUnitHidden = Map[Append[#, 1.0] &, hidden];
		Return[SigmoidFunction[trueUnitHidden.Transpose[outputWeights]]];
    ];

GetNumberOfHiddenNeurons[

	(* Returns number of hidden neurons for specified perceptronInfo.

	   Returns:
	   Number of hidden neurons *)

    
  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{},
		
		Return[
			GetPerceptronStructure[perceptronInfo][[2]]
		]
	];

GetPerceptronInputInclusionClass[

	(* Analyzes relevance of input components by successive get-one-in for classification.
	   If option UtilityOptionsInclusionsPerStep is specified then after each loop over all input components the number of input components 
	   specified are included, i.e. with UtilityOptionsInclusionsPerStep -> {20, 10, 5} 20 input components are included after the first loop, 
	   after the second loop 10 input components etc. 

	   Returns: 
	   perceptronInputComponentRelevanceListForClassification: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, includedInputComponentList, perceptronInfo}
	   trainingSetResult: {numberOfIncludedInputs, (best) classificationInPercent of training set (if there is no test set)}
	   testSetResult: {numberOfIncludedInputs, (best) classificationInPercent of test set} *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,	
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			multiplePerceptrons,
			optimizationMethod,
			initialWeights,
			initialNetworks,
			weightsValueLimit,
			minimizationPrecision,
			maximumNumberOfIterations,
			numberOfIterationsToImprove,
			learningParameterMin,
			learningParameterMax,
			momentumParameter,
			populationSize,
			crossoverProbability,
			mutationProbability,
			randomValueInitialization,
			targetInterval,
			isIntermediateOutput,
			numberOfInclusionsPerStepList,
			isRegression,
			inclusionStartList
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Perceptron options *)   
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		(* Utility options *)   		
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    isIntermediateOutput = UtilityOptionsIsIntermediateOutput/.{opts}/.Options[UtilityOptionsIntermediateOutput];
	    numberOfInclusionsPerStepList = UtilityOptionsInclusionsPerStep/.{opts}/.Options[UtilityOptionsInclusion];
	    inclusionStartList = UtilityOptionsInclusionStartList/.{opts}/.Options[UtilityOptionsInclusion];
	    (* DataTransformation options *)   
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];
		
		isRegression = False;
		Return[
			GetPerceptronInputInclusionCalculation[
				trainingAndTestSet,
				numberOfHiddenNeurons,
				isRegression,
				PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
    			PerceptronOptionOptimizationMethod -> optimizationMethod,
				PerceptronOptionInitialWeights -> initialWeights,
				PerceptronOptionInitialNetworks -> initialNetworks,
				PerceptronOptionWeightsValueLimit -> weightsValueLimit,
				PerceptronOptionMinimizationPrecision -> minimizationPrecision,
				PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
				PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
	 			PerceptronOptionReportIteration -> 0,
				PerceptronOptionLearningParameterMin -> learningParameterMin,
				PerceptronOptionLearningParameterMax -> learningParameterMax,
				PerceptronOptionMomentumParameter -> momentumParameter,
				PerceptronOptionPopulationSize -> populationSize,
				PerceptronOptionCrossoverProbability -> crossoverProbability,
				PerceptronOptionMutationProbability -> mutationProbability,
    			DataTransformationOptionTargetInterval -> targetInterval,
    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
				UtilityOptionsIsIntermediateOutput -> isIntermediateOutput,
				UtilityOptionsInclusionsPerStep -> numberOfInclusionsPerStepList,
				UtilityOptionsInclusionStartList -> inclusionStartList
			]
		]
	];

GetPerceptronInputInclusionRegress[

	(* Analyzes relevance of input components by successive get-one-in for regression.
	   If option UtilityOptionsInclusionsPerStep is specified then after each loop over all input components the number of input components 
	   specified are included, i.e. with UtilityOptionsInclusionsPerStep -> {20, 10, 5} 20 input components are included after the first loop, 
	   after the second loop 10 input components etc. 

	   Returns: 
	   perceptronInputComponentRelevanceListForRegression: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, includedInputComponentList, perceptronInfo}
	   trainingSetResult: {numberOfIncludedInputs, best RMSE of training set (if there is no test set)}
	   testSetResult: {numberOfIncludedInputs, best RMSE of test set} *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,
	
	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,	

	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			multiplePerceptrons,
			optimizationMethod,
			initialWeights,
			initialNetworks,
			weightsValueLimit,
			minimizationPrecision,
			maximumNumberOfIterations,
			numberOfIterationsToImprove,
			learningParameterMin,
			learningParameterMax,
			momentumParameter,
			populationSize,
			crossoverProbability,
			mutationProbability,
			randomValueInitialization,
			targetInterval,
			isIntermediateOutput,
			numberOfInclusionsPerStepList,
			isRegression,
			inclusionStartList
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Perceptron options *)   
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		(* Utility options *)   		
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    isIntermediateOutput = UtilityOptionsIsIntermediateOutput/.{opts}/.Options[UtilityOptionsIntermediateOutput];
	    numberOfInclusionsPerStepList = UtilityOptionsInclusionsPerStep/.{opts}/.Options[UtilityOptionsInclusion];
	    inclusionStartList = UtilityOptionsInclusionStartList/.{opts}/.Options[UtilityOptionsInclusion];
	    (* DataTransformation options *)   
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];
		
		isRegression = True;
		Return[
			GetPerceptronInputInclusionCalculation[
				trainingAndTestSet,
				numberOfHiddenNeurons,
				isRegression,
				PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
    			PerceptronOptionOptimizationMethod -> optimizationMethod,
				PerceptronOptionInitialWeights -> initialWeights,
				PerceptronOptionInitialNetworks -> initialNetworks,
				PerceptronOptionWeightsValueLimit -> weightsValueLimit,
				PerceptronOptionMinimizationPrecision -> minimizationPrecision,
				PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
				PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
	 			PerceptronOptionReportIteration -> 0,
				PerceptronOptionLearningParameterMin -> learningParameterMin,
				PerceptronOptionLearningParameterMax -> learningParameterMax,
				PerceptronOptionMomentumParameter -> momentumParameter,
				PerceptronOptionPopulationSize -> populationSize,
				PerceptronOptionCrossoverProbability -> crossoverProbability,
				PerceptronOptionMutationProbability -> mutationProbability,
    			DataTransformationOptionTargetInterval -> targetInterval,
    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
				UtilityOptionsIsIntermediateOutput -> isIntermediateOutput,
				UtilityOptionsInclusionsPerStep -> numberOfInclusionsPerStepList,
				UtilityOptionsInclusionStartList -> inclusionStartList
			]
		]
	];

GetPerceptronInputInclusionCalculation[

	(* Analyzes relevance of input components by successive get-one-in for regression and classification.
	   If option UtilityOptionsInclusionsPerStep is specified then after each loop over all input components the number of input components 
	   specified are included, i.e. with UtilityOptionsInclusionsPerStep -> {20, 10, 5} 20 input components are included after the first loop, 
	   after the second loop 10 input components etc. 

	   Returns: 
	   perceptronInputComponentRelevanceList: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, includedInputComponentList, perceptronInfo}
	   trainingSetResult: {numberOfIncludedInputs, best RMSE/classificationInPercent of training set (if there is no test set)}
	   testSetResult: {numberOfIncludedInputs, best RMSE/classificationInPercent of test set} *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,
	
	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,	
	
	(* True: Regression, False: Classification*)
	isRegression_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			multiplePerceptrons,
			optimizationMethod,
			initialWeights,
			initialNetworks,
			weightsValueLimit,
			minimizationPrecision,
			maximumNumberOfIterations,
			numberOfIterationsToImprove,
			learningParameterMin,
			learningParameterMax,
			momentumParameter,
			populationSize,
			crossoverProbability,
			mutationProbability,
			randomValueInitialization,
			targetInterval,
			currentIncludedInputComponentList,
			i,
			k,
			numberOfInputs,
			numberOfIncludedInputs,
			perceptronInputComponentRelevanceList,
	        perceptronInfo,
			includedInputComponentList,
			relevance,
			testSet,
			trainingSet,
			testSetRmse,
			trainingSetRmse,
			isIntermediateOutput,
			rmseList,
			sortedRmseList,
			currentTrainingSetRmse,
			currentTestSetRmse,
			currentNumberOfInclusions,
			numberOfInclusionsPerStepList,
			currentTestSetCorrectClassificationInPercent,
			currentTrainingSetCorrectClassificationInPercent,
			inclusionStartList
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Perceptron options *)   
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		(* Utility options *)   		
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    isIntermediateOutput = UtilityOptionsIsIntermediateOutput/.{opts}/.Options[UtilityOptionsIntermediateOutput];
	    numberOfInclusionsPerStepList = UtilityOptionsInclusionsPerStep/.{opts}/.Options[UtilityOptionsInclusion];
	    inclusionStartList = UtilityOptionsInclusionStartList/.{opts}/.Options[UtilityOptionsInclusion];
	    (* DataTransformation options *)   
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* ----------------------------------------------------------------------------------------------------
		   Initialization
		   ---------------------------------------------------------------------------------------------------- *)
		numberOfInputs = First[Dimensions[trainingAndTestSet[[1, 1, 1]] ]];
		If[Length[numberOfInclusionsPerStepList] == 0,
			numberOfInclusionsPerStepList = Table[1, {numberOfInputs}];
		];				   
		includedInputComponentList = inclusionStartList;
		numberOfIncludedInputs = Length[includedInputComponentList];
		perceptronInputComponentRelevanceList = {};
    
		(* ----------------------------------------------------------------------------------------------------
		   Main loop over numberOfInclusionsPerStepList
		   ---------------------------------------------------------------------------------------------------- *)
		Do[
			(* Loop over all input units *)
			currentNumberOfInclusions = numberOfInclusionsPerStepList[[k]];
			rmseList = {};
			Do[
				If[Length[Position[includedInputComponentList, i]] == 0,
					currentIncludedInputComponentList = Append[includedInputComponentList, i];
					trainingSet = trainingAndTestSet[[1]];
					testSet = trainingAndTestSet[[2]];
					trainingSet = CIP`DataTransformation`IncludeInputComponentsOfDataSet[trainingSet, currentIncludedInputComponentList];
    				If[Length[testSet] > 0, 
						testSet = CIP`DataTransformation`IncludeInputComponentsOfDataSet[testSet, currentIncludedInputComponentList]
					];
					perceptronInfo = 
						FitPerceptron[
							trainingSet,
							numberOfHiddenNeurons,
							PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
			    			PerceptronOptionOptimizationMethod -> optimizationMethod,
							PerceptronOptionInitialWeights -> initialWeights,
							PerceptronOptionInitialNetworks -> initialNetworks,
							PerceptronOptionWeightsValueLimit -> weightsValueLimit,
							PerceptronOptionMinimizationPrecision -> minimizationPrecision,
							PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
							PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
				 			PerceptronOptionReportIteration -> 0,
							PerceptronOptionLearningParameterMin -> learningParameterMin,
							PerceptronOptionLearningParameterMax -> learningParameterMax,
							PerceptronOptionMomentumParameter -> momentumParameter,
							PerceptronOptionPopulationSize -> populationSize,
							PerceptronOptionCrossoverProbability -> crossoverProbability,
							PerceptronOptionMutationProbability -> mutationProbability,
			    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
			    			DataTransformationOptionTargetInterval -> targetInterval
						];
					If[Length[testSet] > 0,
            
						testSetRmse = CalculatePerceptronDataSetRmse[testSet, perceptronInfo];
						AppendTo[rmseList,{testSetRmse, i}],
          
						trainingSetRmse = CalculatePerceptronDataSetRmse[trainingSet, perceptronInfo];
						AppendTo[rmseList,{trainingSetRmse, i}]
					]
				],
        
				{i, numberOfInputs}
			];
			sortedRmseList = Sort[rmseList];
			currentIncludedInputComponentList = Flatten[AppendTo[includedInputComponentList, Take[sortedRmseList[[All, 2]], currentNumberOfInclusions]]];
			numberOfIncludedInputs = Length[currentIncludedInputComponentList];
			trainingSet = trainingAndTestSet[[1]];
			testSet = trainingAndTestSet[[2]];
			trainingSet = CIP`DataTransformation`IncludeInputComponentsOfDataSet[trainingSet, currentIncludedInputComponentList];
			If[Length[testSet] > 0, 
				testSet = CIP`DataTransformation`IncludeInputComponentsOfDataSet[testSet, currentIncludedInputComponentList]
			];
			perceptronInfo = 
				FitPerceptron[
					trainingSet,
					numberOfHiddenNeurons,
					PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
	    			PerceptronOptionOptimizationMethod -> optimizationMethod,
					PerceptronOptionInitialWeights -> initialWeights,
					PerceptronOptionInitialNetworks -> initialNetworks,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
					PerceptronOptionMinimizationPrecision -> minimizationPrecision,
					PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
		 			PerceptronOptionReportIteration -> 0,
					PerceptronOptionLearningParameterMin -> learningParameterMin,
					PerceptronOptionLearningParameterMax -> learningParameterMax,
					PerceptronOptionMomentumParameter -> momentumParameter,
					PerceptronOptionPopulationSize -> populationSize,
					PerceptronOptionCrossoverProbability -> crossoverProbability,
					PerceptronOptionMutationProbability -> mutationProbability,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				];

			If[isRegression,
				
				(* Regression*)
				If[Length[testSet] > 0,
					
					(* Regression WITH test set *)
	    			currentTrainingSetRmse = CalculatePerceptronDataSetRmse[trainingSet, perceptronInfo];
					currentTestSetRmse = CalculatePerceptronDataSetRmse[testSet, perceptronInfo];
					If[isIntermediateOutput,
						Print["numberOfIncludedInputs            = ", numberOfIncludedInputs];
						Print["currentIncludedInputComponentList = ", currentIncludedInputComponentList];
						Print["currentTrainingSetRmse            = ", currentTrainingSetRmse];
						Print["currentTestSetRmse                = ", currentTestSetRmse]
					];
					relevance = 
						{
							{N[numberOfIncludedInputs], currentTrainingSetRmse}, 
							{N[numberOfIncludedInputs], currentTestSetRmse}, 
							currentIncludedInputComponentList, 
							perceptronInfo
						},
		          
					(* Regression WITHOUT test set *)
					currentTrainingSetRmse = CalculatePerceptronDataSetRmse[trainingSet, perceptronInfo];
					If[isIntermediateOutput,
						Print["numberOfIncludedInputs            = ", numberOfIncludedInputs];
						Print["currentIncludedInputComponentList = ", currentIncludedInputComponentList];
						Print["currentTrainingSetRmse            = ", currentTrainingSetRmse]
					];
					relevance = 
						{
							{N[numberOfIncludedInputs], currentTrainingSetRmse}, 
							{}, 
							currentIncludedInputComponentList, 
							perceptronInfo
						}
				],
				
				(* Classification *)
				If[Length[testSet] > 0,
					
					(* Classification WITH test set *)
					currentTrainingSetCorrectClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[trainingSet, perceptronInfo];
					currentTestSetCorrectClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[testSet, perceptronInfo];
					If[isIntermediateOutput,
						Print["numberOfIncludedInputs                           = ", numberOfIncludedInputs];
						Print["currentIncludedInputComponentList                = ", currentIncludedInputComponentList];
						Print["currentTrainingSetCorrectClassificationInPercent = ", currentTrainingSetCorrectClassificationInPercent];
						Print["currentTestSetCorrectClassificationInPercent     = ", currentTestSetCorrectClassificationInPercent]
					];
					relevance = 
						{
							{N[numberOfIncludedInputs], currentTrainingSetCorrectClassificationInPercent}, 
							{N[numberOfIncludedInputs], currentTestSetCorrectClassificationInPercent}, 
							currentIncludedInputComponentList, 
							perceptronInfo
						},
		          
					(* Classification WITHOUT test set *)
					currentTrainingSetCorrectClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[trainingSet, perceptronInfo];
					If[isIntermediateOutput,
						Print["numberOfIncludedInputs                           = ", numberOfIncludedInputs];
						Print["currentIncludedInputComponentList                = ", currentIncludedInputComponentList];
						Print["currentTrainingSetCorrectClassificationInPercent = ", currentTrainingSetCorrectClassificationInPercent]
					];
					relevance = 
						{
							{N[numberOfIncludedInputs], currentTrainingSetCorrectClassificationInPercent}, 
							{}, 
							currentIncludedInputComponentList, 
							perceptronInfo
						}
				]
			];	

			AppendTo[perceptronInputComponentRelevanceList, relevance];
			includedInputComponentList = currentIncludedInputComponentList,
			
			{k, Length[numberOfInclusionsPerStepList]}
		];
		
		Return[perceptronInputComponentRelevanceList]
	];

GetPerceptronInputRelevanceClass[

	(* Analyzes relevance of input components by successive leave-one-out for classification.
	   If option UtilityOptionsExclusionsPerStep is specified then after each loop over all input components the number of input components 
	   specified are excluded, i.e. with UtilityOptionsExclusionsPerStep -> {20, 10, 5} 20 input components are excluded after the first loop, 
	   after the second loop 10 input components etc. 

	   Returns: 
	   perceptronInputComponentRelevanceListForClassification: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, removedInputComponentList, perceptronInfo}
	   trainingSetResult: {numberOfRemovedInputs, (best) classificationInPercent of training set (if there is no test set)}
	   testSetResult: {numberOfRemovedInputs, (best) classificationInPercent of test set} *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,
	
	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,	
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			multiplePerceptrons,
			optimizationMethod,
			initialWeights,
			initialNetworks,
			weightsValueLimit,
			minimizationPrecision,
			maximumNumberOfIterations,
			numberOfIterationsToImprove,
			learningParameterMin,
			learningParameterMax,
			momentumParameter,
			populationSize,
			crossoverProbability,
			mutationProbability,
			randomValueInitialization,
			targetInterval,
			isIntermediateOutput,
			numberOfExclusionsPerStepList,
			isRegression
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Perceptron options *)   
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		(* Utility options *)   		
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    isIntermediateOutput = UtilityOptionsIsIntermediateOutput/.{opts}/.Options[UtilityOptionsIntermediateOutput];
	    numberOfExclusionsPerStepList = UtilityOptionsExclusionsPerStep/.{opts}/.Options[UtilityOptionsExclusion];
	    (* DataTransformation options *)   
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];
		
		isRegression = False;
		Return[
			GetPerceptronInputRelevanceCalculation[
				trainingAndTestSet,
				numberOfHiddenNeurons,
				isRegression,
				PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
    			PerceptronOptionOptimizationMethod -> optimizationMethod,
				PerceptronOptionInitialWeights -> initialWeights,
				PerceptronOptionInitialNetworks -> initialNetworks,
				PerceptronOptionWeightsValueLimit -> weightsValueLimit,
				PerceptronOptionMinimizationPrecision -> minimizationPrecision,
				PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
				PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
	 			PerceptronOptionReportIteration -> 0,
				PerceptronOptionLearningParameterMin -> learningParameterMin,
				PerceptronOptionLearningParameterMax -> learningParameterMax,
				PerceptronOptionMomentumParameter -> momentumParameter,
				PerceptronOptionPopulationSize -> populationSize,
				PerceptronOptionCrossoverProbability -> crossoverProbability,
				PerceptronOptionMutationProbability -> mutationProbability,
    			DataTransformationOptionTargetInterval -> targetInterval,
    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
				UtilityOptionsIsIntermediateOutput -> isIntermediateOutput,
				UtilityOptionsExclusionsPerStep -> numberOfExclusionsPerStepList
			]
		]
	];

GetPerceptronInputRelevanceRegress[

	(* Analyzes relevance of input components by successive leave-one-out for regression.
	   If option UtilityOptionsExclusionsPerStep is specified then after each loop over all input components the number of input components 
	   specified are excluded, i.e. with UtilityOptionsExclusionsPerStep -> {20, 10, 5} 20 input components are excluded after the first loop, 
	   after the second loop 10 input components etc. 

	   Returns: 
	   perceptronInputComponentRelevanceListForRegression: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, removedInputComponentList, perceptronInfo}
	   trainingSetResult: {numberOfRemovedInputs, best RMSE of training set (if there is no test set)}
	   testSetResult: {numberOfRemovedInputs, best RMSE of test set} *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			multiplePerceptrons,
			optimizationMethod,
			initialWeights,
			initialNetworks,
			weightsValueLimit,
			minimizationPrecision,
			maximumNumberOfIterations,
			numberOfIterationsToImprove,
			learningParameterMin,
			learningParameterMax,
			momentumParameter,
			populationSize,
			crossoverProbability,
			mutationProbability,
			randomValueInitialization,
			targetInterval,
			isIntermediateOutput,
			numberOfExclusionsPerStepList,
			isRegression
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Perceptron options *)   
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		(* Utility options *)   		
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    isIntermediateOutput = UtilityOptionsIsIntermediateOutput/.{opts}/.Options[UtilityOptionsIntermediateOutput];
	    numberOfExclusionsPerStepList = UtilityOptionsExclusionsPerStep/.{opts}/.Options[UtilityOptionsExclusion];
	    (* DataTransformation options *)   
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];
		
		isRegression = True;
		Return[
			GetPerceptronInputRelevanceCalculation[
				trainingAndTestSet,
				numberOfHiddenNeurons,
				isRegression,
				PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
    			PerceptronOptionOptimizationMethod -> optimizationMethod,
				PerceptronOptionInitialWeights -> initialWeights,
				PerceptronOptionInitialNetworks -> initialNetworks,
				PerceptronOptionWeightsValueLimit -> weightsValueLimit,
				PerceptronOptionMinimizationPrecision -> minimizationPrecision,
				PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
				PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
	 			PerceptronOptionReportIteration -> 0,
				PerceptronOptionLearningParameterMin -> learningParameterMin,
				PerceptronOptionLearningParameterMax -> learningParameterMax,
				PerceptronOptionMomentumParameter -> momentumParameter,
				PerceptronOptionPopulationSize -> populationSize,
				PerceptronOptionCrossoverProbability -> crossoverProbability,
				PerceptronOptionMutationProbability -> mutationProbability,
    			DataTransformationOptionTargetInterval -> targetInterval,
    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
				UtilityOptionsIsIntermediateOutput -> isIntermediateOutput,
				UtilityOptionsExclusionsPerStep -> numberOfExclusionsPerStepList
			]
		]
	];

GetPerceptronInputRelevanceCalculation[

	(* Analyzes relevance of input components by successive leave-one-out for regression and classification.
	   If option UtilityOptionsExclusionsPerStep is specified then after each loop over all input components the number of input components 
	   specified are excluded, i.e. with UtilityOptionsExclusionsPerStep -> {20, 10, 5} 20 input components are excluded after the first loop, 
	   after the second loop 10 input components etc. 

	   Returns: 
	   perceptronInputComponentRelevanceList: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, removedInputComponentList, perceptronInfo}
	   trainingSetResult: {numberOfRemovedInputs, best RMSE/classificationInPercent of training set (if there is no test set)}
	   testSetResult: {numberOfRemovedInputs, best RMSE/classificationInPercent of test set} *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,
	
	(* True: Regression, False: Classification*)
	isRegression_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			multiplePerceptrons,
			optimizationMethod,
			initialWeights,
			initialNetworks,
			weightsValueLimit,
			minimizationPrecision,
			maximumNumberOfIterations,
			numberOfIterationsToImprove,
			learningParameterMin,
			learningParameterMax,
			momentumParameter,
			populationSize,
			crossoverProbability,
			mutationProbability,
			randomValueInitialization,
			targetInterval,
			currentRemovedInputComponentList,
			i,
			k,
			numberOfInputs,
			numberOfRemovedInputs,
			perceptronInputComponentRelevanceList,
	        perceptronInfo,
			removedInputComponentList,
			relevance,
			testSet,
			trainingSet,
			initialTestSetRmse,
			initialTrainingSetRmse,
			testSetRmse,
			trainingSetRmse,
			isIntermediateOutput,
			rmseList,
			sortedRmseList,
			currentTrainingSetRmse,
			currentTestSetRmse,
			currentNumberOfExclusions,
			numberOfExclusionsPerStepList,
			initialTestSetCorrectClassificationInPercent,
			initialTrainingSetCorrectClassificationInPercent,
			currentTestSetCorrectClassificationInPercent,
			currentTrainingSetCorrectClassificationInPercent
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Perceptron options *)   
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		(* Utility options *)   		
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    isIntermediateOutput = UtilityOptionsIsIntermediateOutput/.{opts}/.Options[UtilityOptionsIntermediateOutput];
	    numberOfExclusionsPerStepList = UtilityOptionsExclusionsPerStep/.{opts}/.Options[UtilityOptionsExclusion];
	    (* DataTransformation options *)   
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* ----------------------------------------------------------------------------------------------------
		   Initialization
		   ---------------------------------------------------------------------------------------------------- *)
		numberOfInputs = First[Dimensions[trainingAndTestSet[[1, 1, 1]] ]];
		If[Length[numberOfExclusionsPerStepList] == 0,
			numberOfExclusionsPerStepList = Table[1, {numberOfInputs - 1}];
		];				   
		removedInputComponentList = {};
		perceptronInputComponentRelevanceList = {};
    
		(* Result for no removal *)
		trainingSet = trainingAndTestSet[[1]];
		testSet = trainingAndTestSet[[2]];
		perceptronInfo = 
			FitPerceptron[
				trainingSet,
				numberOfHiddenNeurons,
				PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
    			PerceptronOptionOptimizationMethod -> optimizationMethod,
				PerceptronOptionInitialWeights -> initialWeights,
				PerceptronOptionInitialNetworks -> initialNetworks,
				PerceptronOptionWeightsValueLimit -> weightsValueLimit,
				PerceptronOptionMinimizationPrecision -> minimizationPrecision,
				PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
				PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
	 			PerceptronOptionReportIteration -> 0,
				PerceptronOptionLearningParameterMin -> learningParameterMin,
				PerceptronOptionLearningParameterMax -> learningParameterMax,
				PerceptronOptionMomentumParameter -> momentumParameter,
				PerceptronOptionPopulationSize -> populationSize,
				PerceptronOptionCrossoverProbability -> crossoverProbability,
				PerceptronOptionMutationProbability -> mutationProbability,
    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
    			DataTransformationOptionTargetInterval -> targetInterval
			];
		
		initialTrainingSetRmse = CalculatePerceptronDataSetRmse[trainingSet, perceptronInfo];
		If[isRegression,
			
			(* Regression*)
			If[Length[testSet] > 0,
				
				(* Regression WITH test set*)
				initialTestSetRmse = CalculatePerceptronDataSetRmse[testSet, perceptronInfo];
				If[isIntermediateOutput,
					Print["initialTrainingSetRmse = ", initialTrainingSetRmse];
					Print["initialTestSetRmse     = ", initialTestSetRmse]
				];
				relevance = 
					{
						{0.0, initialTrainingSetRmse},
						{0.0, initialTestSetRmse},
						{}, 
						perceptronInfo
					},
	          
				(* Regression WITHOUT test set*)
				If[isIntermediateOutput,
					Print["initialTrainingSetRmse = ", initialTrainingSetRmse]
				];
				relevance = 
					{
						{0.0, initialTrainingSetRmse},
						{},
						{}, 
						perceptronInfo
					}
			],
			
			(* Classification *)
			initialTrainingSetCorrectClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[trainingSet, perceptronInfo];
			If[Length[testSet] > 0,
				
				(* Classification WITH test set*)
				initialTestSetCorrectClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[testSet, perceptronInfo];
				If[isIntermediateOutput,
					Print["initialTrainingSetCorrectClassificationInPercent = ", initialTrainingSetCorrectClassificationInPercent];
					Print["initialTestSetCorrectClassificationInPercent     = ", initialTestSetCorrectClassificationInPercent]
				];
				relevance = 
					{
						{0.0, initialTrainingSetCorrectClassificationInPercent},
						{0.0, initialTestSetCorrectClassificationInPercent},
						{}, 
						perceptronInfo
					},
	          
				(* Classification WITHOUT test set*)
				If[isIntermediateOutput,
					Print["initialTrainingSetCorrectClassificationInPercent = ", initialTrainingSetCorrectClassificationInPercent]
				];
				relevance = 
					{
						{0.0, initialTrainingSetCorrectClassificationInPercent},
						{},
						{}, 
						perceptronInfo
					}
			]
		];	
		
		AppendTo[perceptronInputComponentRelevanceList, relevance];
    
		(* ----------------------------------------------------------------------------------------------------
		   Main loop over numberOfExclusionsPerStepList
		   ---------------------------------------------------------------------------------------------------- *)
		numberOfRemovedInputs = 0;
		Do[
			(* Loop over all input units *)
			currentNumberOfExclusions = numberOfExclusionsPerStepList[[k]];
			rmseList = {};
			Do[
				If[Length[Position[removedInputComponentList, i]] == 0,
					currentRemovedInputComponentList = Append[removedInputComponentList, i];
					trainingSet = trainingAndTestSet[[1]];
					testSet = trainingAndTestSet[[2]];
					trainingSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[trainingSet, currentRemovedInputComponentList];
    				If[Length[testSet] > 0, 
						testSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[testSet, currentRemovedInputComponentList]
					];
					perceptronInfo = 
						FitPerceptron[
							trainingSet,
							numberOfHiddenNeurons,
							PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
			    			PerceptronOptionOptimizationMethod -> optimizationMethod,
							PerceptronOptionInitialWeights -> initialWeights,
							PerceptronOptionInitialNetworks -> initialNetworks,
							PerceptronOptionWeightsValueLimit -> weightsValueLimit,
							PerceptronOptionMinimizationPrecision -> minimizationPrecision,
							PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
							PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
				 			PerceptronOptionReportIteration -> 0,
							PerceptronOptionLearningParameterMin -> learningParameterMin,
							PerceptronOptionLearningParameterMax -> learningParameterMax,
							PerceptronOptionMomentumParameter -> momentumParameter,
							PerceptronOptionPopulationSize -> populationSize,
							PerceptronOptionCrossoverProbability -> crossoverProbability,
							PerceptronOptionMutationProbability -> mutationProbability,
			    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
			    			DataTransformationOptionTargetInterval -> targetInterval
						];
					If[Length[testSet] > 0,
            
						testSetRmse = CalculatePerceptronDataSetRmse[testSet, perceptronInfo];
						AppendTo[rmseList,{testSetRmse, i}],
          
						trainingSetRmse = CalculatePerceptronDataSetRmse[trainingSet, perceptronInfo];
						AppendTo[rmseList,{trainingSetRmse, i}]
					]
				],
        
				{i, numberOfInputs}
			];
			sortedRmseList = Sort[rmseList];
			currentRemovedInputComponentList = Flatten[AppendTo[removedInputComponentList, Take[sortedRmseList[[All, 2]], currentNumberOfExclusions]]];
			numberOfRemovedInputs = Length[currentRemovedInputComponentList];
			trainingSet = trainingAndTestSet[[1]];
			testSet = trainingAndTestSet[[2]];
			trainingSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[trainingSet, currentRemovedInputComponentList];
			If[Length[testSet] > 0, 
				testSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[testSet, currentRemovedInputComponentList]
			];
			perceptronInfo = 
				FitPerceptron[
					trainingSet,
					numberOfHiddenNeurons,
					PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
	    			PerceptronOptionOptimizationMethod -> optimizationMethod,
					PerceptronOptionInitialWeights -> initialWeights,
					PerceptronOptionInitialNetworks -> initialNetworks,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
					PerceptronOptionMinimizationPrecision -> minimizationPrecision,
					PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
		 			PerceptronOptionReportIteration -> 0,
					PerceptronOptionLearningParameterMin -> learningParameterMin,
					PerceptronOptionLearningParameterMax -> learningParameterMax,
					PerceptronOptionMomentumParameter -> momentumParameter,
					PerceptronOptionPopulationSize -> populationSize,
					PerceptronOptionCrossoverProbability -> crossoverProbability,
					PerceptronOptionMutationProbability -> mutationProbability,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				];

			If[isRegression,
				
				(* Regression*)
				If[Length[testSet] > 0,
					
					(* Regression WITH test set *)
	    			currentTrainingSetRmse = CalculatePerceptronDataSetRmse[trainingSet, perceptronInfo];
					currentTestSetRmse = CalculatePerceptronDataSetRmse[testSet, perceptronInfo];
					If[isIntermediateOutput,
						Print["numberOfRemovedInputs            = ", numberOfRemovedInputs];
						Print["currentRemovedInputComponentList = ", currentRemovedInputComponentList];
						Print["currentTrainingSetRmse           = ", currentTrainingSetRmse];
						Print["Delta(current - initial)         = ", currentTrainingSetRmse - initialTrainingSetRmse];
						Print["currentTestSetRmse               = ", currentTestSetRmse];
						Print["Delta(current - initial)         = ", currentTestSetRmse - initialTestSetRmse]
					];
					relevance = 
						{
							{N[numberOfRemovedInputs], currentTrainingSetRmse}, 
							{N[numberOfRemovedInputs], currentTestSetRmse}, 
							currentRemovedInputComponentList, 
							perceptronInfo
						},
		          
					(* Regression WITHOUT test set *)
					currentTrainingSetRmse = CalculatePerceptronDataSetRmse[trainingSet, perceptronInfo];
					If[isIntermediateOutput,
						Print["numberOfRemovedInputs            = ", numberOfRemovedInputs];
						Print["currentRemovedInputComponentList = ", currentRemovedInputComponentList];
						Print["currentTrainingSetRmse           = ", currentTrainingSetRmse];
						Print["Delta(current - initial)         = ", currentTrainingSetRmse - initialTrainingSetRmse]
					];
					relevance = 
						{
							{N[numberOfRemovedInputs], currentTrainingSetRmse}, 
							{}, 
							currentRemovedInputComponentList, 
							perceptronInfo
						}
				],
				
				(* Classification *)
				If[Length[testSet] > 0,
					
					(* Classification WITH test set *)
					currentTrainingSetCorrectClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[trainingSet, perceptronInfo];
					currentTestSetCorrectClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[testSet, perceptronInfo];
					If[isIntermediateOutput,
						Print["numberOfRemovedInputs                            = ", numberOfRemovedInputs];
						Print["currentRemovedInputComponentList                 = ", currentRemovedInputComponentList];
						Print["currentTrainingSetCorrectClassificationInPercent = ", currentTrainingSetCorrectClassificationInPercent];
						Print["Delta(initial - current)                         = ", initialTrainingSetCorrectClassificationInPercent - currentTrainingSetCorrectClassificationInPercent];
						Print["currentTestSetCorrectClassificationInPercent     = ", currentTestSetCorrectClassificationInPercent];
						Print["Delta(initial - current)                         = ", initialTestSetCorrectClassificationInPercent - currentTestSetCorrectClassificationInPercent]
					];
					relevance = 
						{
							{N[numberOfRemovedInputs], currentTrainingSetCorrectClassificationInPercent}, 
							{N[numberOfRemovedInputs], currentTestSetCorrectClassificationInPercent}, 
							currentRemovedInputComponentList, 
							perceptronInfo
						},
		          
					(* Classification WITHOUT test set *)
					currentTrainingSetCorrectClassificationInPercent = CalculatePerceptronCorrectClassificationInPercent[trainingSet, perceptronInfo];
					If[isIntermediateOutput,
						Print["numberOfRemovedInputs                            = ", numberOfRemovedInputs];
						Print["currentRemovedInputComponentList                 = ", currentRemovedInputComponentList];
						Print["currentTrainingSetCorrectClassificationInPercent = ", currentTrainingSetCorrectClassificationInPercent];
						Print["Delta(initial - current)                         = ", initialTrainingSetCorrectClassificationInPercent - currentTrainingSetCorrectClassificationInPercent]
					];
					relevance = 
						{
							{N[numberOfRemovedInputs], currentTrainingSetCorrectClassificationInPercent}, 
							{}, 
							currentRemovedInputComponentList, 
							perceptronInfo
						}
				]
			];	

			AppendTo[perceptronInputComponentRelevanceList, relevance];
			removedInputComponentList = currentRemovedInputComponentList,
			
			{k, Length[numberOfExclusionsPerStepList]}
		];
		
		Return[perceptronInputComponentRelevanceList]
	];

GetPerceptronSeriesClassificationResult[

	(* Shows result of Perceptron series classifications for training and test set.

	   Returns: 
	   perceptronSeriesClassificationResult: {trainingPoints2D, testPoints2D}
	   trainingPoints2D: {trainingPoint1, trainingPoint2, ...}
	   testPoints2D: {testPoint1, testPoint2, ...}
	   trainingPoint[[i]]: {index i in perceptronInfoList, classification result in percent for training set}
	   testPoint[[i]]: {index i in perceptronInfoList, classification result in percent for test set} *)


    (* {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputComponent1, inputComponent2, ...}
	   output : {outputComponent1, outputComponent2, ...}
	   testSet has the same structure and restrictions as trainingSet 
	   NOTE: Training and test set MUST be in original units *)
    trainingAndTestSet_,

	(* {perceptronInfo1, perceptronInfo2, ...}
	   perceptronInfo (see "Frequently used data structures") *)
    perceptronInfoList_
    
	] :=
  
	Module[
    
		{
			testSet,
			trainingSet,
			pureFunction,
			i,
			trainingPoints2D,
			testPoints2D,
			correctClassificationInPercent
		},

    	trainingSet = trainingAndTestSet[[1]];
    	testSet = trainingAndTestSet[[2]];

		trainingPoints2D = {};
		testPoints2D = {};
		Do[
			pureFunction = Function[inputs, CalculatePerceptronClassNumbers[inputs, perceptronInfoList[[i]]]];
			correctClassificationInPercent = CIP`Utility`GetCorrectClassificationInPercent[trainingSet, pureFunction];
			AppendTo[trainingPoints2D, {N[i], correctClassificationInPercent}];
			If[Length[testSet] > 0,
				correctClassificationInPercent = CIP`Utility`GetCorrectClassificationInPercent[testSet, pureFunction];
				AppendTo[testPoints2D, {N[i], correctClassificationInPercent}]
			],
			
			{i, Length[perceptronInfoList]}
		];
		
		Return[{trainingPoints2D, testPoints2D}]
	];

GetPerceptronSeriesRmse[

	(* Shows RMSE of Perceptron series for training and test set.

	   Returns: 
	   perceptronSeriesRmse: {trainingPoints2D, testPoints2D}
	   trainingPoints2D: {trainingPoint1, trainingPoint2, ...}
	   testPoints2D: {testPoint1, testPoint2, ...}
	   trainingPoint[[i]]: {index i in perceptronInfoList, RMSE for training set}
	   testPoint[[i]]: {index i in perceptronInfoList, RMSE for test set} *)


    (* {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputComponent1, inputComponent2, ...}
	   output : {outputComponent1, outputComponent2, ...}
	   testSet has the same structure and restrictions as trainingSet 
	   NOTE: Training and test set MUST be in original units *)
    trainingAndTestSet_,

	(* {perceptronInfo1, perceptronInfo2, ...}
	   perceptronInfo (see "Frequently used data structures") *)
    perceptronInfoList_
    
	] :=
  
	Module[
    
		{
			testSet,
			trainingSet,
			pureFunction,
			i,
			trainingPoints2D,
			testPoints2D,
			rmse
		},

    	trainingSet = trainingAndTestSet[[1]];
    	testSet = trainingAndTestSet[[2]];

		trainingPoints2D = {};
		testPoints2D = {};
		Do[
			pureFunction = Function[inputs, CalculatePerceptronOutputs[inputs, perceptronInfoList[[i]]]];
			rmse = Sqrt[CIP`Utility`GetMeanSquaredError[trainingSet, pureFunction]];
			AppendTo[trainingPoints2D, {N[i], rmse}];
			If[Length[testSet] > 0,
				rmse = Sqrt[CIP`Utility`GetMeanSquaredError[testSet, pureFunction]];
				AppendTo[testPoints2D, {N[i], rmse}]
			],
			
			{i, Length[perceptronInfoList]}
		];
		
		Return[{trainingPoints2D, testPoints2D}]
	];

GetPerceptronStructure[

	(* Returns perceptron structure for specified perceptronInfo.

	   Returns:
	   {numberOfInputs, numberOfHiddenNeurons, numberOfOutputs} *)

    
  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			hiddenWeights,
			numberOfHiddenNeurons,
			numberOfInputs,
			numberOfOutputs,
			networks,
			outputWeights,
			weights
		},
    
    	networks = perceptronInfo[[1]];
    	
		If[Length[networks] == 1,
	
			(* --------------------------------------------------------------------------------
			   One network
			   -------------------------------------------------------------------------------- *)		

	    	weights = networks[[1]];
	    	hiddenWeights = weights[[1]];
	    	outputWeights = weights[[2]];
	    	(* - 1: Subtract true unit *)
	    	numberOfInputs = Length[hiddenWeights[[1]]] - 1;
	    	numberOfHiddenNeurons = Length[hiddenWeights];
	    	numberOfOutputs = Length[outputWeights];
	    	Return[{numberOfInputs, numberOfHiddenNeurons, numberOfOutputs}],
			
			(* --------------------------------------------------------------------------------
			   Multiple networks (with ONE output value each)
			   -------------------------------------------------------------------------------- *)		

	    	weights = networks[[1]];
	    	hiddenWeights = weights[[1]];
	    	(* - 1: Subtract true unit *)
	    	numberOfInputs = Length[hiddenWeights[[1]]] - 1;
	    	numberOfHiddenNeurons = Length[hiddenWeights];
	    	numberOfOutputs = Length[networks];;
	    	Return[{numberOfInputs, numberOfHiddenNeurons, numberOfOutputs}]
		]
	];

GetPerceptronTrainOptimization[

	(* Returns training set optimization result for perceptron training.

	   Returns:
	   perceptronTrainOptimization = {trainingSetRmseList, testSetRmseList, trainingAndTestSetList, perceptronInfoList}
	   trainingSetRmseList: List with {number of optimization step, RMSE of training set}
	   testSetRmseList: List with {number of optimization step, RMSE of test set}
	   trainingAndTestSetList: List with {training set, test set}
	   trainingAndTestSetList[[i]] refers to optimization step i
	   perceptronInfoList: List with perceptronInfo
	   perceptronInfoList[[i]] refers to optimization step i *)


	(* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} *)
    dataSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,

	(* 0.0 < trainingFraction <= 1.0 
	   trainingFraction = 1.0: Test set is empty *)
	trainingFraction_?NumberQ,
	
	(* Number of training set optimization steps *)
	numberOfTrainingSetOptimizationSteps_?IntegerQ,

	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			crossoverProbability,
			initialNetworks,
			initialWeights,
			weightsValueLimit,
			learningParameterMin,
			learningParameterMax,
			maximumNumberOfIterations,
			minimizationPrecision,
			momentumParameter,
			multiplePerceptrons,
			mutationProbability,
			numberOfIterationsToImprove,
			populationSize,
			randomValueInitialization,
			targetInterval,
			optimizationMethod,

			clusterMethod,
			maximumNumberOfEpochs,
			scalarProductMinimumTreshold,
			maximumNumberOfTrialSteps,

			deviationCalculationMethod,
			blackListLength,
			
			i,
			testSet,
			trainingSet,
			clusterRepresentativesRelatedIndexLists,
			trainingSetIndexList,
			testSetIndexList,
			indexLists,
			perceptronInfo,
			trainingSetRMSE,
			testSetRMSE,
			pureOutputFunction,
			trainingSetRmseList,
			testSetRmseList,
			trainingAndTestSetList,
			perceptronInfoList,
			selectionResult,
			blackList
		},
    
		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Perceptron options *)
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* Cluster options *)
		clusterMethod = ClusterOptionMethod/.{opts}/.Options[ClusterOptionsMethod];
	    maximumNumberOfEpochs = ClusterOptionMaximumNumberOfEpochs/.{opts}/.Options[ClusterOptionsArt2a];
	    scalarProductMinimumTreshold = ClusterOptionScalarProductMinimumTreshold/.{opts}/.Options[ClusterOptionsArt2a];
	    maximumNumberOfTrialSteps = ClusterOptionMaximumTrialSteps/.{opts}/.Options[ClusterOptionsArt2a];

		(* Training set optimization options *)
	    deviationCalculationMethod = UtilityOptionDeviationCalculation/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];
	    blackListLength = UtilityOptionBlackListLength/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];

		clusterRepresentativesRelatedIndexLists = 
			CIP`Cluster`GetClusterRepresentativesRelatedIndexLists[
				dataSet, 
				trainingFraction, 
				ClusterOptionMethod -> clusterMethod,
				ClusterOptionMaximumNumberOfEpochs -> maximumNumberOfEpochs,
				ClusterOptionScalarProductMinimumTreshold -> scalarProductMinimumTreshold,
				ClusterOptionMaximumTrialSteps -> maximumNumberOfTrialSteps,
				UtilityOptionRandomInitializationMode -> randomValueInitialization,
				DataTransformationOptionTargetInterval -> targetInterval
			];
		trainingSetIndexList = clusterRepresentativesRelatedIndexLists[[1]];
		testSetIndexList = clusterRepresentativesRelatedIndexLists[[2]];
		indexLists = clusterRepresentativesRelatedIndexLists[[3]];

		trainingSetRmseList = {};
		testSetRmseList = {};
		trainingAndTestSetList = {};
		perceptronInfoList = {};
		blackList = {};
		Do[
			(* Fit training set and evaluate RMSE *)
			trainingSet = CIP`DataTransformation`GetDataSetPart[dataSet, trainingSetIndexList];
			testSet = CIP`DataTransformation`GetDataSetPart[dataSet, testSetIndexList];
			perceptronInfo = 
				FitPerceptron[
					trainingSet,
					numberOfHiddenNeurons,
					PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
	    			PerceptronOptionOptimizationMethod -> optimizationMethod,
					PerceptronOptionInitialWeights -> initialWeights,
					PerceptronOptionInitialNetworks -> initialNetworks,
					PerceptronOptionWeightsValueLimit -> weightsValueLimit,
					PerceptronOptionMinimizationPrecision -> minimizationPrecision,
					PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
					PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
		 			PerceptronOptionReportIteration -> 0,
					PerceptronOptionLearningParameterMin -> learningParameterMin,
					PerceptronOptionLearningParameterMax -> learningParameterMax,
					PerceptronOptionMomentumParameter -> momentumParameter,
					PerceptronOptionPopulationSize -> populationSize,
					PerceptronOptionCrossoverProbability -> crossoverProbability,
					PerceptronOptionMutationProbability -> mutationProbability,
	    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
	    			DataTransformationOptionTargetInterval -> targetInterval
				];
			trainingSetRMSE = CalculatePerceptronDataSetRmse[trainingSet, perceptronInfo];
			testSetRMSE = CalculatePerceptronDataSetRmse[testSet, perceptronInfo];

			(* Set iteration results *)
			AppendTo[trainingSetRmseList, {N[i], trainingSetRMSE}];
			AppendTo[testSetRmseList, {N[i], testSetRMSE}];
			AppendTo[trainingAndTestSetList, {trainingSet, testSet}];
			AppendTo[perceptronInfoList, perceptronInfo];
			
			(* Break if necessary *)
			If[i == numberOfTrainingSetOptimizationSteps,
				Break[]
			];

			(* Select new training and test set index lists *)
			pureOutputFunction = Function[input, CalculatePerceptronOutput[input, perceptronInfo]];
			selectionResult = 
				CIP`Utility`SelectNewTrainingAndTestSetIndexLists[
					dataSet, 
					trainingSetIndexList, 
					testSetIndexList,
					blackList,
					indexLists, 
					pureOutputFunction, 
					UtilityOptionDeviationCalculation -> deviationCalculationMethod,
					UtilityOptionBlackListLength -> blackListLength
				];
			trainingSetIndexList = selectionResult[[1]];
			testSetIndexList = selectionResult[[2]];
			blackList = selectionResult[[3]],
			
			{i, numberOfTrainingSetOptimizationSteps}
		];
		
		Return[
			{
				trainingSetRmseList,
				testSetRmseList,
				trainingAndTestSetList,
				perceptronInfoList
			}
		]
	];

GetPerceptronWeights[

	(* Returns weights of specified network of perceptronInfo.

	   Returns:
	   weights: {hiddenWeights, outputWeights}
	   hiddenWeights: Weights from input to hidden units
	   outputWeights : Weights from hidden to output units *)

    
  	(* See "Frequently used data structures" *)
    perceptronInfo_,
    
	(* Index of network in perceptronInfo *)
    indexOfNetwork_?IntegerQ
    
	] :=
  
	Module[
    
		{
			networks
		},
    
    	networks = perceptronInfo[[1]];
   		Return[networks[[indexOfNetwork]]]
	];

GetWeightsStartVariables[

	(* Returns weights start variables, see code. *)

    
	(* Number of hidden units *)
    numberOfInputs_?IntegerQ,

	(* Number of hidden units *)
    numberOfHiddenNeurons_?IntegerQ,

	(* Number of hidden units *)
    numberOfOutputs_?IntegerQ,

    (* Variable for hidden weights *)
    wInputToHidden_,
    
    (* Variable for output weights *)
    wHiddenToOutput_,
    
    (* Hidden weights *)
    hiddenWeights_,
    
    (* Output weights *)
    outputWeights_

	] :=
  
	Module[
    
		{
			factor,
			hiddenWeigthsStartVariables,
			i,
			j,
			k,
			outputWeightsStartVariables
		},

		factor = CIP`Utility`GetNextHigherMultipleOfTen[numberOfInputs + 1];
		hiddenWeigthsStartVariables = {};
		Do[
	    	Do[
				AppendTo[hiddenWeigthsStartVariables, {Subscript[wInputToHidden, j*factor + i], hiddenWeights[[j, i]]}],
	    		
	    		{i, numberOfInputs + 1}
	    	],
	    
	    	{j, numberOfHiddenNeurons}	
		];

		factor = CIP`Utility`GetNextHigherMultipleOfTen[numberOfHiddenNeurons + 1];
		outputWeightsStartVariables = {};
		Do[	
			Do[
				AppendTo[outputWeightsStartVariables, {Subscript[wHiddenToOutput, k*factor + j], outputWeights[[k, j]]}],
		    
		    	{j, numberOfHiddenNeurons + 1}	
			],
				
			{k, numberOfOutputs}
		];
		
		Return[Join[hiddenWeigthsStartVariables, outputWeightsStartVariables]]
	];

GetWeightsVariables[

	(* Returns weights variables, see code. *)

    
	(* Number of hidden units *)
    numberOfInputs_?IntegerQ,

	(* Number of hidden units *)
    numberOfHiddenNeurons_?IntegerQ,

	(* Number of hidden units *)
    numberOfOutputs_?IntegerQ,

    (* Variable for hidden weights *)
    wInputToHidden_,
    
    (* Variable for output weights *)
    wHiddenToOutput_

	] :=
  
	Module[
    
		{
			factor,
			hiddenWeightsVariables,
			i,
			j,
			k,
			outputWeightsVariables
		},

		factor = CIP`Utility`GetNextHigherMultipleOfTen[numberOfInputs + 1];
		hiddenWeightsVariables = 
			Table[
				Table[
					Subscript[wInputToHidden, j*factor + i], 
					
					{i, numberOfInputs + 1}
				], 
				
				{j, numberOfHiddenNeurons}
			];

		factor = CIP`Utility`GetNextHigherMultipleOfTen[numberOfHiddenNeurons + 1];
		outputWeightsVariables = 
			Table[
				Table[
					Subscript[wHiddenToOutput, k*factor + j], 
					
					{j, numberOfHiddenNeurons + 1}
				], 
				
				{k, numberOfOutputs}
			];
		
		Return[{hiddenWeightsVariables, outputWeightsVariables}]		
	];

MutateChromosome[

	(* Returns a mutated chromosome

	   Returns:
	   chromosome: {hiddenWeights, outputWeights} *)

    
	(* Chromosome has form: {hiddenWeights, outputWeights} *)
    chromosome_,
    
    mutationProbability_?NumberQ,
    
    (* Mutated value will be in interval -mutatedValueBound <= mutated value <= +mutatedValueBound *)
    mutatedValueBound_?NumberQ
    
	] := 
	
	Module[
    
		{
			randomNumber,
			randomPosition1,
			randomPosition2,
			randomPosition3,
			mutatedChromosome
		},
    
	    mutatedChromosome = chromosome;
	    randomNumber = RandomReal[];
    
		(* Mutate with given mutation probability *)
		If[randomNumber <= mutationProbability,
			
			(* True -> Mutate *)
			(* First choose layer : Hidden or output weights *)
			randomPosition1 = RandomInteger[{1, 2}];
			(* Second choose neuron : Hidden or output neuron *)
			randomPosition2 = RandomInteger[{1, Length[chromosome[[randomPosition1]]]}];
			(* Third choose specific weight of hidden or output neuron *)
			randomPosition3 = RandomInteger[{1, Length[chromosome[[randomPosition1, randomPosition2]]]}];
			mutatedChromosome = ReplacePart[mutatedChromosome, {randomPosition1, randomPosition2, randomPosition3} -> RandomReal[{-mutatedValueBound, mutatedValueBound}]];
			Return[mutatedChromosome],
      
			(* False -> Do nothing and return input *)
			Return[chromosome]
		]
	];

ScanClassTrainingWithPerceptron[

	(* Scans training and test set for different training fractions based on method FitPerceptron, see code.
	
	   Returns:
	   perceptronClassificationScan: {trainingAndTestSetsInfo, scanReport}
	   trainingAndTestSetsInfo: {{trainingAndTestSet1, perceptronInfo1}, {trainingAndTestSet2, perceptronInfo2}, ...}
	   trainingAndTestSetsInfo[[i]] corresponds to trainingFractionList[[i]]
	   scanReport: {scanResult1, scanResult2, ...}
	   scanResult: {{trainingFraction, classification result in percent for training set}, {trainingFraction, classification result in percent for test set}}
	   scanResult[[i]] corresponds to trainingFractionList[[i]] and trainingAndTestSetsInfo[[i]] *)

	
	(* classificationDataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} 
	   outputValue: 0/1
	   Data set must be a classification data set, i.e. the output components must 0/1 code a class,
	   i.e. class 4 of 5 must be coded {0, 0, 0, 1, 0} *)
    classificationDataSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,

	(* trainingFractionList = {trainingFraction1, trainingFraction2, ...}
	   0.0 < trainingFraction <= 1.0 
	   trainingFraction = 1.0: Test set is empty *)
	trainingFractionList_/;VectorQ[trainingFractionList, NumberQ],
	
	(* Options *)
	opts___

	] :=
    
	Module[
      
		{
			crossoverProbability,
			initialNetworks,
			initialWeights,
			weightsValueLimit,
			learningParameterMin,
			learningParameterMax,
			maximumNumberOfIterations,
			minimizationPrecision,
			momentumParameter,
			multiplePerceptrons,
			mutationProbability,
			numberOfIterationsToImprove,
			populationSize,
			optimizationMethod,

	    	clusterMethod,
	    	maximumNumberOfEpochs,
	    	scalarProductMinimumTreshold,
	    	maximumNumberOfTrialSteps,
	    	randomValueInitialization,
	    	targetInterval,

			numberOfTrainingSetOptimizationSteps,
			deviationCalculationMethod,
			blackListLength,

			i,
			scanReport,
			trainingAndTestSetsInfo,
			currentTrainingAndTestSet,
			currentTrainingSet,
			currentTestSet,
			currentPerceptronInfo,
			pureFunction,
			trainingSetCorrectClassificationInPercent,
			testSetCorrectClassificationInPercent,
			perceptronTrainOptimization,
			perceptronInfoList,
			trainingAndTestSetList,
			bestIndex
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Perceptron options *)
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];

		(* Cluster options *)
		clusterMethod = ClusterOptionMethod/.{opts}/.Options[ClusterOptionsMethod];
	    maximumNumberOfEpochs = ClusterOptionMaximumNumberOfEpochs/.{opts}/.Options[ClusterOptionsArt2a];
	    scalarProductMinimumTreshold = ClusterOptionScalarProductMinimumTreshold/.{opts}/.Options[ClusterOptionsArt2a];
	    maximumNumberOfTrialSteps = ClusterOptionMaximumTrialSteps/.{opts}/.Options[ClusterOptionsArt2a];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
   	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* Training set optimization options *)
		numberOfTrainingSetOptimizationSteps = UtilityOptionOptimizationSteps/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];
		deviationCalculationMethod = UtilityOptionDeviationCalculation/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];
	    blackListLength = UtilityOptionBlackListLength/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];

		scanReport = {};
		trainingAndTestSetsInfo = {};
		Do[
			If[numberOfTrainingSetOptimizationSteps > 0,
				
				(* ------------------------------------------------------------------------------------------------------ *)
				(* Training set optimization *)
				perceptronTrainOptimization = 
					GetPerceptronTrainOptimization[
						classificationDataSet, 
						numberOfHiddenNeurons, 
						trainingFractionList[[i]],
						numberOfTrainingSetOptimizationSteps,
						PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
		    			PerceptronOptionOptimizationMethod -> optimizationMethod,
						PerceptronOptionInitialWeights -> initialWeights,
						PerceptronOptionInitialNetworks -> initialNetworks,
						PerceptronOptionWeightsValueLimit -> weightsValueLimit,
						PerceptronOptionMinimizationPrecision -> minimizationPrecision,
						PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
						PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
						PerceptronOptionLearningParameterMin -> learningParameterMin,
						PerceptronOptionLearningParameterMax -> learningParameterMax,
						PerceptronOptionMomentumParameter -> momentumParameter,
						PerceptronOptionPopulationSize -> populationSize,
						PerceptronOptionCrossoverProbability -> crossoverProbability,
						PerceptronOptionMutationProbability -> mutationProbability,
						ClusterOptionMethod -> clusterMethod,
						ClusterOptionMaximumNumberOfEpochs -> maximumNumberOfEpochs,
						ClusterOptionScalarProductMinimumTreshold -> scalarProductMinimumTreshold,
						ClusterOptionMaximumTrialSteps -> maximumNumberOfTrialSteps,
						DataTransformationOptionTargetInterval -> targetInterval,
						UtilityOptionRandomInitializationMode -> randomValueInitialization,
				        UtilityOptionDeviationCalculation -> deviationCalculationMethod,
						UtilityOptionBlackListLength -> blackListLength
					];
				bestIndex = GetBestPerceptronClassOptimization[perceptronTrainOptimization];
				trainingAndTestSetList = perceptronTrainOptimization[[3]];
				perceptronInfoList = perceptronTrainOptimization[[4]];
				currentTrainingAndTestSet = trainingAndTestSetList[[bestIndex]];
				currentTrainingSet = currentTrainingAndTestSet[[1]];
				currentTestSet = currentTrainingAndTestSet[[2]];
				currentPerceptronInfo = perceptronInfoList[[bestIndex]],
				
				(* ------------------------------------------------------------------------------------------------------ *)
				(* No training set optimization *)
				currentTrainingAndTestSet = 
					CIP`Cluster`GetClusterBasedTrainingAndTestSet[
						classificationDataSet,
						trainingFractionList[[i]],
						ClusterOptionMethod -> clusterMethod,
						ClusterOptionMaximumNumberOfEpochs -> maximumNumberOfEpochs,
						ClusterOptionScalarProductMinimumTreshold -> scalarProductMinimumTreshold,
						ClusterOptionMaximumTrialSteps -> maximumNumberOfTrialSteps,
						UtilityOptionRandomInitializationMode -> randomValueInitialization,
						DataTransformationOptionTargetInterval -> targetInterval
					];
				currentTrainingSet = currentTrainingAndTestSet[[1]];
				currentTestSet = currentTrainingAndTestSet[[2]];
				currentPerceptronInfo = 
					FitPerceptron[
						currentTrainingSet,
						numberOfHiddenNeurons,
						PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
		    			PerceptronOptionOptimizationMethod -> optimizationMethod,
						PerceptronOptionInitialWeights -> initialWeights,
						PerceptronOptionInitialNetworks -> initialNetworks,
						PerceptronOptionWeightsValueLimit -> weightsValueLimit,
						PerceptronOptionMinimizationPrecision -> minimizationPrecision,
						PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
						PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
			 			PerceptronOptionReportIteration -> 0,
						PerceptronOptionLearningParameterMin -> learningParameterMin,
						PerceptronOptionLearningParameterMax -> learningParameterMax,
						PerceptronOptionMomentumParameter -> momentumParameter,
						PerceptronOptionPopulationSize -> populationSize,
						PerceptronOptionCrossoverProbability -> crossoverProbability,
						PerceptronOptionMutationProbability -> mutationProbability,
		    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
		    			DataTransformationOptionTargetInterval -> targetInterval
					]
			];
			
			pureFunction = Function[inputs, CalculatePerceptronClassNumbers[inputs, currentPerceptronInfo]];
			trainingSetCorrectClassificationInPercent = CIP`Utility`GetCorrectClassificationInPercent[currentTrainingSet, pureFunction];
			testSetCorrectClassificationInPercent = CIP`Utility`GetCorrectClassificationInPercent[currentTestSet, pureFunction];
			AppendTo[trainingAndTestSetsInfo, {currentTrainingAndTestSet, currentPerceptronInfo}];
			AppendTo[
				scanReport, 
				{
					{trainingFractionList[[i]], trainingSetCorrectClassificationInPercent},
					{trainingFractionList[[i]], testSetCorrectClassificationInPercent}
				}
			],
			
			{i, Length[trainingFractionList]}
		];

		Return[{trainingAndTestSetsInfo, scanReport}]
	];

ScanRegressTrainingWithPerceptron[

	(* Scans training and test set for different training fractions based on method FitPerceptron, see code.
	
	   Returns:
	   perceptronRegressopmTrainingScanResult: {trainingAndTestSetsInfo, scanReport}
	   trainingAndTestSetsInfo: {{trainingAndTestSet1, perceptronInfo1}, {trainingAndTestSet2, perceptronInfo2}, ...}
	   trainingAndTestSetsInfo[[i]] corresponds to trainingFractionList[[i]]
	   scanReport: {scanResult1, scanResult2, ...}
	   scanResult: {{trainingFraction, RMSE for training set}, {trainingFraction, RMSE for test set}}
	   scanResult[[i]] corresponds to trainingFractionList[[i]] and trainingAndTestSetsInfo[[i]] *)

	
	(* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputComponent1, inputComponent2, ...}
	   output: {outputComponent1, outputComponent2, ...}
	   NOTE: Data set MUST be in original units *)
	dataSet_,

	(* Number of hidden neurons *)
	numberOfHiddenNeurons_?IntegerQ,

	(* trainingFractionList = {trainingFraction1, trainingFraction2, ...}
	   0.0 < trainingFraction <= 1.0 
	   trainingFraction = 1.0: Test set is empty *)
	trainingFractionList_/;VectorQ[trainingFractionList, NumberQ],
	
	(* Options *)
	opts___

	] :=
    
	Module[
      
		{
			crossoverProbability,
			initialNetworks,
			initialWeights,
			weightsValueLimit,
			learningParameterMin,
			learningParameterMax,
			maximumNumberOfIterations,
			minimizationPrecision,
			momentumParameter,
			multiplePerceptrons,
			mutationProbability,
			numberOfIterationsToImprove,
			populationSize,
			optimizationMethod,

	    	clusterMethod,
	    	maximumNumberOfEpochs,
	    	scalarProductMinimumTreshold,
	    	maximumNumberOfTrialSteps,
	    	randomValueInitialization,
	    	targetInterval,

			numberOfTrainingSetOptimizationSteps,
			deviationCalculationMethod,
			blackListLength,

			i,
			scanReport,
			trainingAndTestSetsInfo,
			currentTrainingAndTestSet,
			currentTrainingSet,
			currentTestSet,
			currentPerceptronInfo,
			pureFunction,
			trainingSetRMSE,
			testSetRMSE,
			perceptronTrainOptimization,
			trainingAndTestSetList,
			perceptronInfoList,
			bestIndex
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Perceptron options *)
		multiplePerceptrons = PerceptronOptionMultiplePerceptrons/.{opts}/.Options[PerceptronOptionsTraining];
	    optimizationMethod = PerceptronOptionOptimizationMethod/.{opts}/.Options[PerceptronOptionsTraining];
		initialWeights = PerceptronOptionInitialWeights/.{opts}/.Options[PerceptronOptionsOptimization];
		initialNetworks = PerceptronOptionInitialNetworks/.{opts}/.Options[PerceptronOptionsOptimization];
		weightsValueLimit = PerceptronOptionWeightsValueLimit/.{opts}/.Options[PerceptronOptionsOptimization];
		minimizationPrecision = PerceptronOptionMinimizationPrecision/.{opts}/.Options[PerceptronOptionsOptimization];
		maximumNumberOfIterations = PerceptronOptionMaximumIterations/.{opts}/.Options[PerceptronOptionsOptimization];
		numberOfIterationsToImprove = PerceptronOptionIterationsToImprove/.{opts}/.Options[PerceptronOptionsOptimization];
		learningParameterMin = PerceptronOptionLearningParameterMin/.{opts}/.Options[PerceptronOptionsBackpropagation];
		learningParameterMax = PerceptronOptionLearningParameterMax/.{opts}/.Options[PerceptronOptionsBackpropagation];
		momentumParameter = PerceptronOptionMomentumParameter/.{opts}/.Options[PerceptronOptionsBackpropagation];
		populationSize = PerceptronOptionPopulationSize/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		crossoverProbability = PerceptronOptionCrossoverProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];
		mutationProbability = PerceptronOptionMutationProbability/.{opts}/.Options[PerceptronOptionsGeneticAlgorithm];

		(* Cluster options *)
		clusterMethod = ClusterOptionMethod/.{opts}/.Options[ClusterOptionsMethod];
	    maximumNumberOfEpochs = ClusterOptionMaximumNumberOfEpochs/.{opts}/.Options[ClusterOptionsArt2a];
	    scalarProductMinimumTreshold = ClusterOptionScalarProductMinimumTreshold/.{opts}/.Options[ClusterOptionsArt2a];
	    maximumNumberOfTrialSteps = ClusterOptionMaximumTrialSteps/.{opts}/.Options[ClusterOptionsArt2a];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];
   	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* Training set optimization options *)
		numberOfTrainingSetOptimizationSteps = UtilityOptionOptimizationSteps/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];
		deviationCalculationMethod = UtilityOptionDeviationCalculation/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];
	    blackListLength = UtilityOptionBlackListLength/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];

		scanReport = {};
		trainingAndTestSetsInfo = {};
		Do[
			If[numberOfTrainingSetOptimizationSteps > 0,
				
				(* ------------------------------------------------------------------------------------------------------ *)
				(* Training set optimization *)
				perceptronTrainOptimization = 
					GetPerceptronTrainOptimization[
						dataSet, 
						numberOfHiddenNeurons, 
						trainingFractionList[[i]],
						numberOfTrainingSetOptimizationSteps,
						PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
		    			PerceptronOptionOptimizationMethod -> optimizationMethod,
						PerceptronOptionInitialWeights -> initialWeights,
						PerceptronOptionInitialNetworks -> initialNetworks,
						PerceptronOptionWeightsValueLimit -> weightsValueLimit,
						PerceptronOptionMinimizationPrecision -> minimizationPrecision,
						PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
						PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
						PerceptronOptionLearningParameterMin -> learningParameterMin,
						PerceptronOptionLearningParameterMax -> learningParameterMax,
						PerceptronOptionMomentumParameter -> momentumParameter,
						PerceptronOptionPopulationSize -> populationSize,
						PerceptronOptionCrossoverProbability -> crossoverProbability,
						PerceptronOptionMutationProbability -> mutationProbability,
						ClusterOptionMethod -> clusterMethod,
						ClusterOptionMaximumNumberOfEpochs -> maximumNumberOfEpochs,
						ClusterOptionScalarProductMinimumTreshold -> scalarProductMinimumTreshold,
						ClusterOptionMaximumTrialSteps -> maximumNumberOfTrialSteps,
						DataTransformationOptionTargetInterval -> targetInterval,
						UtilityOptionRandomInitializationMode -> randomValueInitialization,
				        UtilityOptionDeviationCalculation -> deviationCalculationMethod,
						UtilityOptionBlackListLength -> blackListLength
					];
				bestIndex = GetBestPerceptronRegressOptimization[perceptronTrainOptimization];
				trainingAndTestSetList = perceptronTrainOptimization[[3]];
				perceptronInfoList = perceptronTrainOptimization[[4]];
				currentTrainingAndTestSet = trainingAndTestSetList[[bestIndex]];
				currentTrainingSet = currentTrainingAndTestSet[[1]];
				currentTestSet = currentTrainingAndTestSet[[2]];
				currentPerceptronInfo = perceptronInfoList[[bestIndex]],
				
				(* ------------------------------------------------------------------------------------------------------ *)
				(* No training set optimization *)
				currentTrainingAndTestSet = 
					CIP`Cluster`GetClusterBasedTrainingAndTestSet[
						dataSet,
						trainingFractionList[[i]],
						ClusterOptionMethod -> clusterMethod,
						ClusterOptionMaximumNumberOfEpochs -> maximumNumberOfEpochs,
						ClusterOptionScalarProductMinimumTreshold -> scalarProductMinimumTreshold,
						ClusterOptionMaximumTrialSteps -> maximumNumberOfTrialSteps,
						UtilityOptionRandomInitializationMode -> randomValueInitialization,
						DataTransformationOptionTargetInterval -> targetInterval
				];
				currentTrainingSet = currentTrainingAndTestSet[[1]];
				currentTestSet = currentTrainingAndTestSet[[2]];
				currentPerceptronInfo = 
					FitPerceptron[
						currentTrainingSet,
						numberOfHiddenNeurons,
						PerceptronOptionMultiplePerceptrons -> multiplePerceptrons,
		    			PerceptronOptionOptimizationMethod -> optimizationMethod,
						PerceptronOptionInitialWeights -> initialWeights,
						PerceptronOptionInitialNetworks -> initialNetworks,
						PerceptronOptionWeightsValueLimit -> weightsValueLimit,
						PerceptronOptionMinimizationPrecision -> minimizationPrecision,
						PerceptronOptionMaximumIterations -> maximumNumberOfIterations,
						PerceptronOptionIterationsToImprove -> numberOfIterationsToImprove,
			 			PerceptronOptionReportIteration -> 0,
						PerceptronOptionLearningParameterMin -> learningParameterMin,
						PerceptronOptionLearningParameterMax -> learningParameterMax,
						PerceptronOptionMomentumParameter -> momentumParameter,
						PerceptronOptionPopulationSize -> populationSize,
						PerceptronOptionCrossoverProbability -> crossoverProbability,
						PerceptronOptionMutationProbability -> mutationProbability,
		    			UtilityOptionRandomInitializationMode -> randomValueInitialization,
		    			DataTransformationOptionTargetInterval -> targetInterval
					]
			];
			
			pureFunction = Function[inputs, CalculatePerceptronOutputs[inputs, currentPerceptronInfo]];
			trainingSetRMSE = Sqrt[CIP`Utility`GetMeanSquaredError[currentTrainingSet, pureFunction]];
			testSetRMSE = Sqrt[CIP`Utility`GetMeanSquaredError[currentTestSet, pureFunction]];
			AppendTo[trainingAndTestSetsInfo, {currentTrainingAndTestSet, currentPerceptronInfo}];
			AppendTo[
				scanReport, 
				{
					{trainingFractionList[[i]], trainingSetRMSE},
					{trainingFractionList[[i]], testSetRMSE}
				}
			],
			
			{i, Length[trainingFractionList]}
		];

		Return[{trainingAndTestSetsInfo, scanReport}]
	];

ShowPerceptron2dOutput[

	(* Shows 2D perceptron output.

	   Returns: Nothing *)


    (* Index of input neuron that receives argumentValue *)
    indexOfInput_?IntegerQ,

    (* Index of output neuron that returns function value *)
    indexOfFunctionValueOutput_?IntegerQ,
    
    (* Perceptron input in original units: 
       inputsInOriginalUnits = {inputValue1, inputValue2, ...} 
       Value of input neuron with specified index (indexOfInput) is replaced by argumentValue *)
    input_/;VectorQ[input, NumberQ],
    
    (* Arguments to be displayed as points:
       arguments: {argumentValue1, argumentValue2, ...} *)
    arguments_/;VectorQ[arguments, NumberQ],
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_
      
	] :=
    
	Module[
      
		{	
			dataSetScaleInfo,
			inputsMinMaxList,
			labels,
			points,
			xMin,
			xMax
		},
	
		If[Length[arguments] > 0,
			
			points = 
				Table[
					{
						arguments[[i]], 
						CalculatePerceptron2dValue[arguments[[i]], indexOfInput, indexOfFunctionValueOutput, input, perceptronInfo]
					},
						
					{i, Length[arguments]}
				],
				
			points = {}
		];
		
		dataSetScaleInfo = perceptronInfo[[2]];
		inputsMinMaxList = dataSetScaleInfo[[1, 1]];
		xMin = inputsMinMaxList[[indexOfInput, 1]];
		xMax = inputsMinMaxList[[indexOfInput, 2]];
		
		labels = 
			{
				StringJoin["Argument Value of Input ", ToString[indexOfInput]],
				StringJoin["Value of Output ", ToString[indexOfFunctionValueOutput]],
				"Perceptron Output"
			};
		Print[
			CIP`Graphics`Plot2dPointsAboveFunction[
				points, 
				Function[x, CalculatePerceptron2dValue[x, indexOfInput, indexOfFunctionValueOutput, input, perceptronInfo]], 
				labels,
				GraphicsOptionArgumentRange2D -> {xMin, xMax}
			]
		]
	];

ShowPerceptron3dOutput[

	(* Shows 3D perceptron output.

	   Returns: Graphics3D *)


    (* Index of input neuron that receives argumentValue1 *)
    indexOfInput1_?IntegerQ,

    (* Index of input neuron that receives argumentValue2 *)
    indexOfInput2_?IntegerQ,

    (* Index of output neuron that returns function value *)
    indexOfFunctionValueOutput_?IntegerQ,
    
    (* Perceptron input in original units: 
       inputsInOriginalUnits = {inputValue1, inputValue2, ...} 
       Value of input neuron with specified index (indexOfInput) is replaced by argumentValue *)
    input_/;VectorQ[input, NumberQ],
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_,
    
	(* Options *)
	opts___
      
	] :=
    
	Module[
      
		{	
			GraphicsOptionDisplayFunction,
			GraphicsOptionViewPoint3D,
			GraphicsOptionNumberOfPlotPoints,
			GraphicsOptionColorFunction,
			GraphicsOptionIsMesh,
			GraphicsOptionMeshStyle,
			GraphicsOptionPlotStyle3D,
			dataSetScaleInfo,
			inputsMinMaxList,
			labels,
			x1Min,
			x1Max,
			x2Min,
			x2Max
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    GraphicsOptionDisplayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];
	    GraphicsOptionViewPoint3D = GraphicsOptionViewPoint3D/.{opts}/.Options[GraphicsOptionsGraphics3D];
	    GraphicsOptionNumberOfPlotPoints = GraphicsOptionNumberOfPlotPoints/.{opts}/.Options[GraphicsOptionsGraphics3D];
	    GraphicsOptionColorFunction = GraphicsOptionColorFunction/.{opts}/.Options[GraphicsOptionsGraphics3D];
	    GraphicsOptionIsMesh = GraphicsOptionIsMesh/.{opts}/.Options[GraphicsOptionsGraphics3D];
	    GraphicsOptionMeshStyle = GraphicsOptionMeshStyle/.{opts}/.Options[GraphicsOptionsGraphics3D];
	    GraphicsOptionPlotStyle3D = GraphicsOptionPlotStyle3D/.{opts}/.Options[GraphicsOptionsGraphics3D];
	
		dataSetScaleInfo = perceptronInfo[[2]];
		inputsMinMaxList = dataSetScaleInfo[[1, 1]];
		x1Min = inputsMinMaxList[[indexOfInput1, 1]];
		x1Max = inputsMinMaxList[[indexOfInput1, 2]];
		x2Min = inputsMinMaxList[[indexOfInput2, 1]];
		x2Max = inputsMinMaxList[[indexOfInput2, 2]];
		labels = 
			{
				StringJoin["In ", ToString[indexOfInput1]],
				StringJoin["In ", ToString[indexOfInput2]],
				StringJoin["Out ", ToString[indexOfFunctionValueOutput]]
			};
		
		Return[
			CIP`Graphics`Plot3dFunction[
				Function[{x1, x2}, CalculatePerceptron3dValue[x1, x2, indexOfInput1, indexOfInput2, indexOfFunctionValueOutput, input, perceptronInfo]], 
				{x1Min, x1Max}, 
				{x2Min, x2Max}, 
				labels, 
				GraphicsOptionViewPoint3D -> GraphicsOptionViewPoint3D,
				GraphicsOptionNumberOfPlotPoints -> GraphicsOptionNumberOfPlotPoints,
				GraphicsOptionColorFunction -> GraphicsOptionColorFunction,
				GraphicsOptionIsMesh -> GraphicsOptionIsMesh,
				GraphicsOptionMeshStyle -> GraphicsOptionMeshStyle,
				GraphicsOptionPlotStyle3D -> GraphicsOptionPlotStyle3D,
				GraphicsOptionDisplayFunction -> GraphicsOptionDisplayFunction
			]
		]
	];

ShowPerceptronClassificationResult[

	(* Shows result of perceptron classification for training and test set according to named property list.

	   Returns: Nothing *)


	(* Properties to be analyzed: 
	   Full list: 
	   {
	       "CorrectClassification",
	       "CorrectClassificationPerClass",
	       "WrongClassificationDistribution",
	       "WrongClassificationPairs"
	    } *)
 	namedPropertyList_,
    
	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
    trainingAndTestSet_,
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			minMaxIndex,
			imageSize,
			testSet,
			trainingSet
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    minMaxIndex = GraphicsOptionMinMaxIndex/.{opts}/.Options[GraphicsOptionsIndex];

    	trainingSet = trainingAndTestSet[[1]];
    	testSet =  trainingAndTestSet[[2]];
    	
		Print["Training Set:"];
		ShowPerceptronSingleClassification[
			namedPropertyList,
			trainingSet, 
			perceptronInfo,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionMinMaxIndex -> minMaxIndex
		];
		
		(* Analyze test set *)
		If[Length[testSet] > 0,
			Print["Test Set:"];
			ShowPerceptronSingleClassification[
				namedPropertyList,
				testSet, 
				perceptronInfo,
				GraphicsOptionImageSize -> imageSize,
				GraphicsOptionMinMaxIndex -> minMaxIndex
			];
		]
	];

ShowPerceptronSingleClassification[

	(* Shows result of perceptron classification for data set according to named property list.

	   Returns: Nothing *)

    
	(* Properties to be analyzed: 
	   Full list: 
	   {
	       "CorrectClassification",
	       "CorrectClassificationPerClass",
	       "WrongClassificationDistribution",
	       "WrongClassificationPairs"
	   } *)
 	namedPropertyList_,
    
	(* classificationDataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} 
	   outputValue: 0/1
	   Data set must be a classification data set, i.e. the output components must 0/1 code a class,
	   i.e. class 4 of 5 must be coded {0, 0, 0, 1, 0} *)
    classificationDataSet_,
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			minMaxIndex,
			imageSize,
			pureFunction
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    minMaxIndex = GraphicsOptionMinMaxIndex/.{opts}/.Options[GraphicsOptionsIndex];

   		pureFunction = Function[inputs, CalculatePerceptronClassNumbers[inputs, perceptronInfo]];
		CIP`Graphics`ShowClassificationResult[
			namedPropertyList,
			classificationDataSet, 
			pureFunction,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionMinMaxIndex -> minMaxIndex
		]
	];

ShowPerceptronClassificationScan[

	(* Shows result of Perceptron based classification scan of clustered training sets.

	   Returns: Nothing *)


	(* perceptronClassificationScan: {trainingAndTestSetsInfo, scanReport}
	   trainingAndTestSetsInfo: {{trainingAndTestSet1, perceptronInfo1}, {trainingAndTestSet2, perceptronInfo2}, ...}
	   trainingAndTestSetsInfo[[i]] corresponds to trainingFractionList[[i]]
	   scanReport: {scanResult1, scanResult2, ...}
	   scanResult: {{trainingFraction, classification result in percent for training set}, {trainingFraction, classification result in percent for test set}}
	   scanResult[[i]] corresponds to trainingFractionList[[i]] and trainingAndTestSetsInfo[[i]] *)
	perceptronClassificationScan_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			imageSize,
			displayFunction
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		CIP`Graphics`ShowClassificationScan[
			perceptronClassificationScan,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionDisplayFunction -> displayFunction
		]
	];

ShowPerceptronInputRelevanceClass[

	(* Shows perceptronInputComponentRelevanceListForClassification.

	   Returns: Nothing *)


	(* perceptronInputComponentRelevanceListForClassification: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, removedInputComponentList, perceptronInfo}
	   trainingSetResult: {numberOfRemovedInputs, (best) correct classification in percent of training set (if there is no test set)}
	   testSetResult: {numberOfRemovedInputs, best correct classification in percent of test set} *)
	perceptronInputComponentRelevanceListForClassification_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			displayFunction,
			imageSize
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		CIP`Graphics`ShowInputRelevanceClass[
			perceptronInputComponentRelevanceListForClassification,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionDisplayFunction -> displayFunction
		]
	];

ShowPerceptronInputRelevanceRegress[

	(* Shows perceptronInputComponentRelevanceListForRegression.

	   Returns: Nothing *)


	(* perceptronInputComponentRelevanceListForRegression: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, removedInputComponentList, perceptronInfo}
	   trainingSetResult: {numberOfRemovedInputs, (best) RMSE of training set (if there is no test set)}
	   testSetResult: {numberOfRemovedInputs, best RMSE of test set} *)
	perceptronInputComponentRelevanceListForRegression_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			displayFunction,
			imageSize
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		CIP`Graphics`ShowInputRelevanceRegress[
			perceptronInputComponentRelevanceListForRegression,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionDisplayFunction -> displayFunction
		]
	];
	
ShowPerceptronRegressionResult[

	(* Shows result of perceptron regression for training and test set according to named property list.
	
	   Returns: Nothing *)


	(* Properties to be analyzed: 
	   Full list: 
	   {
	       "RMSE",
	       "SingleOutputRMSE",
	       "AbsoluteResidualsStatistics",
		   "RelativeResidualsStatistics",
		   "ModelVsDataPlot",
		   "CorrelationCoefficient",
		   "SortedModelVsDataPlot",
		   "AbsoluteSortedResidualsPlot",
		   "RelativeSortedResidualsPlot"
	    } *)
 	namedPropertyList_,

	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
    trainingAndTestSet_,
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			pointSize,
			pointColor,
			
			testSet,
			trainingSet		
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    pointSize = GraphicsOptionPointSize/.{opts}/.Options[GraphicsOptionsPoint];
	    pointColor = GraphicsOptionPointColor/.{opts}/.Options[GraphicsOptionsPoint];

    	trainingSet = trainingAndTestSet[[1]];
    	testSet =  trainingAndTestSet[[2]];

		(* Analyze training set *)
	    Print["Training Set:"];
		ShowPerceptronSingleRegression[
			namedPropertyList,
			trainingSet, 
			perceptronInfo,
			GraphicsOptionPointSize -> pointSize,
			GraphicsOptionPointColor -> pointColor
		];
		
		(* Analyze test set *)
		If[Length[testSet] > 0,
			Print["Test Set:"];
			ShowPerceptronSingleRegression[
				namedPropertyList,
				testSet, 
				perceptronInfo,
				GraphicsOptionPointSize -> pointSize,
				GraphicsOptionPointColor -> pointColor
			]
		]
	];

ShowPerceptronSingleRegression[
    
	(* Shows result of perceptron regression for data set according to named property list.
	
	   Returns: Nothing *)


	(* Properties to be analyzed: 
	   Full list: 
	   {
	       "RMSE",
	       "SingleOutputRMSE",
	       "AbsoluteResidualsStatistics",
		   "RelativeResidualsStatistics",
		   "ModelVsDataPlot",
		   "CorrelationCoefficient",
		   "SortedModelVsDataPlot",
		   "AbsoluteSortedResidualsPlot",
		   "RelativeSortedResidualsPlot"
	    } *)
 	namedPropertyList_,

    (* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputComponent1, inputComponent2, ...}
	   output : {outputComponent1, outputComponent2, ...}
	   NOTE: Data set MUST be in original units *)
    dataSet_,
    
  	(* See "Frequently used data structures" *)
    perceptronInfo_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			pureFunction,
    		pointSize,
    		pointColor
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    pointSize = GraphicsOptionPointSize/.{opts}/.Options[GraphicsOptionsPoint];
	    pointColor = GraphicsOptionPointColor/.{opts}/.Options[GraphicsOptionsPoint];

		pureFunction = Function[inputs, CalculatePerceptronOutputs[inputs, perceptronInfo]];
		CIP`Graphics`ShowRegressionResult[
			namedPropertyList,
			dataSet, 
			pureFunction,
			GraphicsOptionPointSize -> pointSize,
			GraphicsOptionPointColor -> pointColor
		]
	];

ShowPerceptronRegressionScan[

	(* Shows result of Perceptron based regression scan of clustered training sets.

	   Returns: Nothing *)


	(* perceptronRegressionScan: {trainingAndTestSetsInfo, scanReport}
	   trainingAndTestSetsInfo: {{trainingAndTestSet1, perceptronInfo1}, {trainingAndTestSet2, perceptronInfo2}, ...}
	   trainingAndTestSetsInfo[[i]] corresponds to trainingFractionList[[i]]
	   scanReport: {scanResult1, scanResult2, ...}
	   scanResult: {{trainingFraction, RMSE for training set}, {trainingFraction, RMSE for test set}}
	   scanResult[[i]] corresponds to trainingFractionList[[i]] and trainingAndTestSetsInfo[[i]] *)
	perceptronRegressionScan_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			imageSize,
			displayFunction
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		CIP`Graphics`ShowRegressionScan[
			perceptronRegressionScan,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionDisplayFunction -> displayFunction
		]
	];

ShowPerceptronSeriesClassificationResult[

	(* Shows result of Perceptron series classifications for training and test set.

	   Returns: Nothing *)


	(* perceptronSeriesClassificationResult: {trainingPoints2D, testPoints2D}
	   trainingPoints2D: {trainingPoint1, trainingPoint2, ...}
	   testPoints2D: {testPoint1, testPoint2, ...}
	   trainingPoint[[i]]: {index i in perceptronInfoList, classification result in percent for training set}
	   testPoint[[i]]: {index i in perceptronInfoList, classification result in percent for test set} *)
	perceptronSeriesClassificationResult_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			i,
			trainingPoints2D,
			testPoints2D,
			labels,
			displayFunction,
			imageSize,
			trainingPoints2DWithPlotStyle,
			testPoints2DWithPlotStyle,
			points2DWithPlotStyleList,
			bestIndexList,
			maximum
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		trainingPoints2D = perceptronSeriesClassificationResult[[1]];
		testPoints2D = perceptronSeriesClassificationResult[[2]];
		
		If[Length[testPoints2D] > 0,

			(* Training and test set *)
			labels = {"perceptronInfo index", "Correct classifications [%]", "Training (green), Test (red)"};
			trainingPoints2DWithPlotStyle = {trainingPoints2D, {Thickness[0.005], Green}};
			testPoints2DWithPlotStyle = {testPoints2D, {Thickness[0.005], Red}};
			points2DWithPlotStyleList = {trainingPoints2DWithPlotStyle, testPoints2DWithPlotStyle};
			Print[
				CIP`Graphics`PlotMultiple2dLines[
					points2DWithPlotStyleList, 
					labels,
					GraphicsOptionImageSize -> imageSize,
					GraphicsOptionDisplayFunction -> displayFunction
				]
			];
			bestIndexList = {};
			maximum = -1.0;
			Do[
				If[testPoints2D[[i, 2]] > maximum,
					
					maximum = testPoints2D[[i, 2]];
					bestIndexList = {i},
					
					
					If[testPoints2D[[i, 2]] == maximum, AppendTo[bestIndexList, i]]
				],
				
				{i, Length[testPoints2D]}
			];
			Print["Best test set classification with perceptronInfo index = ", bestIndexList],
		
			(* Training set only *)
			labels = {"perceptronInfo index", "Correct classifications [%]", "Training (green)"};
			trainingPoints2DWithPlotStyle = {trainingPoints2D, {Thickness[0.005], Green}};
			points2DWithPlotStyleList = {trainingPoints2DWithPlotStyle};
			Print[
				CIP`Graphics`PlotMultiple2dLines[
					points2DWithPlotStyleList, 
					labels,
					GraphicsOptionImageSize -> imageSize,
					GraphicsOptionDisplayFunction -> displayFunction
				]
			];
			bestIndexList = {};
			maximum = -1.0;
			Do[
				If[trainingPoints2D[[i, 2]] > maximum,
					
					maximum = trainingPoints2D[[i, 2]];
					bestIndexList = {i},
					
					
					If[trainingPoints2D[[i, 2]] == maximum, AppendTo[bestIndexList, i]]
				],
				
				{i, Length[trainingPoints2D]}
			];
			Print["Best training set classification with perceptronInfo index = ", bestIndexList]			
		]
	];

ShowPerceptronSeriesRmse[

	(* Shows RMSE of Perceptron series for training and test set.

	   Returns: Nothing *)


	(* perceptronSeriesRmse: {trainingPoints2D, testPoints2D}
	   trainingPoints2D: {trainingPoint1, trainingPoint2, ...}
	   testPoints2D: {testPoint1, testPoint2, ...}
	   trainingPoint[[i]]: {index i in perceptronInfoList, RMSE for training set}
	   testPoint[[i]]: {index i in perceptronInfoList, RMSE for test set} *)
	perceptronSeriesRmse_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			i,
			trainingPoints2D,
			testPoints2D,
			labels,
			displayFunction,
			imageSize,
			trainingPoints2DWithPlotStyle,
			testPoints2DWithPlotStyle,
			points2DWithPlotStyleList,
			bestIndexList,
			minimum
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		trainingPoints2D = perceptronSeriesRmse[[1]];
		testPoints2D = perceptronSeriesRmse[[2]];

		If[Length[testPoints2D] > 0,
			
			(* Training and test set *)
			labels = {"perceptronInfo index", "RMSE", "Training (green), Test (red)"};
			trainingPoints2DWithPlotStyle = {trainingPoints2D, {Thickness[0.005], Green}};
			testPoints2DWithPlotStyle = {testPoints2D, {Thickness[0.005], Red}};
			points2DWithPlotStyleList = {trainingPoints2DWithPlotStyle, testPoints2DWithPlotStyle};
			Print[
				CIP`Graphics`PlotMultiple2dLines[
					points2DWithPlotStyleList, 
					labels,
					GraphicsOptionImageSize -> imageSize,
					GraphicsOptionDisplayFunction -> displayFunction
				]
			];
			bestIndexList = {};
			minimum = Infinity;
			Do[
				If[testPoints2D[[i, 2]] < minimum,
					
					minimum = testPoints2D[[i, 2]];
					bestIndexList = {i},
					
					If[testPoints2D[[i, 2]] == minimum, AppendTo[bestIndexList, i]]
				],
				
				{i, Length[testPoints2D]}
			];
			Print["Best test set regression with perceptronInfo index = ", bestIndexList],

			(* Training set only *)
			labels = {"perceptronInfo index", "RMSE", "Training (green)"};
			trainingPoints2DWithPlotStyle = {trainingPoints2D, {Thickness[0.005], Green}};
			points2DWithPlotStyleList = {trainingPoints2DWithPlotStyle};
			Print[
				CIP`Graphics`PlotMultiple2dLines[
					points2DWithPlotStyleList, 
					labels,
					GraphicsOptionImageSize -> imageSize,
					GraphicsOptionDisplayFunction -> displayFunction
				]
			];
			bestIndexList = {};
			minimum = Infinity;
			Do[
				If[trainingPoints2D[[i, 2]] < minimum,
					
					minimum = trainingPoints2D[[i, 2]];
					bestIndexList = {i},
					
					If[trainingPoints2D[[i, 2]] == minimum, AppendTo[bestIndexList, i]]
				],
				
				{i, Length[trainingPoints2D]}
			];
			Print["Best training set regression with perceptronInfo index = ", bestIndexList]			
		]
	];

ShowPerceptronTraining[

	(* Shows training of perceptron.

	   Returns: Nothing *)


  	(* See "Frequently used data structures" *)
    perceptronInfo_
    
	] :=
  
	Module[
    
		{
			i,
			labels,
			perceptronTrainingResults,
			trainingSetMeanSquaredErrorList,
			testSetMeanSquaredErrorList
		},

		perceptronTrainingResults = perceptronInfo[[3]];
		Do[

			If[Length[perceptronTrainingResults] == 1,
				
				labels = 
					{
						"Number of Iterations",
						"Mean Squared Error [Training Units]",
						"Blue: Training Set, Red: Test Set"
					},
					
				labels = 
					{
						"Number of Iterations",
						"Mean Squared Error [Training Units]",
						StringJoin["Component ", ToString[i], " - Blue: Training Set, Red: Test Set"]
					}
			];
			
			trainingSetMeanSquaredErrorList = perceptronTrainingResults[[i, 1]];
			testSetMeanSquaredErrorList = perceptronTrainingResults[[i, 2]];
			Print[
		    	CIP`Graphics`PlotUpToFour2dLines[
		    		testSetMeanSquaredErrorList, {}, trainingSetMeanSquaredErrorList, {}, 
					labels
				]
			];
			Print[""];
			Print["Best mean squared error of training set (in training units) = ", trainingSetMeanSquaredErrorList[[Length[trainingSetMeanSquaredErrorList], 2]]];
			If[Length[testSetMeanSquaredErrorList] > 0,
				Print["Best mean squared error of test set (in training units)     = ", testSetMeanSquaredErrorList[[Length[testSetMeanSquaredErrorList], 2]]];
			];
			Print[""],
		
			{i, Length[perceptronTrainingResults]}
		]
	];

ShowPerceptronTrainOptimization[

	(* Shows training set optimization result of perceptron.

	   Returns: Nothing *)


	(* perceptronTrainOptimization = {trainingSetRmseList, testSetRmseList, not interesting, not interesting}
	   trainingSetRmseList: List with {number of optimization step, RMSE of training set}
	   testSetRmseList: List with {number of optimization step, RMSE of test set} *)
	perceptronTrainOptimization_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			displayFunction,
			imageSize
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		CIP`Graphics`ShowTrainOptimization[
			perceptronTrainOptimization, 
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionDisplayFunction -> displayFunction
		]
	];

SigmoidFunction[

	(* Sigmoid function

	   Returns:
	   Sigmoid function value *)

	(* Do NOT test with NumberQ because of overload with vectors *)
	x_
	
	] := 1./(1. + Exp[-x]);

(* ::Section:: *)
(* End of Package *)

End[]

EndPackage[]
