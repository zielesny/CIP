(*
-----------------------------------------------------------------------
CIP - Computational Intelligence Packages: Package CDK
Version 1.1 for Mathematica 7 or higher
-----------------------------------------------------------------------

Author    : Florian Boecker
Co-author : Prof. Dr. Achim Zielesny
            E-Mail 
            - IBCI : achim.zielesny@fh-gelsenkirchen.de
            - GNWI : achim.zielesny@gnwi.de

IBCI - Institute for Chemoinformatics and Bioinformatics, 
University of Applied Sciences Gelsenkirchen, Germany

GNWI - Gesellschaft fuer naturwissenschaftliche Informatik mbH, 
Oer-Erkenschwick, Germany

Citation:
A. Zielesny, CIP - Computational Intelligence Packages, Version 1.1, 
GNWI mbH (http://www.gnwi.de), Oer-Erkenschwick, Germany, 2011.

Additional information:
Achim Zielesny, From Curve Fitting to Machine Learning: An 
illustrative Guide to scientific Data Analysis and Computational 
Intelligence, Berlin 2011.
(Springer: Intelligent Systems Reference Library, Volume 18)

A CIP user forum is provided at http://www.gnwi.de.


Copyright 2011 Achim Zielesny

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License (LGPL) as 
published by the Free Software Foundation, version 3 of the License.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
Lesser General Public License (LGPL) for more details.

You should have received a copy of the GNU Lesser General Public 
License along with this program. If not, see 
<http://www.gnu.org/licenses/>. 
-----------------------------------------------------------------------
*)

(* ::Section:: *)
(* Package and dependencies *)

BeginPackage["CIP`CDK`", {"CIP`Utility`", "CIP`Graphics`"}]

(* ::Section:: *)
(* Off settings *)

Off[General::"spell1"]
Off[General::shdw]
Off[General::compat]

(* ::Section:: *)
(* Options *)

Options[CdkOptionsMyOption] = 
{
    (* My specific option 1 *)
	CdkOptionMySpecificOption1 -> 0,
	
	(* My specific option 2 *)
	CdkOptionMySpecificOption2 -> 0
}

(* ::Section:: *)
(* Declarations *)

MyFunction::usage = 
	"MyFunction[myArgument, options]"

(* ::Section:: *)
(* Functions *)

Begin["`Private`"]

MyFunction[

	(* MyFunction does something.
	
	   Returns:
	   Result of MyFunction *)
    
    
    (* myArgument *)
    myArgument_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
    	{
    		mySpecificOption1,
    		mySpecificOption2
    	},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* CDK options *)
	    mySpecificOption1 = CdkOptionMySpecificOption1/.{opts}/.Options[CdkOptionsMyOption];
	    mySpecificOption2 = CdkOptionMySpecificOption2/.{opts}/.Options[CdkOptionsMyOption];

		(* Do something *)
		    
	    Return[]
	];

(* ::Section:: *)
(* End of Package *)

End[]

EndPackage[]
