(*
----------------------------------------------------------------------------------------
CIP - Computational Intelligence Packages: Package Multiple Linear Regression (MLR)
Version 1.0 for Mathematica 7 or higher
----------------------------------------------------------------------------------------

Author : Prof. Dr. Achim Zielesny
         E-Mail 
         - IBCI : achim.zielesny@fh-gelsenkirchen.de
         - GNWI : achim.zielesny@gnwi.de

IBCI - Institute for Chemoinformatics and Bioinformatics, 
University of Applied Sciences Gelsenkirchen, Germany

GNWI - Gesellschaft fuer naturwissenschaftliche Informatik mbH, 
Oer-Erkenschwick, Germany

Citation:
A. Zielesny, CIP - Computational Intelligence Packages, Version 1.0, 
GNWI mbH <http://www.gnwi.de>, Oer-Erkenschwick, Germany, 2011.

Additional information:
Achim Zielesny, From Curve Fitting to Machine Learning: An 
illustrative Guide to scientific Data Analysis and Computational 
Intelligence, Berlin 2011.
(Springer: Intelligent Systems Reference Library)

A CIP user forum is provided at <http://www.gnwi.de>.


Copyright 2011 Achim Zielesny

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License (LGPL) as 
published by the Free Software Foundation, version 3 of the License.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
Lesser General Public License (LGPL) for more details.

You should have received a copy of the GNU Lesser General Public 
License along with this program. If not, see 
<http://www.gnu.org/licenses/>. 
----------------------------------------------------------------------------------------
*)

(* ::Section:: *)
(* Frequently used data structures *)

(*
-----------------------------------------------------------------------
Frequently used data structures
-----------------------------------------------------------------------
mlrInfo: {mlrFitResult, dataSetScaleInfo, dataTransformationMode, outputOffsets}

	mlrFitResult: See code of FitMlr[] and signature of Fit[]
	dataSetScaleInfo: {dataMatrixScaleInfo for inputs, dataMatrixScaleInfo for outputs}, see GetDataSetScaleInfo 
	dataTransformationMode: True: All values of dataSet are internally transformed by Log operation, False: Otherwise 
	outputOffsets: Offset value for transformations of outputs
-----------------------------------------------------------------------
*)

(* ::Section:: *)
(* Package and dependencies *)

BeginPackage["CIP`MLR`", {"CIP`Utility`", "CIP`Graphics`", "CIP`DataTransformation`", "CIP`Cluster`"}]

(* ::Section:: *)
(* Off settings *)

Off[General::"spell1"]
Off[General::shdw]

(* ::Section:: *)
(* Options *)

Options[MlrOptionsDataTransformation] = 
{
	(* Data transformation mode: "None", "Log", "Sqrt" *)
    MlrOptionDataTransformationMode -> "None"
}

(* ::Section:: *)
(* Declarations *)

CalculateMlr2dValue::usage = 
	"CalculateMlr2dValue[argumentValue, indexOfInput, indexOfOutput, input, mlrInfo]"

CalculateMlr3dValue::usage = 
	"CalculateMlr3dValue[argumentValue1, argumentValue2, indexOfInput1, indexOfInput2, indexOfOutput, input, mlrInfo]"

CalculateMlrClassNumber::usage = 
	"CalculateMlrClassNumber[input, mlrInfo]"

CalculateMlrClassNumbers::usage = 
	"CalculateMlrClassNumbers[inputs, mlrInfo]"

CalculateMlrDataSetRmse::usage = 
	"CalculateMlrDataSetRmse[dataSet, mlrInfo]"

CalculateMlrOutput::usage = 
	"CalculateMlrOutput[input, mlrInfo]"

CalculateMlrOutputs::usage = 
	"CalculateMlrOutputs[inputs, mlrInfo]"

FitMlr::usage = 
	"FitMlr[dataSet]"

GetBestMlrClassOptimization::usage = 
	"GetBestMlrClassOptimization[mlrTrainOptimization]"

GetBestMlrRegressOptimization::usage = 
	"GetBestMlrRegressOptimization[mlrTrainOptimization]"

GetMlrInputRelevanceClass::usage = 
	"GetMlrInputRelevanceClass[trainingAndTestSet, options]"

GetMlrInputRelevanceRegress::usage = 
	"GetMlrInputRelevanceRegress[trainingAndTestSet, options]"

GetMlrInputRelevanceRegressSpec::usage = 
	"GetMlrInputRelevanceRegressSpec[trainingAndTestSet, numberOfExclusionsPerStep, options]"

GetMlrTrainOptimization::usage = 
	"GetMlrTrainOptimization[dataSet, trainingFraction, numberOfTrainingSetOptimizationSteps, options]"

ScanClassTrainingWithMlr::usage = 
	"ScanClassTrainingWithMlr[dataSet, trainingFractionList, options]"

ScanRegressTrainingWithMlr::usage = 
	"ScanRegressTrainingWithMlr[dataSet, trainingFractionList, options]"

ShowMlr3dOutput::usage = 
	"ShowMlr3dOutput[indexOfInput1, indexOfInput2, indexOfOutput, input, mlrInfo, graphicsOptions, displayFunction]"

ShowMlrClassificationResult::usage = 
	"ShowMlrClassificationResult[namedPropertyList, trainingAndTestSet, mlrInfo]"

ShowMlrSingleClassification::usage = 
	"ShowMlrSingleClassification[namedPropertyList, dataSet, mlrInfo]"

ShowMlrClassificationScan::usage = 
	"ShowMlrClassificationScan[mlrClassificationScan, options]"

ShowMlrInputRelevanceClass::usage = 
	"ShowMlrInputRelevanceClass[mlrInputComponentRelevanceListForClassification, options]"
	
ShowMlrInputRelevanceRegress::usage = 
	"ShowMlrInputRelevanceRegress[mlrInputComponentRelevanceListForRegression, options]"

ShowMlrRegressionResult::usage = 
	"ShowMlrRegressionResult[namedPropertyList, trainingAndTestSet, mlrInfo, options]"

ShowMlrSingleRegression::usage = 
	"ShowMlrSingleRegression[namedPropertyList, dataSet, mlrInfo, options]"

ShowMlrRegressionScan::usage = 
	"ShowMlrRegressionScan[mlrRegressionScan, options]"

ShowMlrTrainOptimization::usage = 
	"ShowMlrTrainOptimization[mlrTrainOptimization, options]"
	
(* ::Section:: *)
(* Functions *)

Begin["`Private`"]

CalculateMlr2dValue[

	(* Calculates 2D output for specified argument and input for specified MLR.
	   This special method assumes an input and an output with one component only.

	   Returns:
	   Value of specified output component for argument *)


    (* Argument value for input component with index indexOfInput *)
    argumentValue_?NumberQ,
    
  	(* See "Frequently used data structures" *)
    mlrInfo_
    
	] :=
  
	Module[
    
		{
			indexOfInput,
			indexOfFunctionValueOutput,
			input
		},

		indexOfInput = 1;
		indexOfFunctionValueOutput = 1;
		input = {0.0};
		Return[
			CalculateMlr2dValue[argumentValue, indexOfInput, indexOfFunctionValueOutput, input, mlrInfo]
		]
	];

CalculateMlr2dValue[

	(* Calculates 2D output for specified argument and input for specified MLR.

	   Returns:
	   Value of specified output component for argument and input *)


    (* Argument value for input component with index indexOfInput *)
    argumentValue_?NumberQ,
    
    (* Index of input component that receives argumentValue *)
    indexOfInput_?IntegerQ,

    (* Index of output component that returns function value *)
    indexOfOutput_?IntegerQ,
    
    (* Input in original units: 
       inputsInOriginalUnits = {inputValue1, inputValue2, ...} 
       Values of input components with specified indices (indexOfInput1, indexOfInput2) are replaced by argument values *)
    input_/;VectorQ[input, NumberQ],
    
  	(* See "Frequently used data structures" *)
    mlrInfo_
    
	] :=
  
	Module[
    
		{
			currentInput,
			output
		},
		
		currentInput = ReplacePart[input, {indexOfInput -> argumentValue}];
		output = CalculateMlrOutput[currentInput, mlrInfo];
		Return[output[[indexOfOutput]]];
	];

CalculateMlr3dValue[

	(* Calculates 3D output for specified arguments for specified MLR. 
	   This specific methods assumes a MLR with input vector of length 2 and an output vector of length 1.

	   Returns:
	   Value of specified output component for input *)


    (* Argument value for input component with index indexOfInput1 *)
    argumentValue1_?NumberQ,
    
    (* Argument value for input component with index indexOfInput2 *)
    argumentValue2_?NumberQ,
    
  	(* See "Frequently used data structures" *)
    mlrInfo_
    
	] :=
  
	Module[
    
		{
			indexOfInput1,
			indexOfInput2,
			indexOfOutput,
			input
		},
		
		indexOfInput1 = 1;
		indexOfInput2 = 2;
		indexOfOutput = 1;
		input = {0.0,0.0};
		Return[
			CalculateMlr3dValue[argumentValue1, argumentValue2, indexOfInput1, indexOfInput2, indexOfOutput, input, mlrInfo]
		];
	];

CalculateMlr3dValue[

	(* Calculates 3D output for specified arguments and input for specified MLR.

	   Returns:
	   Value of specified output component for arguments and input *)


    (* Argument value for input component with index indexOfInput1 *)
    argumentValue1_?NumberQ,
    
    (* Argument value for input component with index indexOfInput2 *)
    argumentValue2_?NumberQ,
    
    (* Index of input component that receives argumentValue1 *)
    indexOfInput1_?IntegerQ,

    (* Index of input component that receives argumentValue2 *)
    indexOfInput2_?IntegerQ,

    (* Index of output component that returns function value *)
    indexOfOutput_?IntegerQ,
    
    (* Input in original units: 
       inputsInOriginalUnits = {inputValue1, inputValue2, ...} 
       Values of input components with specified indices (indexOfInput1, indexOfInput2) are replaced by argument values *)
    input_/;VectorQ[input, NumberQ],
    
  	(* See "Frequently used data structures" *)
    mlrInfo_
    
	] :=
  
	Module[
    
		{
			currentInput,
			output
		},
		
		currentInput = ReplacePart[input, {indexOfInput1 -> argumentValue1, indexOfInput2 -> argumentValue2}];
		output = CalculateMlrOutput[currentInput, mlrInfo];
		Return[output[[indexOfOutput]]];
	];

CalculateMlrClassNumber[

	(* Returns class number for specified input for classification MLR.

	   Returns:
	   Class number of input *)

    
    (* Input in original units: {inputValueInOriginalUnit1, inputValueInOriginalUnit2, ...} *)
    input_/;VectorQ[input, NumberQ],
    
  	(* See "Frequently used data structures" *)
    mlrInfo_
    
	] :=
  
	Module[
    
		{
			dataSetScaleInfo,
			mlrFitResult,
			scaledInput,
			scaledOutput
		},
    
		mlrFitResult = mlrInfo[[1]];
    	dataSetScaleInfo = mlrInfo[[2]];

		scaledInput = First[CIP`DataTransformation`ScaleDataMatrix[{input}, dataSetScaleInfo[[1]]]];
		scaledOutput = GetInternalMlrOutput[scaledInput, mlrFitResult];
		Return[CIP`Utility`GetPositionOfMaximumValue[scaledOutput]]
	];

CalculateMlrClassNumbers[

	(* Returns class numbers for specified inputs for classification MLR.

	   Returns:
	   {class number of input1, class number of input2, ...} *)

    
    (* {inputsInOriginalUnit1, inputsInOriginalUnit2, ...}
        inputsInOriginalUnit: {inputValueInOriginalUnit1, inputValueInOriginalUnit2, ...} *)
    inputs_/;MatrixQ[inputs, NumberQ],
    
  	(* See "Frequently used data structures" *)
    mlrInfo_
    
	] :=
  
	Module[
    
		{
			i,
			mlrFitResult,
			dataSetScaleInfo,
			scaledInputs,
			scaledOutputs
		},

		mlrFitResult = mlrInfo[[1]];
    	dataSetScaleInfo = mlrInfo[[2]];

		scaledInputs = CIP`DataTransformation`ScaleDataMatrix[inputs, dataSetScaleInfo[[1]]];
		scaledOutputs = GetInternalMlrOutputs[scaledInputs, mlrFitResult];
		Return[
			Table[
				CIP`Utility`GetPositionOfMaximumValue[scaledOutputs[[i]]],
				
				{i, Length[scaledOutputs]}
			]
		]
	];

CalculateMlrCorrectClassificationInPercent[

	(* Returns correct classification in percent for classification data set.

	   Returns: 
	   Correct classification in percent for classification data set *)


	(* classificationDataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} 
	   outputValue: 0/1
	   Data set must be a classification data set, i.e. the output components must 0/1 code a class,
	   i.e. class 4 of 5 must be coded {0, 0, 0, 1, 0} *)
    classificationDataSet_,

  	(* See "Frequently used data structures" *)
    mlrInfo_
    
	] :=
  
	Module[
    
		{
			pureFunction
		},

		pureFunction = Function[inputs, CalculateMlrClassNumbers[inputs, mlrInfo]];
		Return[CIP`Utility`GetCorrectClassificationInPercent[classificationDataSet, pureFunction]]
	];

CalculateMlrDataSetRmse[

	(* Returns RMSE of data set.

	   Returns: 
	   RMSE of data set *)


	(* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} *)
    dataSet_,

  	(* See "Frequently used data structures" *)
    mlrInfo_
    
	] :=
  
	Module[
    
		{
			pureFunction,
			rmse
		},

		pureFunction = Function[inputs, CalculateMlrOutputs[inputs, mlrInfo]];
		rmse = Sqrt[CIP`Utility`GetMeanSquaredError[dataSet, pureFunction]];
		Return[rmse]
	];

CalculateMlrOutput[

	(* Calculates output for specified input for MLR.

	   Returns:
	   output: {transformedOutputValue1, transformedOutputValue2, ...} *)

    
    (* Input in original units: {inputValueInOriginalUnit1, inputValueInOriginalUnit2, ...} *)
    input_/;VectorQ[input, NumberQ],
    
  	(* See "Frequently used data structures" *)
    mlrInfo_
    
	] :=
  
	Module[
    
		{
			dataSetScaleInfo,
			i,
			k,
			dataTransformationMode,
			mlrFitResult,
			outputOffsets,
			outputsInOriginalUnits,
			scaledInput,
			scaledOutput,
			unscaledOutputs
		},
    
		mlrFitResult = mlrInfo[[1]];
    	dataSetScaleInfo = mlrInfo[[2]];
    	dataTransformationMode = mlrInfo[[3]];
    	outputOffsets = mlrInfo[[4]];

		scaledInput = First[CIP`DataTransformation`ScaleDataMatrix[{input}, dataSetScaleInfo[[1]]]];
		scaledOutput = GetInternalMlrOutput[scaledInput, mlrFitResult];

		Switch[dataTransformationMode,
			
			"None",
			outputsInOriginalUnits = CIP`DataTransformation`ScaleDataMatrixReverse[{scaledOutput}, dataSetScaleInfo[[2]]],

			"Log",
			(* All values are internally transformed by Log operation *)
			unscaledOutputs = CIP`DataTransformation`ScaleDataMatrixReverse[{scaledOutput}, dataSetScaleInfo[[2]]];
			outputsInOriginalUnits = 
				Table[
					Exp[unscaledOutputs[[i]]] - outputOffsets,
					
					{i, Length[unscaledOutputs]}
				],

			"Sqrt",
			(* All values are internally transformed by Sqrt operation *)
			unscaledOutputs = CIP`DataTransformation`ScaleDataMatrixReverse[{scaledOutput}, dataSetScaleInfo[[2]]];
			outputsInOriginalUnits = 
				Table[
					Table[
						unscaledOutputs[[i, k]]*unscaledOutputs[[i, k]],
						
						{k, Length[unscaledOutputs[[i]]]}
					] - outputOffsets,
					
					{i, Length[unscaledOutputs]}
				]
		];

		Return[First[outputsInOriginalUnits]]
	];

CalculateMlrOutputs[

	(* Calculates outputs for specified inputs for MLR.

	   Returns:
	   outputs = {output1, ..., output<Length[inputs]>}
	   output: {transformedOutputValue1, transformedOutputValue2, ...} *)

    
    (* {inputsInOriginalUnit1, inputsInOriginalUnit2, ...}
        inputsInOriginalUnit: {inputValueInOriginalUnit1, inputValueInOriginalUnit2, ...} *)
    inputs_/;MatrixQ[inputs, NumberQ],
    
  	(* See "Frequently used data structures" *)
    mlrInfo_
    
	] :=
  
	Module[
    
		{
			dataSetScaleInfo,
			i,
			dataTransformationMode,
			mlrFitResult,
			outputOffsets,
			outputsInOriginalUnits,
			scaledInputs,
			scaledOutputs,
			unscaledOutputs
		},
    
		mlrFitResult = mlrInfo[[1]];
    	dataSetScaleInfo = mlrInfo[[2]];
    	dataTransformationMode = mlrInfo[[3]];
    	outputOffsets = mlrInfo[[4]];

		scaledInputs = CIP`DataTransformation`ScaleDataMatrix[inputs, dataSetScaleInfo[[1]]];
		scaledOutputs = GetInternalMlrOutputs[scaledInputs, mlrFitResult];

		Switch[dataTransformationMode,
			
			"None",
			outputsInOriginalUnits = CIP`DataTransformation`ScaleDataMatrixReverse[scaledOutputs, dataSetScaleInfo[[2]]],

			"Log",
			(* All values are internally transformed by Log operation *)
			unscaledOutputs = CIP`DataTransformation`ScaleDataMatrixReverse[scaledOutputs, dataSetScaleInfo[[2]]];
			outputsInOriginalUnits = 
				Table[
					Exp[unscaledOutputs[[i]]] - outputOffsets,
					
					{i, Length[unscaledOutputs]}
				],

			"Sqrt",
			(* All values are internally transformed by Sqrt operation *)
			unscaledOutputs = CIP`DataTransformation`ScaleDataMatrixReverse[scaledOutputs, dataSetScaleInfo[[2]]];
			outputsInOriginalUnits = 
				Table[
					Table[
						unscaledOutputs[[i, k]]*unscaledOutputs[[i, k]],
						
						{k, Length[unscaledOutputs[[i]]]}
					] - outputOffsets,
					
					{i, Length[unscaledOutputs]}
				]
		];

		Return[outputsInOriginalUnits];
	];

FitMlr[

	(* Trains with MLR

	   Returns: 
	   mlrInfo (see "Frequently used data structures") *)
	   
	   
	(* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} *)
    dataSet_,
	
	(* Options *)
	opts___
		
	] :=
  
	Module[
    
		{
			applicationResult,
			correctedDataSet,
			correctedDataSetScaleInfo,
			ioPair,
			dataTransformationMode,
			dataSetScaleInfo,
			mlrFitResult,
			functionVector,
			i,
			k,
			mlrInputDataList,
			numberOfInputVariables,
			numberOfOutputVariables,
			outputOffsets,
			scaledDataSet,
			variableVector,
			targetInterval
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    dataTransformationMode = MlrOptionDataTransformationMode/.{opts}/.Options[MlrOptionsDataTransformation];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		dataSetScaleInfo = CIP`DataTransformation`GetDataSetScaleInfo[
			dataSet,
			DataTransformationOptionTargetInterval -> targetInterval
		];	    

		(* ----------------------------------------------------------------------------------------------------
		   Training
		   ---------------------------------------------------------------------------------------------------- *)
		Switch[dataTransformationMode,
			
			"None",
			correctedDataSetScaleInfo = dataSetScaleInfo;
			outputOffsets = Table[0.0, {Length[dataSet[[1, 2]]]}];
			scaledDataSet = CIP`DataTransformation`ScaleDataSet[dataSet, dataSetScaleInfo],

			"Log",
			(* All values are internally transformed by Log operation *)
			applicationResult = CIP`DataTransformation`ApplyLogToDataSetOutputs[dataSet]; 
			correctedDataSet = applicationResult[[1]];
			outputOffsets = applicationResult[[2]];
			correctedDataSetScaleInfo = CIP`DataTransformation`CorrectDataSetScaleInfoForLogApplication[dataSetScaleInfo];
			scaledDataSet = CIP`DataTransformation`ScaleDataSet[correctedDataSet, correctedDataSetScaleInfo],

			"Sqrt",
			(* All values are internally transformed by Sqrt operation *)
			applicationResult = CIP`DataTransformation`ApplySqrtToDataSetOutputs[dataSet]; 
			correctedDataSet = applicationResult[[1]];
			outputOffsets = applicationResult[[2]];
			correctedDataSetScaleInfo = CIP`DataTransformation`CorrectDataSetScaleInfoForSqrtApplication[dataSetScaleInfo];
			scaledDataSet = CIP`DataTransformation`ScaleDataSet[correctedDataSet, correctedDataSetScaleInfo]
		];
		
		(* Initialization *)
		numberOfInputVariables = Length[scaledDataSet[[1, 1]]];
		numberOfOutputVariables = Length[scaledDataSet[[1, 2]]];
		
		(* Clear mlrVariable variable. NOTE: These is NOT a local variable *)
		Clear[mlrVariable];

		(* Create subscripted mlrVariable variable vector and function vector. NOTE : These are NOT local variables *)
		variableVector = Table[Subscript[mlrVariable, i], {i, numberOfInputVariables}];
		functionVector = Flatten[{1.0, variableVector}];

		(* Transform data for Fit[] (see signature of Fit) *)
		mlrInputDataList = 
			Table[
				Table[
					ioPair = scaledDataSet[[k]];
					AppendTo[ioPair[[1]], ioPair[[2, i]]],
					
					{k, Length[scaledDataSet]}
				],
				
				{i, numberOfOutputVariables}
			];

		(* Fit data *)
		mlrFitResult = 
			Table[
				Fit[mlrInputDataList[[i]], functionVector, variableVector], 
					
				{i, numberOfOutputVariables}
			];
		
		(* ----------------------------------------------------------------------------------------------------
		   Return results
		   ---------------------------------------------------------------------------------------------------- *)
    	Return[{mlrFitResult, correctedDataSetScaleInfo, dataTransformationMode, outputOffsets}]
	];

GetBestMlrClassOptimization[

	(* Returns best training set optimization result of MLR for classification.

	   Returns: 
	   Best index for classification *)


	(* mlrTrainOptimization = {trainingSetRmseList, testSetRmseList, trainingAndTestSetList, mlrInfoList}
	   trainingSetRmseList: List with {number of optimization step, RMSE of training set}
	   testSetRmseList: List with {number of optimization step, RMSE of test set}
	   trainingAndTestSetList: List with {training set, test set}
	   trainingAndTestSetList[[i]] refers to optimization step i
	   mlrInfoList: List with mlrInfo
	   mlrInfoList[[i]] refers to optimization step i *)
	mlrTrainOptimization_
    
	] :=
  
	Module[
    
		{
			k,
			trainingAndTestSetList,
			mlrInfoList,
			maximumCorrectClassificationInPercent,
			mlrInfo,
			correctClassificationInPercent,
			bestIndex,
			testSet 
		},

		trainingAndTestSetList = mlrTrainOptimization[[3]];
		mlrInfoList = mlrTrainOptimization[[4]];
		maximumCorrectClassificationInPercent = -1.0;
		Do[
			testSet = trainingAndTestSetList[[k, 2]];
			mlrInfo = mlrInfoList[[k]];
			correctClassificationInPercent = CalculateMlrCorrectClassificationInPercent[testSet, mlrInfo];
			If[correctClassificationInPercent > maximumCorrectClassificationInPercent,
				maximumCorrectClassificationInPercent = correctClassificationInPercent;
				bestIndex = k
			],
			
			{k, Length[mlrInfoList]}
		];

		Return[bestIndex]
	];

GetBestMlrRegressOptimization[

	(* Returns best training set optimization result of MLR for regression.

	   Returns: 
	   Best index for regression *)


	(* mlrTrainOptimization = {trainingSetRmseList, testSetRmseList, trainingAndTestSetList, mlrInfoList}
	   trainingSetRmseList: List with {number of optimization step, RMSE of training set}
	   testSetRmseList: List with {number of optimization step, RMSE of test set}
	   trainingAndTestSetList: List with {training set, test set}
	   trainingAndTestSetList[[i]] refers to optimization step i
	   mlrInfoList: List with mlrInfo
	   mlrInfoList[[i]] refers to optimization step i *)
	mlrTrainOptimization_
    
	] :=
  
	Module[
    
		{
			k,
			bestIndex,
			testSetRmseList,
			minimumTestSetRmseValue
		},

		testSetRmseList = mlrTrainOptimization[[2]];
		minimumTestSetRmseValue = Infinity;
		Do[
			If[testSetRmseList[[k, 2]] < minimumTestSetRmseValue,
				minimumTestSetRmseValue = testSetRmseList[[k, 2]];
				bestIndex = k
			],
			
			{k, Length[testSetRmseList]}
		];

		Return[bestIndex]
	];

GetInternalMlrOutput[

	(* Returns output of MLR according to specified input.

	   Returns: output: {outputValue1, outputValue2, ..., outputValue<<numberOfoutputValues>} *)


    (* {inputValue1, inputValue2, ..., inputValue<<numberOfInputValues>} *)
    input_/;VectorQ[input, NumberQ],

	(* mlrFitResult: See code of FitMlr[] and signature of Fit[] *)
    mlrFitResult_
    
	] :=
  
	Module[
    
		{
			j,
			k,
			output,
			replacementList
		},
    
		(* NOTE: Subscripted mlrVariable variables are NOT local *)
		replacementList = 
			Table[
				Subscript[mlrVariable, j] -> input[[j]], 
					
				{j, Length[input]}
			];
        output = 
        	Table[
        		mlrFitResult[[k]] /. replacementList, 
        			
        		{k, Length[mlrFitResult]}
        	];
		Return[output]
	];

GetInternalMlrOutputs[

	(* Returns outputs of MLR according to specified inputs.

	   Returns: 
	   outputs: {output1, ..., output<Length[inputs]>} 
	   output[[i]] corresponds to inputs[[i]] *)

    (* inputs: {input1, input2, ...} 
       input: {inputValue1, inputValue2, ..., inputValue<<numberOfInputValues>} *)
    inputs_/;MatrixQ[inputs, NumberQ],

	(* mlrFitResult: See code of FitMlr[] and signature of Fit[] *)
    mlrFitResult_
	
	] :=
  
	Module[
    
		{
			i,
			j,
			k,
			outputs,
			replacementList,
			singleInput
		},
    
		(* NOTE: Subscripted mlrVariable variables are NOT local *)
		outputs = 
			Table[
		    	singleInput = inputs[[i]];
				replacementList = 
					Table[
						Subscript[mlrVariable, j] -> singleInput[[j]], 
							
						{j, Length[singleInput]}
					];
	    		Table[
	    			mlrFitResult[[k]] /. replacementList, 
	    				
	    			{k, Length[mlrFitResult]}
	    		],
	    
				{i, Length[inputs]}
		    ];
		Return[outputs]
	];

GetMlrInputRelevanceClass[

	(* Analyzes relevance of input components by successive leave-one-out for classification.

	   Returns: 
	   mlrInputComponentRelevanceListForClassification: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, removedInputComponentList, mlrInfo}
	   trainingSetResult: {numberOfRemovedInputs, (best) correct classification in percent of training set (if there is no test set)}
	   testSetResult: {numberOfRemovedInputs, best correct classification in percent of test set} *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,
      
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			dataTransformationMode,
						
			targetInterval,

			bestCurrentRemovedInputComponentList,
			bestCorrectClassificationInPercent,
			bestMlrInfo,
			currentRemovedInputComponentList,
			i,
			correctClassificationInPercent,
			numberOfInputs,
			numberOfRemovedInputs,
			mlrInputComponentRelevanceListForClassification,
	        mlrInfo,
			removedInputComponentList,
			relevance,
			testSet,
			trainingSet,
			testSetCorrectClassificationInPercent,
			trainingSetCorrectClassificationInPercent,
			bestTestSetCorrectClassificationInPercent,
			bestTrainingSetCorrectClassificationInPercent
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* MLR options *)
		dataTransformationMode = MlrOptionDataTransformationMode/.{opts}/.Options[MlrOptionsDataTransformation];
	    (* DataTransformation options *)   
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* ----------------------------------------------------------------------------------------------------
		   Initialization
		   ---------------------------------------------------------------------------------------------------- *)
		numberOfInputs = First[Dimensions[trainingAndTestSet[[1, 1, 1]] ]];
		removedInputComponentList = {};
		mlrInputComponentRelevanceListForClassification = {};
    
		(* Result for no removal *)
		trainingSet = trainingAndTestSet[[1]];
		testSet = trainingAndTestSet[[2]];
		mlrInfo = 
			FitMlr[
				trainingSet,
				MlrOptionDataTransformationMode -> dataTransformationMode,
				DataTransformationOptionTargetInterval -> targetInterval
			];
		If[Length[testSet] > 0,
			
			testSetCorrectClassificationInPercent = CalculateMlrCorrectClassificationInPercent[testSet, mlrInfo];
			trainingSetCorrectClassificationInPercent = CalculateMlrCorrectClassificationInPercent[trainingSet, mlrInfo];
			relevance = 
				{
					{0.0, trainingSetCorrectClassificationInPercent},
					{0.0, testSetCorrectClassificationInPercent},
					{}, 
					mlrInfo
				},
          
			trainingSetCorrectClassificationInPercent = CalculateMlrCorrectClassificationInPercent[trainingSet, mlrInfo];
			relevance = 
				{
					{0.0, trainingSetCorrectClassificationInPercent},
					{},
					{}, 
					mlrInfo
				}
		];
		AppendTo[mlrInputComponentRelevanceListForClassification, relevance];
    
		(* ----------------------------------------------------------------------------------------------------
		   Main loop over number of removed input units
		   ---------------------------------------------------------------------------------------------------- *)
		Do[
			(* Loop over all input units *)
			bestCorrectClassificationInPercent = -1.0;
			bestTrainingSetCorrectClassificationInPercent = -1.0;
			bestTestSetCorrectClassificationInPercent = -1.0;
			Do[
				If[Length[Position[removedInputComponentList, i]] == 0,
					currentRemovedInputComponentList = Append[removedInputComponentList, i];
					trainingSet = trainingAndTestSet[[1]];
					testSet = trainingAndTestSet[[2]];
					trainingSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[trainingSet, currentRemovedInputComponentList];
    				If[Length[testSet] > 0, 
						testSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[testSet, currentRemovedInputComponentList]
					];
					mlrInfo = 
						FitMlr[
							trainingSet,
							MlrOptionDataTransformationMode -> dataTransformationMode,
							DataTransformationOptionTargetInterval -> targetInterval
						];
					If[Length[testSet] > 0,
            
						testSetCorrectClassificationInPercent = CalculateMlrCorrectClassificationInPercent[testSet, mlrInfo];
						trainingSetCorrectClassificationInPercent = CalculateMlrCorrectClassificationInPercent[trainingSet, mlrInfo];
						correctClassificationInPercent = testSetCorrectClassificationInPercent,
          
						trainingSetCorrectClassificationInPercent = CalculateMlrCorrectClassificationInPercent[trainingSet, mlrInfo];
						correctClassificationInPercent = trainingSetCorrectClassificationInPercent
					];
					If[correctClassificationInPercent > bestCorrectClassificationInPercent,
						bestCorrectClassificationInPercent = correctClassificationInPercent;
						bestCurrentRemovedInputComponentList = currentRemovedInputComponentList;
						bestMlrInfo = mlrInfo;
						bestTestSetCorrectClassificationInPercent = testSetCorrectClassificationInPercent; 
						bestTrainingSetCorrectClassificationInPercent = trainingSetCorrectClassificationInPercent;
						If[bestCorrectClassificationInPercent == 100.0,
							Break[]
						]
					]
				],
        
				{i, numberOfInputs}
			];
			If[Length[testSet] > 0,
				
				relevance = 
					{
						{N[numberOfRemovedInputs], bestTrainingSetCorrectClassificationInPercent}, 
						{N[numberOfRemovedInputs], bestTestSetCorrectClassificationInPercent}, 
						bestCurrentRemovedInputComponentList, 
						mlrInfo
					},
	          
				relevance = 
					{
						{N[numberOfRemovedInputs], bestTrainingSetCorrectClassificationInPercent}, 
						{}, 
						bestCurrentRemovedInputComponentList, 
						mlrInfo
					}
			];
			AppendTo[mlrInputComponentRelevanceListForClassification, relevance];
			removedInputComponentList = bestCurrentRemovedInputComponentList,
      
			{numberOfRemovedInputs, numberOfInputs - 1}
		];
		
		Return[mlrInputComponentRelevanceListForClassification]
	];

GetMlrInputRelevanceRegress[

	(* Analyzes relevance of input components by successive leave-one-out for regression.

	   Returns: 
	   mlrInputComponentRelevanceListForRegression: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, removedInputComponentList, mlrInfo}
	   trainingSetResult: {numberOfRemovedInputs, (best) RMSE of training set (if there is no test set)}
	   testSetResult: {numberOfRemovedInputs, best RMSE of test set} *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,
      
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			dataTransformationMode,
						
			targetInterval,

			bestCurrentRemovedInputComponentList,
			bestRmse,
			bestMlrInfo,
			currentRemovedInputComponentList,
			i,
			rmse,
			numberOfInputs,
			numberOfRemovedInputs,
			mlrInputComponentRelevanceListForRegression,
	        mlrInfo,
			removedInputComponentList,
			relevance,
			testSet,
			trainingSet,
			testSetRmse,
			trainingSetRmse,
			bestTestSetRmse,
			bestTrainingSetRmse,
			isIntermediateOutput
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Mlr options *)   
		dataTransformationMode = MlrOptionDataTransformationMode/.{opts}/.Options[MlrOptionsDataTransformation];
	    (* DataTransformation options *)   
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];
	    (* Utility options *)   
	    isIntermediateOutput = UtilityOptionsIsIntermediateOutput/.{opts}/.Options[UtilityOptionsIsIntermediateOutput];

		(* ----------------------------------------------------------------------------------------------------
		   Initialization
		   ---------------------------------------------------------------------------------------------------- *)
		numberOfInputs = First[Dimensions[trainingAndTestSet[[1, 1, 1]] ]];
		removedInputComponentList = {};
		mlrInputComponentRelevanceListForRegression = {};
    
		(* Result for no removal *)
		trainingSet = trainingAndTestSet[[1]];
		testSet = trainingAndTestSet[[2]];
		mlrInfo = 
			FitMlr[
				trainingSet,
				MlrOptionDataTransformationMode -> dataTransformationMode,
				DataTransformationOptionTargetInterval -> targetInterval
			];
		If[Length[testSet] > 0,
			
			testSetRmse = CalculateMlrDataSetRmse[testSet, mlrInfo];
			trainingSetRmse = CalculateMlrDataSetRmse[trainingSet, mlrInfo];
			relevance = 
				{
					{0.0, trainingSetRmse},
					{0.0, testSetRmse},
					{}, 
					mlrInfo
				},
          
			trainingSetRmse = CalculateMlrDataSetRmse[trainingSet, mlrInfo];
			relevance = 
				{
					{0.0, trainingSetRmse},
					{},
					{}, 
					mlrInfo
				}
		];
		AppendTo[mlrInputComponentRelevanceListForRegression, relevance];
    
		(* ----------------------------------------------------------------------------------------------------
		   Main loop over number of removed input units
		   ---------------------------------------------------------------------------------------------------- *)
		Do[
			(* Loop over all input units *)
			bestRmse = Infinity;
			bestTrainingSetRmse = Infinity;
			bestTestSetRmse = Infinity;
			Do[
				If[Length[Position[removedInputComponentList, i]] == 0,
					currentRemovedInputComponentList = Append[removedInputComponentList, i];
					trainingSet = trainingAndTestSet[[1]];
					testSet = trainingAndTestSet[[2]];
					trainingSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[trainingSet, currentRemovedInputComponentList];
    				If[Length[testSet] > 0, 
						testSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[testSet, currentRemovedInputComponentList]
					];
					mlrInfo = 
						FitMlr[
							trainingSet,
							MlrOptionDataTransformationMode -> dataTransformationMode,
							DataTransformationOptionTargetInterval -> targetInterval
						];
					If[Length[testSet] > 0,
            
						testSetRmse = CalculateMlrDataSetRmse[testSet, mlrInfo];
						trainingSetRmse = CalculateMlrDataSetRmse[trainingSet, mlrInfo];
						rmse = testSetRmse,
          
						trainingSetRmse = CalculateMlrDataSetRmse[trainingSet, mlrInfo];
						rmse = trainingSetRmse
					];
					If[rmse < bestRmse,
						bestRmse = rmse;
						bestCurrentRemovedInputComponentList = currentRemovedInputComponentList;
						bestMlrInfo = mlrInfo;
						bestTestSetRmse = testSetRmse; 
						bestTrainingSetRmse = trainingSetRmse; 
					]
				],
        
				{i, numberOfInputs}
			];
			If[Length[testSet] > 0,
				
				If[isIntermediateOutput,
					Print["currentRemovedInputComponentList = ", bestCurrentRemovedInputComponentList];
					Print["currentTrainingSetRmse   = ", bestTrainingSetRmse];
					Print["currentTestSetRmse       = ", bestTestSetRmse];
				];
				relevance = 
					{
						{N[numberOfRemovedInputs], bestTrainingSetRmse}, 
						{N[numberOfRemovedInputs], bestTestSetRmse}, 
						bestCurrentRemovedInputComponentList, 
						mlrInfo
					},
	          
				If[isIntermediateOutput,
					Print["currentRemovedInputComponentList = ", bestCurrentRemovedInputComponentList];
					Print["currentTrainingSetRmse   = ", bestTrainingSetRmse];
				];
				relevance = 
					{
						{N[numberOfRemovedInputs], bestTrainingSetRmse}, 
						{}, 
						bestCurrentRemovedInputComponentList, 
						mlrInfo
					}
			];
			AppendTo[mlrInputComponentRelevanceListForRegression, relevance];
			removedInputComponentList = bestCurrentRemovedInputComponentList,
      
			{numberOfRemovedInputs, numberOfInputs - 1}
		];
		
		Return[mlrInputComponentRelevanceListForRegression]
	];

GetMlrInputRelevanceRegressSpec[

	(* Analyzes relevance of input components by successive leave-one-out for regression.
	   After each loop over all input components the number of input components specified in numberOfExclusionsPerStepList are excluded,
	   i.e. with numberOfExclusionsPerStepList = {20, 10, 5} 20 input components are excluded after the first loop, after the second
	   loop 10 input components etc. 

	   Returns: 
	   mlrInputComponentRelevanceListForRegression: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, removedInputComponentList, mlrInfo}
	   trainingSetResult: {numberOfRemovedInputs, (best) RMSE of training set (if there is no test set)}
	   testSetResult: {numberOfRemovedInputs, best RMSE of test set} *)


	(* trainingAndTestSet: {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...}
	   testSet has the same structure as trainingSet *)
	trainingAndTestSet_,
	
	(* Number of input components to be excluded after each loop over all input components *)
	numberOfExclusionsPerStepList_/;VectorQ[numberOfExclusionsPerStepList, IntegerQ],
      
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			dataTransformationMode,
			targetInterval,
			currentRemovedInputComponentList,
			i,
			k,
			numberOfInputs,
			numberOfRemovedInputs,
			mlrInputComponentRelevanceListForRegression,
	        mlrInfo,
			removedInputComponentList,
			relevance,
			testSet,
			trainingSet,
			initialTestSetRmse,
			initialTrainingSetRmse,
			testSetRmse,
			trainingSetRmse,
			isIntermediateOutput,
			rmseList,
			sortedRmseList,
			currentTrainingSetRmse,
			currentTestSetRmse,
			currentNumberOfExclusions
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Mlr options *)   
		dataTransformationMode = MlrOptionDataTransformationMode/.{opts}/.Options[MlrOptionsDataTransformation];
	    (* DataTransformation options *)   
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];
	    (* Utility options *)   
	    isIntermediateOutput = UtilityOptionsIsIntermediateOutput/.{opts}/.Options[UtilityOptionsIsIntermediateOutput];

		(* ----------------------------------------------------------------------------------------------------
		   Initialization
		   ---------------------------------------------------------------------------------------------------- *)
		numberOfInputs = First[Dimensions[trainingAndTestSet[[1, 1, 1]] ]];
		removedInputComponentList = {};
		mlrInputComponentRelevanceListForRegression = {};
    
		(* Result for no removal *)
		trainingSet = trainingAndTestSet[[1]];
		testSet = trainingAndTestSet[[2]];
		mlrInfo = 
			FitMlr[
				trainingSet,
				MlrOptionDataTransformationMode -> dataTransformationMode,
				DataTransformationOptionTargetInterval -> targetInterval
			];
		If[Length[testSet] > 0,
			
			initialTrainingSetRmse = CalculateMlrDataSetRmse[trainingSet, mlrInfo];
			initialTestSetRmse = CalculateMlrDataSetRmse[testSet, mlrInfo];
			If[isIntermediateOutput,
				Print["initialTrainingSetRmse = ", initialTrainingSetRmse];
				Print["initialTestSetRmse     = ", initialTestSetRmse]
			];
			relevance = 
				{
					{0.0, initialTrainingSetRmse},
					{0.0, initialTestSetRmse},
					{}, 
					mlrInfo
				},
          
			initialTrainingSetRmse = CalculateMlrDataSetRmse[trainingSet, mlrInfo];
			If[isIntermediateOutput,
				Print["initialTrainingSetRmse = ", initialTrainingSetRmse]
			];
			relevance = 
				{
					{0.0, initialTrainingSetRmse},
					{},
					{}, 
					mlrInfo
				}
		];
		AppendTo[mlrInputComponentRelevanceListForRegression, relevance];
    
		(* ----------------------------------------------------------------------------------------------------
		   Main loop over number of removed input units
		   ---------------------------------------------------------------------------------------------------- *)
		numberOfRemovedInputs = 0;
		Do[
			(* Loop over all input units *)
			currentNumberOfExclusions = numberOfExclusionsPerStepList[[k]];
			rmseList = {};
			Do[
				If[Length[Position[removedInputComponentList, i]] == 0,
					currentRemovedInputComponentList = Append[removedInputComponentList, i];
					trainingSet = trainingAndTestSet[[1]];
					testSet = trainingAndTestSet[[2]];
					trainingSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[trainingSet, currentRemovedInputComponentList];
    				If[Length[testSet] > 0, 
						testSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[testSet, currentRemovedInputComponentList]
					];
					mlrInfo = 
						FitMlr[
							trainingSet,
							MlrOptionDataTransformationMode -> dataTransformationMode,
							DataTransformationOptionTargetInterval -> targetInterval
						];
					If[Length[testSet] > 0,
            
						testSetRmse = CalculateMlrDataSetRmse[testSet, mlrInfo];
						AppendTo[rmseList,{testSetRmse, i}],
          
						trainingSetRmse = CalculateMlrDataSetRmse[trainingSet, mlrInfo];
						AppendTo[rmseList,{trainingSetRmse, i}]
					]
				],
        
				{i, numberOfInputs}
			];
			sortedRmseList = Sort[rmseList];
			currentRemovedInputComponentList = Flatten[AppendTo[removedInputComponentList, Take[sortedRmseList[[All, 2]], currentNumberOfExclusions]]];
			numberOfRemovedInputs = Length[currentRemovedInputComponentList];
			trainingSet = trainingAndTestSet[[1]];
			testSet = trainingAndTestSet[[2]];
			trainingSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[trainingSet, currentRemovedInputComponentList];
			If[Length[testSet] > 0, 
				testSet = CIP`DataTransformation`RemoveInputComponentsOfDataSet[testSet, currentRemovedInputComponentList]
			];
			mlrInfo = 
				FitMlr[
					trainingSet,
					MlrOptionDataTransformationMode -> dataTransformationMode,
					DataTransformationOptionTargetInterval -> targetInterval
				];
			If[Length[testSet] > 0,
				
    			currentTrainingSetRmse = CalculateMlrDataSetRmse[trainingSet, mlrInfo];
				currentTestSetRmse = CalculateMlrDataSetRmse[testSet, mlrInfo];
				If[isIntermediateOutput,
					Print["currentRemovedInputComponentList = ", currentRemovedInputComponentList];
					Print["currentTrainingSetRmse   = ", currentTrainingSetRmse];
					Print["Delta(current - initial) = ", currentTrainingSetRmse - initialTrainingSetRmse];
					Print["currentTestSetRmse       = ", currentTestSetRmse];
					Print["Delta(current - initial) = ", currentTestSetRmse - initialTestSetRmse]
				];
				relevance = 
					{
						{N[numberOfRemovedInputs], currentTrainingSetRmse}, 
						{N[numberOfRemovedInputs], currentTestSetRmse}, 
						currentRemovedInputComponentList, 
						mlrInfo
					},
	          
				currentTrainingSetRmse = CalculateMlrDataSetRmse[trainingSet, mlrInfo];
				If[isIntermediateOutput,
					Print["currentRemovedInputComponentList = ", currentRemovedInputComponentList];
					Print["currentTrainingSetRmse   = ", currentTrainingSetRmse];
					Print["Delta(current - initial) = ", currentTrainingSetRmse - initialTrainingSetRmse]
				];
				relevance = 
					{
						{N[numberOfRemovedInputs], currentTrainingSetRmse}, 
						{}, 
						currentRemovedInputComponentList, 
						mlrInfo
					}
			];
			AppendTo[mlrInputComponentRelevanceListForRegression, relevance];
			removedInputComponentList = currentRemovedInputComponentList,
			
			{k, Length[numberOfExclusionsPerStepList]}
		];
		
		Return[mlrInputComponentRelevanceListForRegression]
	];

GetMlrTrainOptimization[

	(* Returns training set optimization result for MLR training.

	   Returns:
	   mlrTrainOptimization = {trainingSetRmseList, testSetRmseList, trainingAndTestSetList, mlrInfoList}
	   trainingSetRmseList: List with {number of optimization step, RMSE of training set}
	   testSetRmseList: List with {number of optimization step, RMSE of test set}
	   trainingAndTestSetList: List with {training set, test set}
	   trainingAndTestSetList[[i]] refers to optimization step i
	   mlrInfoList: List with mlrInfo
	   mlrInfoList[[i]] refers to optimization step i *)


	(* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} *)
    dataSet_,

	(* 0.0 < trainingFraction <= 1.0 
	   trainingFraction = 1.0: Test set is empty *)
	trainingFraction_?NumberQ, 

	(* Number of training set optimization steps *)
	numberOfTrainingSetOptimizationSteps_?IntegerQ,

	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			dataTransformationMode,
			targetInterval,

			clusterMethod,
			maximumNumberOfEpochs,
			scalarProductMinimumTreshold,
			maximumNumberOfTrialSteps,
			randomValueInitialization,

			deviationCalculationMethod,
			blackListLength,
			
			i,
			testSet,
			trainingSet,
			clusterRepresentativesRelatedIndexLists,
			trainingSetIndexList,
			testSetIndexList,
			indexLists,
			mlrInfo,
			trainingSetRMSE,
			testSetRMSE,
			pureOutputFunction,
			trainingSetRmseList,
			testSetRmseList,
			trainingAndTestSetList,
			mlrInfoList,
			selectionResult,
			blackList
		},
    
		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* Mlr options *)
	    dataTransformationMode = MlrOptionDataTransformationMode/.{opts}/.Options[MlrOptionsDataTransformation];
	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* Cluster options *)
		clusterMethod = ClusterOptionMethod/.{opts}/.Options[ClusterOptionsMethod];
	    maximumNumberOfEpochs = ClusterOptionMaximumNumberOfEpochs/.{opts}/.Options[ClusterOptionsArt2a];
	    scalarProductMinimumTreshold = ClusterOptionScalarProductMinimumTreshold/.{opts}/.Options[ClusterOptionsArt2a];
	    maximumNumberOfTrialSteps = ClusterOptionMaximumTrialSteps/.{opts}/.Options[ClusterOptionsArt2a];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];

		(* Training set optimization options *)
	    deviationCalculationMethod = UtilityOptionDeviationCalculation/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];
	    blackListLength = UtilityOptionBlackListLength/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];

		clusterRepresentativesRelatedIndexLists = 
			CIP`Cluster`GetClusterRepresentativesRelatedIndexLists[
				dataSet, 
				trainingFraction, 
				ClusterOptionMethod -> clusterMethod,
				ClusterOptionMaximumNumberOfEpochs -> maximumNumberOfEpochs,
				ClusterOptionScalarProductMinimumTreshold -> scalarProductMinimumTreshold,
				ClusterOptionMaximumTrialSteps -> maximumNumberOfTrialSteps,
				UtilityOptionRandomInitializationMode -> randomValueInitialization,
				DataTransformationOptionTargetInterval -> targetInterval
			];
		trainingSetIndexList = clusterRepresentativesRelatedIndexLists[[1]];
		testSetIndexList = clusterRepresentativesRelatedIndexLists[[2]];
		indexLists = clusterRepresentativesRelatedIndexLists[[3]];

		trainingSetRmseList = {};
		testSetRmseList = {};
		trainingAndTestSetList = {};
		mlrInfoList = {};
		blackList = {};
		Do[
			(* Fit training set and evaluate RMSE *)
			trainingSet = CIP`DataTransformation`GetDataSetPart[dataSet, trainingSetIndexList];
			testSet = CIP`DataTransformation`GetDataSetPart[dataSet, testSetIndexList];
			mlrInfo = 
				FitMlr[
					trainingSet,
					MlrOptionDataTransformationMode -> dataTransformationMode,
					DataTransformationOptionTargetInterval -> targetInterval
				];
			trainingSetRMSE = CalculateMlrDataSetRmse[trainingSet, mlrInfo];
			testSetRMSE = CalculateMlrDataSetRmse[testSet, mlrInfo];

			(* Set iteration results *)
			AppendTo[trainingSetRmseList, {N[i], trainingSetRMSE}];
			AppendTo[testSetRmseList, {N[i], testSetRMSE}];
			AppendTo[trainingAndTestSetList, {trainingSet, testSet}];
			AppendTo[mlrInfoList, mlrInfo];
			
			(* Break if necessary *)
			If[i == numberOfTrainingSetOptimizationSteps,
				Break[]
			];

			(* Select new training and test set index lists *)
			pureOutputFunction = Function[input, CalculateMlrOutput[input, mlrInfo]];
			selectionResult = 
				CIP`Utility`SelectNewTrainingAndTestSetIndexLists[
					dataSet, 
					trainingSetIndexList, 
					testSetIndexList,
					blackList,
					indexLists, 
					pureOutputFunction, 
					UtilityOptionDeviationCalculation -> deviationCalculationMethod,
					UtilityOptionBlackListLength -> blackListLength
				];
			trainingSetIndexList = selectionResult[[1]];
			testSetIndexList = selectionResult[[2]];
			blackList = selectionResult[[3]],
			
			{i, numberOfTrainingSetOptimizationSteps}
		];
		
		Return[
			{
				trainingSetRmseList,
				testSetRmseList,
				trainingAndTestSetList,
				mlrInfoList
			}
		]
	];

ScanClassTrainingWithMlr[

	(* Scans training and test set for different training fractions based on method FitMlr, see code.
	
	   Returns:
	   mlrClassificationScan: {trainingAndTestSetsInfo, scanReport}
	   trainingAndTestSetsInfo: {{trainingAndTestSet1, mlrInfo1}, {trainingAndTestSet2, mlrInfo2}, ...}
	   trainingAndTestSetsInfo[[i]] corresponds to trainingFractionList[[i]]
	   scanReport: {scanResult1, scanResult2, ...}
	   scanResult: {{trainingFraction, classification result in percent for training set}, {trainingFraction, classification result in percent for test set}}
	   scanResult[[i]] corresponds to trainingFractionList[[i]] and trainingAndTestSetsInfo[[i]] *)

	
	(* classificationDataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputValue1, inputValue2, ...}
	   output: {outputValue1, outputValue2, ...} 
	   outputValue: 0/1
	   Data set must be a classification data set, i.e. the output components must 0/1 code a class,
	   i.e. class 4 of 5 must be coded {0, 0, 0, 1, 0} *)
    classificationDataSet_,

	(* trainingFractionList = {trainingFraction1, trainingFraction2, ...}
	   0.0 < trainingFraction <= 1.0 
	   trainingFraction = 1.0: Test set is empty *)
	trainingFractionList_/;VectorQ[trainingFractionList, NumberQ],
	
	(* Options *)
	opts___

	] :=
    
	Module[
      
		{
	    	dataTransformationMode,
	    	targetInterval,

	    	clusterMethod,
	    	maximumNumberOfEpochs,
	    	scalarProductMinimumTreshold,
	    	maximumNumberOfTrialSteps,
	    	randomValueInitialization,

			numberOfTrainingSetOptimizationSteps,
			deviationCalculationMethod,
			blackListLength,

			i,
			scanReport,
			trainingAndTestSetsInfo,
			currentTrainingAndTestSet,
			currentTrainingSet,
			currentTestSet,
			currentMlrInfo,
			pureFunction,
			trainingSetCorrectClassificationInPercent,
			testSetCorrectClassificationInPercent,
			mlrTrainOptimization,
			trainingAndTestSetList,
			mlrInfoList,
			bestIndex
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* MLR options *)
		dataTransformationMode = MlrOptionDataTransformationMode/.{opts}/.Options[MlrOptionsDataTransformation];
   	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* Cluster options *)
		clusterMethod = ClusterOptionMethod/.{opts}/.Options[ClusterOptionsMethod];
	    maximumNumberOfEpochs = ClusterOptionMaximumNumberOfEpochs/.{opts}/.Options[ClusterOptionsArt2a];
	    scalarProductMinimumTreshold = ClusterOptionScalarProductMinimumTreshold/.{opts}/.Options[ClusterOptionsArt2a];
	    maximumNumberOfTrialSteps = ClusterOptionMaximumTrialSteps/.{opts}/.Options[ClusterOptionsArt2a];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];

		(* Training set optimization options *)
		numberOfTrainingSetOptimizationSteps = UtilityOptionOptimizationSteps/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];
		deviationCalculationMethod = UtilityOptionDeviationCalculation/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];
	    blackListLength = UtilityOptionBlackListLength/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];

		scanReport = {};
		trainingAndTestSetsInfo = {};
		Do[
			If[numberOfTrainingSetOptimizationSteps > 0,
				
				(* ------------------------------------------------------------------------------------------------------ *)
				(* Training set optimization *)
				mlrTrainOptimization = 
					GetMlrTrainOptimization[
						classificationDataSet, 
						trainingFractionList[[i]],
						numberOfTrainingSetOptimizationSteps,
						MlrOptionDataTransformationMode -> dataTransformationMode,
						ClusterOptionMethod -> clusterMethod,
						ClusterOptionMaximumNumberOfEpochs -> maximumNumberOfEpochs,
						ClusterOptionScalarProductMinimumTreshold -> scalarProductMinimumTreshold,
						ClusterOptionMaximumTrialSteps -> maximumNumberOfTrialSteps,
						DataTransformationOptionTargetInterval -> targetInterval,
						UtilityOptionRandomInitializationMode -> randomValueInitialization,
				        UtilityOptionDeviationCalculation -> deviationCalculationMethod,
						UtilityOptionBlackListLength -> blackListLength
					];
				bestIndex = GetBestMlrClassOptimization[mlrTrainOptimization];
				trainingAndTestSetList = mlrTrainOptimization[[3]];
				mlrInfoList = mlrTrainOptimization[[4]];
				currentTrainingAndTestSet = trainingAndTestSetList[[bestIndex]];
				currentTrainingSet = currentTrainingAndTestSet[[1]];
				currentTestSet = currentTrainingAndTestSet[[2]];
				currentMlrInfo = mlrInfoList[[bestIndex]],
				
				(* ------------------------------------------------------------------------------------------------------ *)
				(* No training set optimization *)
				currentTrainingAndTestSet = 
					CIP`Cluster`GetClusterBasedTrainingAndTestSet[
						classificationDataSet,
						trainingFractionList[[i]],
						ClusterOptionMethod -> clusterMethod,
						ClusterOptionMaximumNumberOfEpochs -> maximumNumberOfEpochs,
						ClusterOptionScalarProductMinimumTreshold -> scalarProductMinimumTreshold,
						ClusterOptionMaximumTrialSteps -> maximumNumberOfTrialSteps,
						UtilityOptionRandomInitializationMode -> randomValueInitialization,
						DataTransformationOptionTargetInterval -> targetInterval
				];
				currentTrainingSet = currentTrainingAndTestSet[[1]];
				currentTestSet = currentTrainingAndTestSet[[2]];
				currentMlrInfo = 
					FitMlr[
						currentTrainingSet,
						MlrOptionDataTransformationMode -> dataTransformationMode,
						DataTransformationOptionTargetInterval -> targetInterval
					]
			];
			
			pureFunction = Function[inputs, CalculateMlrClassNumbers[inputs, currentMlrInfo]];
			trainingSetCorrectClassificationInPercent = CIP`Utility`GetCorrectClassificationInPercent[currentTrainingSet, pureFunction];
			testSetCorrectClassificationInPercent = CIP`Utility`GetCorrectClassificationInPercent[currentTestSet, pureFunction];
			AppendTo[trainingAndTestSetsInfo, {currentTrainingAndTestSet, currentMlrInfo}];
			AppendTo[
				scanReport, 
				{
					{trainingFractionList[[i]], trainingSetCorrectClassificationInPercent},
					{trainingFractionList[[i]], testSetCorrectClassificationInPercent}
				}
			],
			
			{i, Length[trainingFractionList]}
		];

		Return[{trainingAndTestSetsInfo, scanReport}]
	];

ScanRegressTrainingWithMlr[

	(* Scans training and test set for different training fractions based on method FitMlr, see code.
	
	   Returns:
	   mlrRegressopmTrainingScanResult: {trainingAndTestSetsInfo, scanReport}
	   trainingAndTestSetsInfo: {{trainingAndTestSet1, mlrInfo1}, {trainingAndTestSet2, mlrInfo2}, ...}
	   trainingAndTestSetsInfo[[i]] corresponds to trainingFractionList[[i]]
	   scanReport: {scanResult1, scanResult2, ...}
	   scanResult: {{trainingFraction, RMSE for training set}, {trainingFraction, RMSE for test set}}
	   scanResult[[i]] corresponds to trainingFractionList[[i]] and trainingAndTestSetsInfo[[i]] *)

	
	(* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputComponent1, inputComponent2, ...}
	   output: {outputComponent1, outputComponent2, ...}
	   NOTE: Data set MUST be in original units *)
	dataSet_,

	(* trainingFractionList = {trainingFraction1, trainingFraction2, ...}
	   0.0 < trainingFraction <= 1.0 
	   trainingFraction = 1.0: Test set is empty *)
	trainingFractionList_/;VectorQ[trainingFractionList, NumberQ],
	
	(* Options *)
	opts___

	] :=
    
	Module[
      
		{
	    	dataTransformationMode,
	    	targetInterval,

	    	clusterMethod,
	    	maximumNumberOfEpochs,
	    	scalarProductMinimumTreshold,
	    	maximumNumberOfTrialSteps,
	    	randomValueInitialization,

			numberOfTrainingSetOptimizationSteps,
			deviationCalculationMethod,
			blackListLength,

			i,
			scanReport,
			trainingAndTestSetsInfo,
			currentTrainingAndTestSet,
			currentTrainingSet,
			currentTestSet,
			currentMlrInfo,
			pureFunction,
			trainingSetRMSE,
			testSetRMSE,
			mlrTrainOptimization,
			trainingAndTestSetList,
			mlrInfoList,
			bestIndex
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
		(* MLR options *)
		dataTransformationMode = MlrOptionDataTransformationMode/.{opts}/.Options[MlrOptionsDataTransformation];
   	    targetInterval = DataTransformationOptionTargetInterval/.{opts}/.Options[DataTransformationOptionsTargetInterval];

		(* Cluster options *)
		clusterMethod = ClusterOptionMethod/.{opts}/.Options[ClusterOptionsMethod];
	    maximumNumberOfEpochs = ClusterOptionMaximumNumberOfEpochs/.{opts}/.Options[ClusterOptionsArt2a];
	    scalarProductMinimumTreshold = ClusterOptionScalarProductMinimumTreshold/.{opts}/.Options[ClusterOptionsArt2a];
	    maximumNumberOfTrialSteps = ClusterOptionMaximumTrialSteps/.{opts}/.Options[ClusterOptionsArt2a];
	    randomValueInitialization = UtilityOptionRandomInitializationMode/.{opts}/.Options[UtilityOptionsRandomInitialization];

		(* Training set optimization options *)
		numberOfTrainingSetOptimizationSteps = UtilityOptionOptimizationSteps/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];
		deviationCalculationMethod = UtilityOptionDeviationCalculation/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];
	    blackListLength = UtilityOptionBlackListLength/.{opts}/.Options[UtilityOptionsTrainingSetOptimization];

		scanReport = {};
		trainingAndTestSetsInfo = {};
		Do[
			If[numberOfTrainingSetOptimizationSteps > 0,
				
				(* ------------------------------------------------------------------------------------------------------ *)
				(* Training set optimization *)
				mlrTrainOptimization = 
					GetMlrTrainOptimization[
						dataSet, 
						trainingFractionList[[i]],
						numberOfTrainingSetOptimizationSteps,
						MlrOptionDataTransformationMode -> dataTransformationMode,
						ClusterOptionMethod -> clusterMethod,
						ClusterOptionMaximumNumberOfEpochs -> maximumNumberOfEpochs,
						ClusterOptionScalarProductMinimumTreshold -> scalarProductMinimumTreshold,
						ClusterOptionMaximumTrialSteps -> maximumNumberOfTrialSteps,
						DataTransformationOptionTargetInterval -> targetInterval,
						UtilityOptionRandomInitializationMode -> randomValueInitialization,
				        UtilityOptionDeviationCalculation -> deviationCalculationMethod,
						UtilityOptionBlackListLength -> blackListLength
					];
				bestIndex = GetBestMlrRegressOptimization[mlrTrainOptimization];
				trainingAndTestSetList = mlrTrainOptimization[[3]];
				mlrInfoList = mlrTrainOptimization[[4]];
				currentTrainingAndTestSet = trainingAndTestSetList[[bestIndex]];
				currentTrainingSet = currentTrainingAndTestSet[[1]];
				currentTestSet = currentTrainingAndTestSet[[2]];
				currentMlrInfo = mlrInfoList[[bestIndex]],
				
				(* ------------------------------------------------------------------------------------------------------ *)
				(* No training set optimization *)
				currentTrainingAndTestSet = 
					CIP`Cluster`GetClusterBasedTrainingAndTestSet[
						dataSet,
						trainingFractionList[[i]],
						ClusterOptionMethod -> clusterMethod,
						ClusterOptionMaximumNumberOfEpochs -> maximumNumberOfEpochs,
						ClusterOptionScalarProductMinimumTreshold -> scalarProductMinimumTreshold,
						ClusterOptionMaximumTrialSteps -> maximumNumberOfTrialSteps,
						UtilityOptionRandomInitializationMode -> randomValueInitialization,
						DataTransformationOptionTargetInterval -> targetInterval
				];
				currentTrainingSet = currentTrainingAndTestSet[[1]];
				currentTestSet = currentTrainingAndTestSet[[2]];
				currentMlrInfo = 
					FitMlr[
						currentTrainingSet,
						MlrOptionDataTransformationMode -> dataTransformationMode,
						DataTransformationOptionTargetInterval -> targetInterval
					]
			];
			
			pureFunction = Function[inputs, CalculateMlrOutputs[inputs, currentMlrInfo]];
			trainingSetRMSE = Sqrt[CIP`Utility`GetMeanSquaredError[currentTrainingSet, pureFunction]];
			testSetRMSE = Sqrt[CIP`Utility`GetMeanSquaredError[currentTestSet, pureFunction]];
			AppendTo[trainingAndTestSetsInfo, {currentTrainingAndTestSet, currentMlrInfo}];
			AppendTo[
				scanReport, 
				{
					{trainingFractionList[[i]], trainingSetRMSE},
					{trainingFractionList[[i]], testSetRMSE}
				}
			],
			
			{i, Length[trainingFractionList]}
		];

		Return[{trainingAndTestSetsInfo, scanReport}]
	];

ShowMlr3dOutput[

	(* Shows 3D MLR output.

	   Returns: Graphics3D *)


    (* Index of input component that receives argumentValue1 *)
    indexOfInput1_?IntegerQ,

    (* Index of input component that receives argumentValue2 *)
    indexOfInput2_?IntegerQ,

    (* Index of output component that returns function value *)
    indexOfOutput_?IntegerQ,
    
    (* Input in original units: 
       inputsInOriginalUnits = {inputValue1, inputValue2, ...} 
       Values of input components with specified indices (indexOfInput1, indexOfInput2) are replaced by argument values *)
    input_/;VectorQ[input, NumberQ],
    
  	(* See "Frequently used data structures" *)
    mlrInfo_,
    
	(* Options *)
	opts___
      
	] :=
    
	Module[
      
		{	
			GraphicsOptionDisplayFunction,
			GraphicsOptionViewPoint3D,
			GraphicsOptionNumberOfPlotPoints,
			GraphicsOptionColorFunction,
			GraphicsOptionIsMesh,
			GraphicsOptionMeshStyle,
			GraphicsOptionPlotStyle3D,
			inputsMinMaxList,
			labels,
			dataSetScaleInfo,
			x1Min,
			x1Max,
			x2Min,
			x2Max
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    GraphicsOptionDisplayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];
	    GraphicsOptionViewPoint3D = GraphicsOptionViewPoint3D/.{opts}/.Options[GraphicsOptionsGraphics3D];
	    GraphicsOptionNumberOfPlotPoints = GraphicsOptionNumberOfPlotPoints/.{opts}/.Options[GraphicsOptionsGraphics3D];
	    GraphicsOptionColorFunction = GraphicsOptionColorFunction/.{opts}/.Options[GraphicsOptionsGraphics3D];
	    GraphicsOptionIsMesh = GraphicsOptionIsMesh/.{opts}/.Options[GraphicsOptionsGraphics3D];
	    GraphicsOptionMeshStyle = GraphicsOptionMeshStyle/.{opts}/.Options[GraphicsOptionsGraphics3D];
	    GraphicsOptionPlotStyle3D = GraphicsOptionPlotStyle3D/.{opts}/.Options[GraphicsOptionsGraphics3D];

		dataSetScaleInfo = mlrInfo[[2]];
		inputsMinMaxList = dataSetScaleInfo[[1, 1]];
		x1Min = inputsMinMaxList[[indexOfInput1, 1]];
		x1Max = inputsMinMaxList[[indexOfInput1, 2]];
		x2Min = inputsMinMaxList[[indexOfInput2, 1]];
		x2Max = inputsMinMaxList[[indexOfInput2, 2]];
		labels = 
			{
				StringJoin["Input ", ToString[indexOfInput1]],
				StringJoin["Input ", ToString[indexOfInput2]],
				StringJoin["Output ", ToString[indexOfOutput]]
			};
		
		Return[
			CIP`Graphics`Plot3dFunction[
				Function[{x1, x2}, CalculateMlr3dValue[x1, x2, indexOfInput1, indexOfInput2, indexOfOutput, input, mlrInfo]], 
				{x1Min, x1Max}, 
				{x2Min, x2Max}, 
				labels, 
				GraphicsOptionViewPoint3D -> GraphicsOptionViewPoint3D,
				GraphicsOptionNumberOfPlotPoints -> GraphicsOptionNumberOfPlotPoints,
				GraphicsOptionColorFunction -> GraphicsOptionColorFunction,
				GraphicsOptionIsMesh -> GraphicsOptionIsMesh,
				GraphicsOptionMeshStyle -> GraphicsOptionMeshStyle,
				GraphicsOptionPlotStyle3D -> GraphicsOptionPlotStyle3D,
				GraphicsOptionDisplayFunction -> GraphicsOptionDisplayFunction
			]
		]
	];

ShowMlrClassificationResult[

	(* Shows result of MLR classification for training and test set according to named property list.

	   Returns: Nothing *)


	(* Properties to be analyzed: 
	   Full list: 
	   {
	       "CorrectClassification",
	       "CorrectClassificationPerClass",
	       "WrongClassificationDistribution",
	       "WrongClassifictionPairs"
	   } *)
 	namedPropertyList_,
    
    (* {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputComponent1, inputComponent2, ...}
	   output : {outputComponent1, outputComponent2, ...}
	   testSet has the same structure and restrictions as trainingSet 
	   NOTE: Training and test set MUST be in original units *)
    trainingAndTestSet_,
    
  	(* See "Frequently used data structures" *)
    mlrInfo_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			minMaxIndex,
			imageSize,
			testSet,
			trainingSet
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    minMaxIndex = GraphicsOptionMinMaxIndex/.{opts}/.Options[GraphicsOptionsIndex];
    
    	trainingSet = trainingAndTestSet[[1]];
    	testSet =  trainingAndTestSet[[2]];
    	
		Print["Training Set:"];
		ShowMlrSingleClassification[
			namedPropertyList,
			trainingSet, 
			mlrInfo,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionMinMaxIndex -> minMaxIndex
		];
		
		(* Analyze test set *)
		If[Length[testSet] > 0,
			Print["Test Set:"];
			ShowMlrSingleClassification[
				namedPropertyList,
				testSet, 
				mlrInfo,
				GraphicsOptionImageSize -> imageSize,
				GraphicsOptionMinMaxIndex -> minMaxIndex
			];
		]
	];

ShowMlrSingleClassification[

	(* Shows result of MLR classification for data set according to named property list.

	   Returns: Nothing *)


	(* Properties to be analyzed: 
	   Full list: 
	   {
	       "CorrectClassification",
	       "CorrectClassificationPerClass",
	       "WrongClassificationDistribution",
	       "WrongClassifictionPairs"
	    } *)
 	namedPropertyList_,

    (* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputComponent1, inputComponent2, ...}
	   output : {outputComponent1, outputComponent2, ...}
	   NOTE: Data set MUST be in original units *)
    dataSet_,
    
  	(* See "Frequently used data structures" *)
    mlrInfo_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			minMaxIndex,
			imageSize,
			pureFunction
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    minMaxIndex = GraphicsOptionMinMaxIndex/.{opts}/.Options[GraphicsOptionsIndex];

   		pureFunction = Function[inputs, CalculateMlrClassNumbers[inputs, mlrInfo]];
		CIP`Graphics`ShowClassificationResult[
			namedPropertyList,
			dataSet, 
			pureFunction,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionMinMaxIndex -> minMaxIndex
		]
	];

ShowMlrClassificationScan[

	(* Shows result of MLR based classification scan of clustered training sets.

	   Returns: Nothing *)


	(* mlrClassificationScan: {trainingAndTestSetsInfo, scanReport}
	   trainingAndTestSetsInfo: {{trainingAndTestSet1, mlrInfo1}, {trainingAndTestSet2, mlrInfo2}, ...}
	   trainingAndTestSetsInfo[[i]] corresponds to trainingFractionList[[i]]
	   scanReport: {scanResult1, scanResult2, ...}
	   scanResult: {{trainingFraction, classification result in percent for training set}, {trainingFraction, classification result in percent for test set}}
	   scanResult[[i]] corresponds to trainingFractionList[[i]] and trainingAndTestSetsInfo[[i]] *)
	mlrClassificationScan_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			imageSize,
			displayFunction
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		CIP`Graphics`ShowClassificationScan[
			mlrClassificationScan,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionDisplayFunction -> displayFunction
		]
	];

ShowMlrInputRelevanceClass[

	(* Shows mlrInputComponentRelevanceListForClassification.

	   Returns: Nothing *)


	(* mlrInputComponentRelevanceListForClassification: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, removedInputComponentList, mlrInfo}
	   trainingSetResult: {numberOfRemovedInputs, (best) correct classification in percent of training set (if there is no test set)}
	   testSetResult: {numberOfRemovedInputs, best correct classification in percent of test set} *)
	mlrInputComponentRelevanceListForClassification_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			displayFunction,
			imageSize
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		CIP`Graphics`ShowInputRelevanceClass[
			mlrInputComponentRelevanceListForClassification,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionDisplayFunction -> displayFunction
		]
	];

ShowMlrInputRelevanceRegress[

	(* Shows mlrInputComponentRelevanceListForRegression.

	   Returns: Nothing *)


	(* mlrInputComponentRelevanceListForRegression: {relevance1, relevance2, ...}
	   relevance: {trainingSetResult, testSetResult, removedInputComponentList, mlrInfo}
	   trainingSetResult: {numberOfRemovedInputs, (best) RMSE of training set (if there is no test set)}
	   testSetResult: {numberOfRemovedInputs, best RMSE of test set} *)
	mlrInputComponentRelevanceListForRegression_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			displayFunction,
			imageSize
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		CIP`Graphics`ShowInputRelevanceRegress[
			mlrInputComponentRelevanceListForRegression,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionDisplayFunction -> displayFunction
		]
	];

ShowMlrRegressionResult[

	(* Shows result of MLR regression for training and test set according to named property list.
	
	   Returns: Nothing *)


	(* Properties to be analyzed: 
	   Full list: 
	   {
	       "RMSE",
	       "SingleOutputRMSE",
	       "AbsoluteResidualsStatistics",
		   "RelativeResidualsStatistics",
		   "ModelVsDataPlot",
		   "CorrelationCoefficient",
		   "SortedModelVsDataPlot",
		   "AbsoluteSortedResidualsPlot",
		   "RelativeSortedResidualsPlot"
	    } *)
 	namedPropertyList_,

    (* {trainingSet, testSet}
	   trainingSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputComponent1, inputComponent2, ...}
	   output : {outputComponent1, outputComponent2, ...}
	   testSet has the same structure and restrictions as trainingSet
	   NOTE: Training and test set MUST be in original units *)
    trainingAndTestSet_,
    
  	(* See "Frequently used data structures" *)
    mlrInfo_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			pointSize,
			pointColor,
			
			testSet,
			trainingSet
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    pointSize = GraphicsOptionPointSize/.{opts}/.Options[GraphicsOptionsPoint];
	    pointColor = GraphicsOptionPointColor/.{opts}/.Options[GraphicsOptionsPoint];

    	trainingSet = trainingAndTestSet[[1]];
    	testSet =  trainingAndTestSet[[2]];

		(* Analyze training set *)
	    Print["Training Set:"];
		ShowMlrSingleRegression[
			namedPropertyList,
			trainingSet, 
			mlrInfo,
			GraphicsOptionPointSize -> pointSize,
			GraphicsOptionPointColor -> pointColor
		];
		
		(* Analyze test set *)
		If[Length[testSet] > 0,
			Print["Test Set:"];
			ShowMlrSingleRegression[
				namedPropertyList,
				testSet, 
				mlrInfo,
				GraphicsOptionPointSize -> pointSize,
				GraphicsOptionPointColor -> pointColor
			]
		]
	];

ShowMlrSingleRegression[
    
	(* Shows result of MLR regression for data set according to named property list.
	
	   Returns: Nothing *)


	(* Properties to be analyzed: 
	   Full list: 
	   {
	       "RMSE",
	       "SingleOutputRMSE",
	       "AbsoluteResidualsStatistics",
		   "RelativeResidualsStatistics",
		   "ModelVsDataPlot",
		   "CorrelationCoefficient",
		   "SortedModelVsDataPlot",
		   "AbsoluteSortedResidualsPlot",
		   "RelativeSortedResidualsPlot"
	    } *)
 	namedPropertyList_,

    (* dataSet: {IOPair1, IOPair2, ...}
	   IOPair: {input, output}
	   input: {inputComponent1, inputComponent2, ...}
	   output : {outputComponent1, outputComponent2, ...}
	   NOTE: Data set MUST be in original units *)
    dataSet_,
    
  	(* See "Frequently used data structures" *)
    mlrInfo_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			pureFunction,
    		pointSize,
    		pointColor
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    pointSize = GraphicsOptionPointSize/.{opts}/.Options[GraphicsOptionsPoint];
	    pointColor = GraphicsOptionPointColor/.{opts}/.Options[GraphicsOptionsPoint];

		pureFunction = Function[inputs, CalculateMlrOutputs[inputs, mlrInfo]];
		CIP`Graphics`ShowRegressionResult[
			namedPropertyList,
			dataSet, 
			pureFunction,
			GraphicsOptionPointSize -> pointSize,
			GraphicsOptionPointColor -> pointColor
		]
	];

ShowMlrRegressionScan[

	(* Shows result of MLR based regression scan of clustered training sets.

	   Returns: Nothing *)


	(* mlrRegressionScan: {trainingAndTestSetsInfo, scanReport}
	   trainingAndTestSetsInfo: {{trainingAndTestSet1, mlrInfo1}, {trainingAndTestSet2, mlrInfo2}, ...}
	   trainingAndTestSetsInfo[[i]] corresponds to trainingFractionList[[i]]
	   scanReport: {scanResult1, scanResult2, ...}
	   scanResult: {{trainingFraction, RMSE for training set}, {trainingFraction, RMSE for test set}}
	   scanResult[[i]] corresponds to trainingFractionList[[i]] and trainingAndTestSetsInfo[[i]] *)
	mlrRegressionScan_,
	
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			imageSize,
			displayFunction
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		CIP`Graphics`ShowRegressionScan[
			mlrRegressionScan,
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionDisplayFunction -> displayFunction
		]
	];

ShowMlrTrainOptimization[

	(* Shows training set optimization result of MLR.

	   Returns: Nothing *)


	(* mlrTrainOptimization = {trainingSetRmseList, testSetRmseList, not interesting, not interesting}
	   trainingSetRmseList: List with {number of optimization step, RMSE of training set}
	   testSetRmseList: List with {number of optimization step, RMSE of test set} *)
	mlrTrainOptimization_,
    
	(* Options *)
	opts___
    
	] :=
  
	Module[
    
		{
			displayFunction,
			imageSize
		},

		(* ----------------------------------------------------------------------------------------------------
		   Options
		   ---------------------------------------------------------------------------------------------------- *)
	    imageSize = GraphicsOptionImageSize/.{opts}/.Options[GraphicsOptionsImageSize];
	    displayFunction = GraphicsOptionDisplayFunction/.{opts}/.Options[GraphicsOptionsDisplayFunction];

		CIP`Graphics`ShowTrainOptimization[
			mlrTrainOptimization, 
			GraphicsOptionImageSize -> imageSize,
			GraphicsOptionDisplayFunction -> displayFunction
		]
	];

(* ::Section:: *)
(* End of Package *)

End[]

EndPackage[]
